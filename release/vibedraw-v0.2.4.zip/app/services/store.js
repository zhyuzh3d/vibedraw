(function (app) {
  "use strict";
  var revisions = {}, saveTimer = 0, queue = Promise.resolve(), index = [], paused = false;
  var fields = ["prompt", "negativePrompt", "background", "color", "size", "opacity", "strength", "referenceStrength", "seed", "autoDelayMs", "autoGenerate", "includeResult", "resultOpacity", "resultBrightness", "resultContrast", "resultSaturation", "resultHue", "resultGlow", "resultClarity", "view", "workId", "workTitle"];
  function serial(task) { var next = queue.then(task); queue = next.catch(function () {}); return next; }
  async function read(key, fallback) {
    var record = await app.platform.hermit.getData("vibedraw", key);
    if (!record || record.value == null) return app.utils.copy(fallback);
    revisions[key] = record.revision; return record.value;
  }
  async function write(key, value) {
    var result = await app.platform.hermit.putData("vibedraw", key, value, revisions[key]);
    if (result && result.revision) revisions[key] = result.revision;
    return result;
  }
  async function loadConfig() { app.config = app.utils.merge(app.defaults, await read("config", app.defaults)); index = await read("works", []); return app.config; }
  async function saveConfig(config) {
    var value = app.utils.merge(app.defaults, config);
    await serial(function () { return write("config", value); }); app.config = value;
    return value;
  }
  function serializeCanvas() {
    var snapshot = { schema: 2, objects: [], result: null, savedAt: Date.now() };
    fields.forEach(function (name) { snapshot[name] = app.state[name]; });
    snapshot.objects = app.state.objects.map(function (object) {
      var copy = app.utils.copy(object); delete copy.src;
      if (copy.url && /^(data:|blob:)/.test(copy.url)) delete copy.url;
      return copy;
    });
    if (app.state.result) {
      var result = app.state.result;
      snapshot.result = { asset: result.asset || null, logicalFileId: result.logicalFileId || "", slot: result.slot, prompt: result.prompt, createdAt: result.createdAt };
      if (!snapshot.result.asset && result.src && !/^(data:|blob:)/.test(result.src)) snapshot.result.asset = { url: result.src };
    }
    return snapshot;
  }
  async function persistImages() {
    var objects = app.state.objects.slice(), result = app.state.result;
    for (var object of objects) {
      if (object.type !== "image" || object.asset) continue;
      object.asset = await app.services.assets.persist(object.src || object.url, null);
    }
    if (result && !result.asset) result.asset = await app.services.assets.persist(result.src, null);
  }
  function meaningful() { return Boolean(app.state.objects.length || app.state.result || String(app.state.prompt).trim() || String(app.state.workTitle).trim()); }
  async function saveNow() {
    if (paused) return;
    app.events.emit("save", "saving");
    await persistImages();
    var snapshot = serializeCanvas();
    var previous = null;
    if (meaningful() || app.state.workId) {
      if (!app.state.workId) app.state.workId = app.utils.id("work");
      snapshot.workId = app.state.workId;
      var item = index.find(function (value) { return value.id === snapshot.workId; });
      var nextItem = { id: snapshot.workId, title: snapshot.workTitle || snapshot.prompt.slice(0, 48), createdAt: item ? item.createdAt : Date.now(), updatedAt: Date.now(), hasResult: Boolean(snapshot.result) };
      if (item) previous = await read("work-" + snapshot.workId, null);
      await write("work-" + snapshot.workId, snapshot);
      index = index.filter(function (value) { return value.id !== snapshot.workId; });
      index.unshift(nextItem);
      await write("works", index);
    }
    await write("canvas", snapshot);
    if (previous && JSON.stringify(app.services.assets.references(previous)) !== JSON.stringify(app.services.assets.references(snapshot))) {
      var surviving = [snapshot];
      for (var work of index) if (work.id !== snapshot.workId) { var saved = await get(work.id); if (saved) surviving.push(saved); }
      await app.services.assets.cleanup(previous, surviving).catch(function () {});
    }
    app.events.emit("save", "saved"); app.events.emit("works:changed", index.length);
    return snapshot;
  }
  function scheduleCanvasSave() {
    if (paused) return;
    clearTimeout(saveTimer); app.events.emit("save", "pending");
    saveTimer = setTimeout(function () { flush().catch(saveError); }, 650);
  }
  function saveError(error) { app.events.emit("save", "error"); app.events.emit("error", error); }
  function flush() { clearTimeout(saveTimer); return serial(saveNow); }
  async function hydrate(snapshot) {
    if (!snapshot) return null;
    var copy = app.utils.copy(snapshot);
    var missing = false;
    for (var object of copy.objects || []) {
      if (object.type === "image") {
        try { object.src = object.asset ? await app.services.assets.resolve(object.asset) : object.url || ""; }
        catch (_) { object.src = ""; missing = true; }
      }
    }
    if (copy.result && copy.result.asset) {
      try { copy.result.src = await app.services.assets.resolve(copy.result.asset); }
      catch (_) { copy.result.src = ""; missing = true; }
    }
    if (missing) app.events.emit("error", new Error(app.i18n.text("部分历史图片无法读取，草稿与描述仍可编辑", "Some saved images are unavailable. Your sketch and prompt remain editable")));
    return copy;
  }
  async function loadCanvas() { return hydrate(await read("canvas", null)); }
  function list() { return app.utils.copy(index); }
  async function get(id) { return read("work-" + id, null); }
  async function restoreWork(id, duplicate) {
    await flush();
    var saved = await get(id);
    if (!saved) throw new Error(app.i18n.text("找不到这件作品", "Artwork not found"));
    var copy = await hydrate(saved);
    if (duplicate) { copy.workId = app.utils.id("work"); copy.workTitle = (copy.workTitle || copy.prompt.slice(0, 28) || app.i18n.text("未命名作品", "Untitled")) + app.i18n.text(" · 副本", " · copy"); }
    return copy;
  }
  async function remove(id) {
    await flush();
    return serial(async function () {
      var removed = await get(id), remaining = [];
      var nextIndex = index.filter(function (item) { return item.id !== id; });
      for (var item of nextIndex) { var record = await get(item.id); if (record) remaining.push(record); }
      await write("works", nextIndex); index = nextIndex;
      await app.platform.hermit.deleteData("vibedraw", "work-" + id);
      delete revisions["work-" + id];
      if (app.state.workId !== id) remaining.push(serializeCanvas());
      if (removed) await app.services.assets.cleanup(removed, remaining).catch(function () {});
      app.events.emit("works:changed", index.length);
    });
  }
  function pause(value) { paused = value; if (value) clearTimeout(saveTimer); }
  app.services.store = { loadConfig: loadConfig, saveConfig: saveConfig, loadCanvas: loadCanvas, scheduleCanvasSave: scheduleCanvasSave, serializeCanvas: serializeCanvas, flush: flush, list: list, get: get, hydrate: hydrate, restoreWork: restoreWork, remove: remove, meaningful: meaningful, pause: pause };
})(window.vibedraw);
