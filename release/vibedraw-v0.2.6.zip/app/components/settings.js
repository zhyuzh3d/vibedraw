(function (app) {
  "use strict";
  var t = app.i18n.text, u = app.utils, ui, draft, original, slot = "quick";
  function init() { ui = app.components.ui; }
  function input(name, label, value, type, placeholder) {
    return '<label class="field"><span>' + label + '</span><input name="' + name + '" type="' + (type || "text") + '" value="' + u.escapeHtml(value == null ? "" : value) + '" placeholder="' + u.escapeHtml(placeholder || "") + '"></label>';
  }
  function textarea(name, label, value, placeholder) {
    return '<label class="field"><span>' + label + '</span><textarea name="' + name + '" placeholder="' + u.escapeHtml(placeholder || "") + '">' + u.escapeHtml(value || "") + '</textarea></label>';
  }
  function select(name, label, value, choices) {
    return '<label class="field"><span>' + label + '</span><select name="' + name + '">' + choices.map(function (item) { return '<option value="' + item[0] + '"' + (value === item[0] ? " selected" : "") + '>' + item[1] + '</option>'; }).join("") + '</select></label>';
  }
  function range(name, label, value, min, max, suffix) {
    return '<label class="field"><span>' + label + ' <strong data-range-label="' + name + '">' + value + (suffix || "") + '</strong></span><input name="' + name + '" type="range" min="' + min + '" max="' + max + '" value="' + value + '" data-suffix="' + (suffix || "") + '"></label>';
  }
  function ranges(root) {
    root.querySelectorAll('input[type="range"]').forEach(function (field) {
      field.addEventListener("input", function () { root.querySelector('[data-range-label="' + field.name + '"]').textContent = field.value + field.dataset.suffix; });
    });
  }
  function footer(label) { return '<div class="button-row modal-footer"><button class="button button-secondary" data-cancel>' + t("取消", "Cancel") + '</button><button class="button button-primary" data-save>' + (label || t("保存设置", "Save settings")) + '</button></div>'; }
  async function discard() {
    if (JSON.stringify(draft) === original) return true;
    return ui.confirm({ title: t("放弃未保存的修改？", "Discard changes?"), message: t("模型设置尚未保存。", "Your model settings have not been saved."), ok: t("放弃修改", "Discard") });
  }
  function open(kind) {
    ui = app.components.ui;
    if (kind === "models") { draft = u.copy(app.config); original = JSON.stringify(draft); slot = "quick"; renderModels(); }
    else if (kind === "work" || kind === "canvas") workSettings();
    else if (kind === "adjustments") adjustmentSettings();
    else if (kind === "preferences") preferences();
    else if (kind === "brush") brushSettings();
    else if (kind === "help") help();
    else about();
  }
  function renderModels() {
    var model = draft[slot], comfy = model.protocol === "comfyui", a1x = model.protocol === "a1x-flux";
    var choices = app.services.providers.protocols.map(function (p) { return [p.id, p.name]; });
    var root = ui.open({ title: t("模型配置", "Models"), beforeClose: discard, html:
      '<button class="button button-secondary a1x-quick-setup" data-a1x-setup><i class="fa-solid fa-microchip"></i><span><strong>' + t("配置 A1X Flux 双模型", "Set up both A1X Flux models") + '</strong><small>' + t("实时 256 / 1 步 · 高质量 512 / 4 步", "Preview 256 / 1 step · quality 512 / 4 steps") + '</small></span></button>' +
      '<div class="segmented model-tabs"><button data-slot-tab="quick" class="' + (slot === "quick" ? "is-active" : "") + '">' + t("实时快速", "Fast preview") + '</button><button data-slot-tab="quality" class="' + (slot === "quality" ? "is-active" : "") + '">' + t("高质量", "High quality") + '</button></div>' +
      '<div data-model-card="' + slot + '"><p class="model-intro">' + (slot === "quick" ? t("落笔后生成预览。选择快速、低步数模型。", "For previews after drawing. Choose a fast, low-step model.") : t("手动精绘成图，可以使用更慢、更精细的模型。", "Refine your artwork manually with a more detailed model.")) + '</p>' +
      '<div class="field-row">' + select("protocol", t("接口模式", "API format"), model.protocol, choices) + (a1x ? '<div class="field locked-field"><span>' + t("输入与画幅", "Input & aspect") + '</span><strong>' + t("草图 + 描述 · 1:1", "Sketch + prompt · 1:1") + '</strong></div>' : select("inputMode", t("输入方式", "Input"), model.inputMode, [["sketch", t("草图 + 描述", "Sketch + prompt")], ["text", t("仅描述", "Prompt only")]])) + '</div>' +
      input("endpoint", t("服务地址", "Base URL"), model.endpoint, "url", "https://… / http://192.168.…") +
      '<label class="field"><span>' + (a1x ? t("A1X 访问密码", "A1X access password") : "API Key") + '</span><div class="secret-input"><input name="apiKey" type="password" autocomplete="off" value="' + u.escapeHtml(model.apiKey) + '" placeholder="' + t("免鉴权的本地服务可留空", "Optional for local services") + '"><button data-toggle-secret aria-label="' + t("显示密钥", "Show key") + '"><i class="fa-regular fa-eye"></i></button><button data-paste-secret aria-label="' + t("粘贴密钥", "Paste key") + '"><i class="fa-regular fa-paste"></i></button></div></label>' +
      (comfy || a1x ? '' : input("model", t("模型 ID", "Model ID"), model.model, "text", t("填写服务提供的模型名称", "Model name from your provider"))) +
      (comfy ? textarea("workflow", t("ComfyUI API 工作流", "ComfyUI API workflow"), model.workflow, "{{prompt}}, {{image}}, {{seed}}, {{steps}}…") : '') +
      (a1x ? '<div class="a1x-profile"><div><i class="fa-solid fa-microchip"></i><span><strong>Flux.2 Klein 4B Distilled</strong><small>' + t("参考图编码精度固定 0.5 MP，画幅固定 1:1；1 / 2 步为实验预览，4 步推荐", "Reference precision is fixed at 0.5 MP and aspect at 1:1; 1 / 2 steps are experimental previews, 4 is recommended") + '</small></span></div><div class="field-row">' + select("width", t("生成尺寸", "Output size"), Number(model.width), [[256, "256 × 256"], [512, "512 × 512"]]) + select("steps", t("采样步数", "Sampling steps"), Number(model.steps), [[1, t("1 步 · 实验", "1 · experimental")], [2, t("2 步 · 实验", "2 · experimental")], [4, t("4 步 · 推荐", "4 · recommended")]]) + '</div></div>' : '') +
      '<details class="advanced"><summary>' + t("高级参数", "Advanced options") + '</summary><div class="field-row">' + (a1x ? '' : input("width", t("宽度", "Width"), model.width, "number") + input("height", t("高度", "Height"), model.height, "number") + input("steps", t("步数", "Steps"), model.steps, "number")) + input("timeoutMs", t("超时（毫秒）", "Timeout (ms)"), model.timeoutMs, "number") + '</div>' +
      (model.protocol === "openai-images" ? select("quality", t("生成质量", "Quality"), model.quality, [["low", t("快速", "Low")], ["medium", t("均衡", "Medium")], ["high", t("精细", "High")], ["auto", t("自动", "Auto")]]) : '') +
      textarea("customHeaders", t("自定义请求头 JSON", "Custom headers JSON"), model.customHeaders, '{"X-API-Key":"…"}') + '</details>' +
      '<p class="field-help">' + t("只向你配置的服务发送画面。局域网支持 HTTP；API Key 仅在保存后保存在当前应用。", "Images go only to your configured service. LAN HTTP is supported. Keys are stored locally when you save.") + '</p>' +
      '<button class="button button-secondary" data-test><i class="fa-solid fa-plug"></i>' + t("测试连接", "Test connection") + '</button><p class="connection-status" data-test-status></p></div>' + footer() });
    root.querySelector("[data-a1x-setup]").onclick = async function () {
      var hasExisting = Boolean(draft.quick.endpoint || draft.quality.endpoint);
      if (hasExisting) {
        var confirmed = await ui.confirm({ title: t("应用 A1X 推荐配置？", "Apply the A1X preset?"), message: t("会替换两个模型槽位的接口设置，但不会立即保存。", "This replaces both model slots, but does not save yet."), ok: t("应用配置", "Apply preset") });
        if (!confirmed) return;
      }
      draft.quick = app.services.providers.preset("a1x-flux", "quick");
      draft.quality = app.services.providers.preset("a1x-flux", "quality");
      slot = "quick"; renderModels();
    };
    root.querySelectorAll("[data-slot-tab]").forEach(function (button) { button.onclick = function () { slot = button.dataset.slotTab; renderModels(); }; });
    root.querySelectorAll("[name]").forEach(function (field) {
      function update() {
        draft[slot][field.name] = ["width", "height", "steps", "timeoutMs"].indexOf(field.name) >= 0 ? Number(field.value) : field.value;
        if (a1x && field.name === "width") draft[slot].height = Number(field.value);
      }
      if (field.name === "protocol") field.onchange = async function () {
        var previous = model.protocol, protocol = field.value;
        if (model.endpoint || model.apiKey || model.workflow) {
          var confirmed = await ui.confirm({ title: t("切换接口模式？", "Change API format?"), message: t("当前槽位的地址、密钥和接口参数会重置；另一个模型不受影响。", "This slot's URL, key and API options will reset. The other model stays unchanged."), ok: t("切换", "Change") });
          if (!confirmed) { field.value = previous; return; }
        }
        draft[slot] = app.services.providers.preset(protocol, slot); renderModels();
      };
      else { field.oninput = update; field.onchange = update; }
    });
    root.querySelector("[data-toggle-secret]").onclick = function (event) {
      var key = root.querySelector('[name="apiKey"]'), reveal = key.type === "password"; key.type = reveal ? "text" : "password";
      event.currentTarget.setAttribute("aria-label", reveal ? t("隐藏密钥", "Hide key") : t("显示密钥", "Show key"));
      event.currentTarget.innerHTML = '<i class="fa-regular fa-' + (reveal ? "eye-slash" : "eye") + '"></i>';
    };
    root.querySelector("[data-paste-secret]").onclick = ui.action(async function () {
      var key = root.querySelector('[name="apiKey"]'); key.value = String(await app.platform.hermit.clipboardRead()).trim();
      key.dispatchEvent(new Event("input", { bubbles: true }));
    });
    root.querySelector("[data-test]").onclick = ui.action(async function () {
      var status = root.querySelector("[data-test-status]"); status.textContent = t("连接中，不生成图片…", "Connecting without generating an image…");
      try { await app.services.providers.test(draft[slot]); status.textContent = a1x ? t("连接成功；Flux Klein 4B 图片能力可用。", "Connected. Flux Klein 4B image generation is available.") : t("连接成功；出图能力取决于所选模型。", "Connected. Image support depends on the selected model."); }
      catch (error) { status.textContent = t("连接失败，请检查地址与密钥。", "Connection failed. Check your URL and key."); throw error; }
    });
    root.querySelector("[data-cancel]").onclick = ui.requestClose;
    root.querySelector("[data-save]").onclick = ui.action(async function () {
      if (draft.quick.protocol === "a1x-flux" && draft.quality.protocol === "a1x-flux" && draft.quick.endpoint === draft.quality.endpoint) {
        if (draft.quick.apiKey && !draft.quality.apiKey) draft.quality.apiKey = draft.quick.apiKey;
        if (draft.quality.apiKey && !draft.quick.apiKey) draft.quick.apiKey = draft.quality.apiKey;
      }
      ["quick", "quality"].forEach(function (name) {
        var config = draft[name];
        if (!config.endpoint.trim()) return;
        u.validateEndpoint(config.endpoint); u.parseHeaders(config.customHeaders);
        if (config.protocol === "a1x-flux" && ([256, 512].indexOf(Number(config.width)) < 0 || Number(config.height) !== Number(config.width) || [1, 2, 4].indexOf(Number(config.steps)) < 0)) throw new Error(t("A1X Flux 仅支持 1:1 的 256 / 512 尺寸与 1 / 2 / 4 步", "A1X Flux supports only square 256 / 512 output and 1 / 2 / 4 steps"));
        if (!(config.width >= 256 && config.width <= 2048 && config.height >= 256 && config.height <= 2048 && config.steps >= 1 && config.steps <= 150 && config.timeoutMs >= 5000 && config.timeoutMs <= 300000)) throw new Error(t("尺寸需为 256–2048，步数为 1–150，超时为 5–300 秒", "Use dimensions 256–2048, steps 1–150, and timeout 5–300 seconds"));
      });
      await app.services.store.saveConfig(draft); ui.close(); app.events.emit("config:changed"); ui.toast(t("两个模型的设置已保存", "Both model settings saved"));
    });
  }
  function workSettings() {
    var state = app.state;
    var usesA1x = app.config.quick.protocol === "a1x-flux" || app.config.quality.protocol === "a1x-flux";
    var root = ui.open({ mode: "center", title: t("作品设置", "Artwork settings"), html:
      textarea("negativePrompt", t("不希望出现的内容", "Negative prompt"), state.negativePrompt, t("例如：模糊、变形、低质量", "For example: blurry, distorted, low quality")) +
      range("strength", t("重绘 / 控制强度", "Denoise / control strength"), Math.round(state.strength * 100), 0, 100, "%") +
      (usesA1x ? range("referenceStrength", t("参考图强度（近似）", "Reference strength (approx.)"), Math.round(state.referenceStrength * 100), 0, 200, "%") + '<p class="field-help compact-help">' + t("A1X 通过参考图 latent 缩放近似控制；100% 为默认，0% 忽略草图。", "A1X approximates this by scaling the reference latent. 100% is default; 0% ignores the sketch.") + '</p>' : '') +
      '<div class="field-row">' + input("seed", t("随机种子", "Seed"), state.seed, "number", t("-1 为随机", "-1 for random")) + input("autoDelayMs", t("笔刷等待（毫秒）", "Brush wait (ms)"), state.autoDelayMs, "number") + '</div>' +
      '<label class="switch-row"><span><strong>' + t("继续绘制", "Continue drawing") + '</strong><small>' + t("把上次成图和新笔触一起发给模型", "Send the last result with new strokes") + '</small></span><input name="includeResult" type="checkbox"' + (state.includeResult ? " checked" : "") + '></label>' +
      range("resultOpacity", t("成图叠加透明度", "Result opacity"), Math.round(state.resultOpacity * 100), 10, 100, "%") + footer(t("应用", "Apply")) });
    ranges(root);
    root.querySelector("[data-cancel]").onclick = ui.close;
    root.querySelector("[data-save]").onclick = ui.action(async function () {
      var seed = Number(root.querySelector('[name="seed"]').value), delay = Number(root.querySelector('[name="autoDelayMs"]').value);
      if (!Number.isSafeInteger(seed) || seed < -1 || seed > 9007199254740991 || delay < 400 || delay > 5000) throw new Error(t("种子需为 -1 至 9007199254740991 的安全整数；笔刷等待为 400–5000 毫秒", "Seed must be a safe integer from -1 to 9007199254740991; brush wait must be 400–5000 ms"));
      state.negativePrompt = root.querySelector('[name="negativePrompt"]').value.trim();
      state.seed = seed; state.strength = Number(root.querySelector('[name="strength"]').value) / 100; state.autoDelayMs = delay;
      if (usesA1x) state.referenceStrength = Number(root.querySelector('[name="referenceStrength"]').value) / 100;
      state.resultOpacity = Number(root.querySelector('[name="resultOpacity"]').value) / 100;
      state.includeResult = root.querySelector('[name="includeResult"]').checked;
      app.services.store.scheduleCanvasSave(); app.events.emit("result:filter"); ui.close(); ui.toast(t("作品设置已应用", "Artwork settings applied"));
    });
  }
  function adjustmentSettings() {
    var state = app.state;
    var root = ui.open({ title: t("调色", "Color adjustments"), html:
      '<p class="field-help">' + t("只改变成图的显示与导出效果，不会破坏原始图片。", "Changes the displayed and exported result without altering the original image.") + '</p>' +
      range("resultBrightness", t("亮度", "Brightness"), state.resultBrightness, 40, 180, "%") +
      range("resultContrast", t("对比度", "Contrast"), state.resultContrast, 40, 180, "%") +
      range("resultSaturation", t("饱和度", "Saturation"), state.resultSaturation, 0, 220, "%") +
      range("resultHue", t("色相", "Hue"), state.resultHue, -180, 180, "°") +
      range("resultGlow", t("梦幻辉光", "Dream glow"), state.resultGlow, 0, 100, "%") +
      range("resultClarity", t("清晰度", "Clarity"), state.resultClarity, -50, 100, "%") +
      '<button class="button button-secondary compact-action" data-reset><i class="fa-solid fa-arrow-rotate-left"></i>' + t("恢复默认", "Reset") + '</button>' + footer(t("应用", "Apply")) });
    ranges(root);
    root.querySelector("[data-reset]").onclick = function () {
      ["resultBrightness", "resultContrast", "resultSaturation", "resultHue", "resultGlow", "resultClarity"].forEach(function (name) {
        var field = root.querySelector('[name="' + name + '"]'); field.value = ["resultHue", "resultGlow", "resultClarity"].indexOf(name) >= 0 ? 0 : 100; field.dispatchEvent(new Event("input"));
      });
    };
    root.querySelector("[data-cancel]").onclick = ui.close;
    root.querySelector("[data-save]").onclick = function () {
      ["resultBrightness", "resultContrast", "resultSaturation", "resultHue", "resultGlow", "resultClarity"].forEach(function (name) { state[name] = Number(root.querySelector('[name="' + name + '"]').value); });
      app.services.store.scheduleCanvasSave(); app.events.emit("result:filter"); ui.close(); ui.toast(t("调色已应用", "Color adjustments applied"));
    };
  }
  function parseColor(value) {
    var match = /^#?([0-9a-f]{6})$/i.exec(String(value || "").trim());
    if (!match) return null;
    var number = parseInt(match[1], 16);
    return { r: number >> 16, g: number >> 8 & 255, b: number & 255 };
  }
  function hexColor(rgb) { return "#" + [rgb.r, rgb.g, rgb.b].map(function (value) { return ("0" + Math.max(0, Math.min(255, Number(value))).toString(16)).slice(-2); }).join(""); }
  function openColor(target) {
    var isBackground = target === "background", current = isBackground ? app.state.background : app.state.color;
    var rgb = parseColor(current) || { r: 56, g: 169, b: 232 };
    var palette = ["#1f2937", "#ffffff", "#ef476f", "#ff9f1c", "#ffd166", "#2ec4b6", "#38a9e8", "#705ed7"];
    var root = ui.open({ mode: "center", title: isBackground ? t("画布底色", "Canvas background") : t("画笔颜色", "Stroke color"), html:
      '<div class="color-picker-head"><span class="color-preview" data-color-preview></span><label class="field color-hex"><span>' + t("颜色值", "Color") + '</span><input name="colorHex" value="' + current + '" maxlength="7" autocapitalize="off" spellcheck="false"></label></div>' +
      '<div class="color-palette">' + palette.map(function (color) { return '<button type="button" data-palette="' + color + '" aria-label="' + color + '"></button>'; }).join("") + '</div>' +
      range("red", t("红", "Red"), rgb.r, 0, 255, "") + range("green", t("绿", "Green"), rgb.g, 0, 255, "") + range("blue", t("蓝", "Blue"), rgb.b, 0, 255, "") + footer(t("应用", "Apply")) });
    ranges(root);
    root.querySelectorAll("[data-palette]").forEach(function (button) { button.style.backgroundColor = button.dataset.palette; });
    function update(next) {
      rgb = next; var hex = hexColor(rgb); root.querySelector('[name="colorHex"]').value = hex; root.querySelector("[data-color-preview]").style.backgroundColor = hex;
      [["red", "r"], ["green", "g"], ["blue", "b"]].forEach(function (pair) { var field = root.querySelector('[name="' + pair[0] + '"]'); field.value = rgb[pair[1]]; field.dispatchEvent(new Event("input")); });
    }
    root.querySelector("[data-color-preview]").style.backgroundColor = current;
    root.querySelectorAll('[name="red"],[name="green"],[name="blue"]').forEach(function (field) { field.oninput = function () { rgb = { r: Number(root.querySelector('[name="red"]').value), g: Number(root.querySelector('[name="green"]').value), b: Number(root.querySelector('[name="blue"]').value) }; root.querySelector('[name="colorHex"]').value = hexColor(rgb); root.querySelector("[data-color-preview]").style.backgroundColor = hexColor(rgb); root.querySelector('[data-range-label="' + field.name + '"]').textContent = field.value; }; });
    root.querySelector('[name="colorHex"]').onchange = function (event) { var value = parseColor(event.target.value); if (value) update(value); else event.target.value = hexColor(rgb); };
    root.querySelectorAll("[data-palette]").forEach(function (button) { button.onclick = function () { update(parseColor(button.dataset.palette)); }; });
    root.querySelector("[data-cancel]").onclick = ui.close;
    root.querySelector("[data-save]").onclick = function () {
      var value = parseColor(root.querySelector('[name="colorHex"]').value); if (!value) { ui.toast(t("请输入 6 位十六进制颜色", "Enter a 6-digit hex color"), "error"); return; }
      if (isBackground) { app.state.background = hexColor(value); app.components.canvas.render(); app.components.canvas.commit(); }
      else { app.state.color = hexColor(value); app.services.store.scheduleCanvasSave(); }
      app.events.emit("color:changed"); ui.close();
    };
  }
  function preferences() {
    var prefs = app.config.preferences;
    var root = ui.open({ title: t("软件设置", "Preferences"), html:
      '<div class="section-label">' + t("外观", "Appearance") + '</div>' + select("theme", t("主题", "Theme"), prefs.theme, [["system", t("跟随系统", "System")], ["light", t("浅色", "Light")], ["dark", t("深色", "Dark")]]) +
      '<div class="section-label">' + t("语言", "Language") + '</div>' + select("language", t("界面语言", "Interface language"), prefs.language, [["zh", "简体中文"], ["en", "English"]]) +
      '<p class="field-help">' + t("设置会保存在此设备，不影响作品的提示词与模型配置。", "Saved on this device. Artwork prompts and model settings stay the same.") + '</p>' + footer() });
    root.querySelector("[data-cancel]").onclick = ui.close;
    root.querySelector("[data-save]").onclick = ui.action(async function () {
      var next = u.copy(app.config); next.preferences = { theme: root.querySelector('[name="theme"]').value, language: root.querySelector('[name="language"]').value };
      await app.services.store.saveConfig(next); app.i18n.theme(); app.i18n.dom(); app.events.emit("preferences:changed"); ui.close(); ui.toast(t("软件设置已保存", "Preferences saved"));
    });
  }
  function brushSettings() {
    var root = ui.open({ mode: "center", title: t("画笔选项", "Brush options"), html: range("opacity", t("笔触不透明度", "Stroke opacity"), Math.round(app.state.opacity * 100), 10, 100, "%") + '<p class="field-help">' + t("仅作用于之后画下的笔触。涂色笔保留轻透的叠色效果。", "Applies to new strokes. The brush retains a soft, translucent finish.") + '</p>' + footer(t("应用", "Apply")) });
    ranges(root); root.querySelector("[data-cancel]").onclick = ui.close;
    root.querySelector("[data-save]").onclick = function () { app.state.opacity = Number(root.querySelector('[name="opacity"]').value) / 100; app.services.store.scheduleCanvasSave(); ui.close(); };
  }
  function help() {
    ui.open({ title: t("使用说明", "How to draw"), html: '<div class="help-copy"><h3>' + t("从草图到成图", "From sketch to artwork") + '</h3><ol><li>' +
      t("在顶部写下画面描述，使用铅笔勾轮廓、涂色笔铺色；图片工具可以导入参考图。", "Describe your idea above the canvas. Draw outlines with Pencil, add color with Brush, or import a reference image.") + '</li><li>' +
      t("先在右上角菜单配置模型。自动模式会在落笔后等待片刻再生成；生成期间可以继续画，最新画面会排队。", "Configure models in the menu. Auto mode waits briefly after a stroke. Keep drawing while a request runs; the latest sketch is queued.") + '</li><li>' +
      t("用画布上方滑竿调整绘画内容层的显示透明度，随时对照下方成图；高质量按钮用于手动精绘。", "Use the slider above the canvas to fade the drawing layer and compare it with the result below. Use Refine for a high-quality render.") + '</li><li>' +
      t("作品会自动保存在历史中。打开历史可继续编辑或复制作品；新建时会先保存当前作品。", "Artwork is saved automatically. Continue or duplicate it from Your artwork. Creating a new work saves the current one first.") + '</li></ol><h3>' +
      t("局部与选择", "Mask & selection") + '</h3><p>' + t("局部工具用粉色标记重绘区域，仅支持有蒙版能力的 OpenAI Images 和 SD WebUI 接口。选择模式下，轻点元素会单选；从空白处拖出选择框，碰到的元素都会被选中。直接拖动单个元素只移动它，框选后再拖动选区内的元素或空隙会整体移动；点击成组后，轻点或框到组内任一元素都会选中整组。四角手柄与双指捏合用于等比缩放。", "The pink mask marks areas to repaint in supported OpenAI Images and SD WebUI APIs. In Select mode, tap an element to select only it, or drag a box from empty space; every touched element is selected. Drag one element to move only it; after a box selection, drag an element or empty space inside the selection to move the selection. After grouping, tapping or touching any member with the selection box selects the whole group. Use corner handles or a two-finger pinch to scale proportionally.") + '</p><h3>' +
      t("连接自己的模型", "Connect your model") + '</h3><p>' + t("两个模型独立配置。A1X Flux 模式直接使用稳定任务接口，不需要粘贴工作流；参考图按 0.5 MP 编码，画幅固定 1:1。局域网地址支持 HTTP，公网需要 HTTPS。通用 ComfyUI 模式仍可导入带占位符的 API 工作流。", "Configure two independent models. A1X Flux uses its stable job API directly, with no workflow JSON required; references use 0.5 MP and output is fixed at 1:1. LAN HTTP is supported, while public services require HTTPS. Generic ComfyUI workflows remain available.") + '</p><h3>' +
      t("保存与导出", "Save & export") + '</h3><p>' + t("历史保留可编辑的草稿和原始成图。当前宿主支持导出通用 SVG 预览；以文件返回的模型图片还可原格式导出。停止等待只忽略本次结果，不保证服务端取消或停止计费。", "History preserves editable sketches and original results. Export an SVG preview, or the original model image when the service returns a file. Dismiss ignores a result; it does not guarantee server cancellation or stop billing.") + '</p></div>' });
  }
  function about() {
    ui.open({ mode: "center", title: t("软件信息", "About VibeDraw"), html: '<div class="about-brand"><span class="brand-mark">V</span><div><strong>VibeDraw</strong><div class="about-meta">v' + app.version + ' · MIT</div></div></div><p>' + t("画下灵感，与 AI 一起完成。", "Sketch an idea. Create with AI.") + '</p><p class="about-meta">' + t("原生 HTML / CSS / JavaScript 开源 happ。模型由你选择，作品保存在当前应用。", "An open-source HTML / CSS / JavaScript happ. Your models, your artwork, stored in this app.") + '</p><p class="about-meta">© 2026 zhyuzh · Font Awesome Free (Hermit)</p>' });
  }
  app.components.settings = { init: init, open: open, openColor: openColor };
})(window.vibedraw);
