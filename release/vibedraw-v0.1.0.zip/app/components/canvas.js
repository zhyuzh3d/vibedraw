(function (app) {
  "use strict";

  var state = app.state;
  var canvas, context;
  var drawingObject = null;
  var dragging = null;
  var imageCache = {};
  var WIDTH = 768;

  function init() {
    canvas = document.getElementById("draft-canvas");
    context = canvas.getContext("2d");
    bindInput();
    render();
    resetHistory();
  }
  function bindInput() {
    if (window.PointerEvent) {
      canvas.addEventListener("pointerdown", start);
      canvas.addEventListener("pointermove", move);
      canvas.addEventListener("pointerup", end);
      canvas.addEventListener("pointercancel", end);
    } else {
      canvas.addEventListener("mousedown", start);
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", end);
      canvas.addEventListener("touchstart", start, { passive: false });
      canvas.addEventListener("touchmove", move, { passive: false });
      canvas.addEventListener("touchend", end, { passive: false });
    }
  }
  function point(event) {
    var source = event.touches && event.touches[0] || event.changedTouches && event.changedTouches[0] || event;
    var rect = canvas.getBoundingClientRect();
    return { x: (source.clientX - rect.left) * WIDTH / rect.width, y: (source.clientY - rect.top) * WIDTH / rect.height };
  }
  function start(event) {
    if (state.busy && state.tool !== "select") return;
    event.preventDefault();
    var p = point(event);
    if (state.tool === "select") {
      var selected = hitTest(p);
      state.selectedId = selected ? selected.id : "";
      dragging = selected ? { object: selected, x: p.x, y: p.y, moved: false } : null;
      render();
      app.events.emit("selection", state.selectedId);
      return;
    }
    state.selectedId = "";
    drawingObject = {
      id: app.utils.id("stroke"),
      type: "stroke",
      tool: state.tool,
      color: state.tool === "mask" ? "#ee4f85" : state.color,
      width: state.tool === "pencil" ? Math.max(1, Math.round(state.size / 3)) : state.tool === "eraser" ? Math.max(8, state.size * 1.6) : state.size,
      opacity: state.tool === "brush" ? Math.min(state.opacity, 0.42) : state.tool === "mask" ? 0.55 : state.opacity,
      points: [p]
    };
    state.objects.push(drawingObject);
    render();
  }
  function move(event) {
    if (!drawingObject && !dragging) return;
    event.preventDefault();
    var p = point(event);
    if (drawingObject) {
      var points = drawingObject.points, last = points[points.length - 1];
      if (distance(last, p) >= 1.5) points.push(p);
      render();
      return;
    }
    var dx = p.x - dragging.x, dy = p.y - dragging.y;
    if (Math.abs(dx) + Math.abs(dy) < 0.25) return;
    translate(dragging.object, dx, dy);
    dragging.x = p.x; dragging.y = p.y; dragging.moved = true;
    render();
  }
  function end(event) {
    if (event && event.preventDefault && (drawingObject || dragging)) event.preventDefault();
    var changed = Boolean(drawingObject || dragging && dragging.moved);
    drawingObject = null;
    dragging = null;
    if (changed) commit();
  }
  function translate(object, dx, dy) {
    if (object.type === "stroke") object.points.forEach(function (p) { p.x += dx; p.y += dy; });
    else { object.x += dx; object.y += dy; }
  }
  function distance(a, b) { var dx = a.x - b.x, dy = a.y - b.y; return Math.sqrt(dx * dx + dy * dy); }
  function segmentDistance(pointValue, a, b) {
    var dx = b.x - a.x, dy = b.y - a.y;
    if (!dx && !dy) return distance(pointValue, a);
    var t = ((pointValue.x - a.x) * dx + (pointValue.y - a.y) * dy) / (dx * dx + dy * dy);
    t = Math.max(0, Math.min(1, t));
    return distance(pointValue, { x: a.x + t * dx, y: a.y + t * dy });
  }
  function hitTest(p) {
    for (var index = state.objects.length - 1; index >= 0; index -= 1) {
      var object = state.objects[index];
      if (object.type === "image") {
        if (p.x >= object.x && p.x <= object.x + object.width && p.y >= object.y && p.y <= object.y + object.height) return object;
      } else {
        for (var pointIndex = 1; pointIndex < object.points.length; pointIndex += 1) {
          if (segmentDistance(p, object.points[pointIndex - 1], object.points[pointIndex]) <= object.width / 2 + 12) return object;
        }
      }
    }
    return null;
  }
  function bounds(object) {
    if (object.type === "image") return { x: object.x, y: object.y, width: object.width, height: object.height };
    var xs = object.points.map(function (p) { return p.x; }), ys = object.points.map(function (p) { return p.y; });
    var pad = object.width / 2 + 5, left = Math.min.apply(null, xs) - pad, top = Math.min.apply(null, ys) - pad;
    return { x: left, y: top, width: Math.max.apply(null, xs) - left + pad, height: Math.max.apply(null, ys) - top + pad };
  }
  function drawStroke(ctx, object, maskPreview) {
    if (!object.points.length) return;
    ctx.save();
    ctx.globalCompositeOperation = object.tool === "eraser" ? "destination-out" : "source-over";
    ctx.globalAlpha = object.opacity;
    ctx.strokeStyle = object.tool === "mask" && maskPreview ? "#ee4f85" : object.color;
    ctx.lineWidth = object.width;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(object.points[0].x, object.points[0].y);
    for (var index = 1; index < object.points.length; index += 1) ctx.lineTo(object.points[index].x, object.points[index].y);
    if (object.points.length === 1) ctx.lineTo(object.points[0].x + 0.1, object.points[0].y + 0.1);
    ctx.stroke();
    ctx.restore();
  }
  function loadImage(src) {
    if (!src) return Promise.resolve(null);
    if (imageCache[src] && imageCache[src].complete) return Promise.resolve(imageCache[src]);
    return new Promise(function (resolve) {
      var image = imageCache[src] || new Image();
      imageCache[src] = image;
      image.onload = function () { resolve(image); render(); };
      image.onerror = function () { resolve(null); };
      if (!image.src) image.src = src;
    });
  }
  function drawImageObject(ctx, object) {
    var image = imageCache[object.src || object.url];
    if (image && image.complete && image.naturalWidth) ctx.drawImage(image, object.x, object.y, object.width, object.height);
    else loadImage(object.src || object.url);
  }
  function render() {
    if (!context) return;
    context.clearRect(0, 0, WIDTH, WIDTH);
    state.objects.forEach(function (object) {
      if (object.type === "stroke") drawStroke(context, object, true);
      else drawImageObject(context, object);
    });
    var selected = selectedObject();
    if (selected) {
      var box = bounds(selected);
      context.save();
      context.strokeStyle = "#ee4f85";
      context.lineWidth = 2;
      context.setLineDash([9, 7]);
      context.strokeRect(box.x, box.y, box.width, box.height);
      context.restore();
    }
    document.getElementById("stage-background").style.background = state.background;
    canvas.style.opacity = String(state.opacity);
    app.events.emit("canvas:rendered", { objects: state.objects.length });
  }
  function selectedObject() {
    return state.objects.find(function (object) { return object.id === state.selectedId; }) || null;
  }
  function snapshot() {
    return JSON.stringify({ objects: state.objects.map(function (object) {
      var value = app.utils.copy(object); delete value._image; return value;
    }), background: state.background });
  }
  function restore(value) {
    var data = app.utils.parseJson(value, { objects: [], background: "#ffffff" });
    state.objects = data.objects || [];
    state.background = data.background || "#ffffff";
    state.selectedId = "";
    state.objects.forEach(function (object) { if (object.type === "image") loadImage(object.src || object.url); });
    render();
    app.events.emit("history", { undo: state.history.length > 1, redo: state.future.length > 0 });
    app.services.store.scheduleCanvasSave();
  }
  function resetHistory() { state.history = [snapshot()]; state.future = []; app.events.emit("history", { undo: false, redo: false }); }
  function commit() {
    var next = snapshot();
    if (state.history[state.history.length - 1] !== next) state.history.push(next);
    if (state.history.length > 80) state.history.shift();
    state.future = [];
    app.events.emit("history", { undo: state.history.length > 1, redo: false });
    app.events.emit("selection", state.selectedId);
    app.services.store.scheduleCanvasSave();
    app.services.imageEngine.schedule();
  }
  function undo() {
    if (state.history.length <= 1) return;
    state.future.push(state.history.pop());
    restore(state.history[state.history.length - 1]);
  }
  function redo() {
    if (!state.future.length) return;
    var value = state.future.pop();
    state.history.push(value);
    restore(value);
  }
  function removeSelected() {
    if (!state.selectedId) return;
    state.objects = state.objects.filter(function (object) { return object.id !== state.selectedId; });
    state.selectedId = "";
    render(); commit();
  }
  function clear() {
    if (!state.objects.length) return;
    state.objects = [];
    state.selectedId = "";
    render(); commit();
  }
  function moveLayer(direction) {
    var index = state.objects.findIndex(function (object) { return object.id === state.selectedId; });
    var target = index + direction;
    if (index < 0 || target < 0 || target >= state.objects.length) return;
    var object = state.objects.splice(index, 1)[0];
    state.objects.splice(target, 0, object);
    render(); commit();
  }
  async function addImage(file) {
    if (!file || !file.url) return;
    var image = await loadImage(file.url);
    if (!image) throw new Error("无法读取所选图片");
    var scale = Math.min(WIDTH * 0.72 / image.naturalWidth, WIDTH * 0.72 / image.naturalHeight, 1);
    var width = image.naturalWidth * scale, height = image.naturalHeight * scale;
    var object = {
      id: app.utils.id("image"), type: "image", url: file.url, src: file.url,
      logicalFileId: file.logicalFileId || "", name: file.name || "image",
      x: (WIDTH - width) / 2, y: (WIDTH - height) / 2, width: width, height: height
    };
    state.objects.push(object);
    state.selectedId = object.id;
    state.tool = "select";
    render(); commit();
    app.events.emit("tool", "select");
  }
  function hasMask() { return state.objects.some(function (object) { return object.type === "stroke" && object.tool === "mask"; }); }
  async function drawObjectList(targetContext, includeMask) {
    for (var index = 0; index < state.objects.length; index += 1) {
      var object = state.objects[index];
      if (object.type === "stroke") {
        if (object.tool === "mask" && !includeMask) continue;
        drawStroke(targetContext, object, false);
      } else {
        var image = await loadImage(object.src || object.url);
        if (image) targetContext.drawImage(image, object.x, object.y, object.width, object.height);
      }
    }
  }
  async function composeInput() {
    var output = document.createElement("canvas");
    output.width = WIDTH; output.height = WIDTH;
    var ctx = output.getContext("2d");
    ctx.fillStyle = state.background;
    ctx.fillRect(0, 0, WIDTH, WIDTH);
    if (state.includeResult && state.result && state.result.src) {
      var result = await loadImage(state.result.src);
      if (result) {
        ctx.save(); ctx.globalAlpha = state.resultOpacity; ctx.drawImage(result, 0, 0, WIDTH, WIDTH); ctx.restore();
      }
    }
    await drawObjectList(ctx, false);
    return output.toDataURL("image/png");
  }
  function composeMask(openAiAlpha) {
    if (!hasMask()) return null;
    var output = document.createElement("canvas");
    output.width = WIDTH; output.height = WIDTH;
    var ctx = output.getContext("2d");
    if (openAiAlpha) {
      ctx.fillStyle = "white"; ctx.fillRect(0, 0, WIDTH, WIDTH);
      ctx.globalCompositeOperation = "destination-out";
    } else {
      ctx.fillStyle = "black"; ctx.fillRect(0, 0, WIDTH, WIDTH);
      ctx.strokeStyle = "white";
    }
    state.objects.filter(function (object) { return object.type === "stroke" && object.tool === "mask"; }).forEach(function (object) {
      var copy = app.utils.copy(object); copy.color = "white"; copy.opacity = 1; copy.tool = "brush"; drawStroke(ctx, copy, false);
    });
    return output.toDataURL("image/png");
  }
  async function exportImage() {
    var src = await composeOutput();
    var anchor = document.createElement("a");
    anchor.download = "vibedraw-" + new Date().toISOString().replace(/[:.]/g, "-") + ".png";
    anchor.href = src;
    document.body.appendChild(anchor); anchor.click(); anchor.remove();
  }
  async function composeOutput() {
    var output = document.createElement("canvas"); output.width = WIDTH; output.height = WIDTH;
    var ctx = output.getContext("2d"); ctx.fillStyle = state.background; ctx.fillRect(0, 0, WIDTH, WIDTH);
    if (state.result && state.result.src) {
      var image = await loadImage(state.result.src);
      if (image) ctx.drawImage(image, 0, 0, WIDTH, WIDTH);
    } else await drawObjectList(ctx, false);
    return output.toDataURL("image/png");
  }
  function load(saved) {
    if (!saved) return;
    ["prompt", "negativePrompt", "background", "color", "size", "opacity", "strength", "seed", "autoGenerate", "includeResult", "resultOpacity"].forEach(function (key) {
      if (saved[key] !== undefined) state[key] = saved[key];
    });
    state.objects = saved.objects || [];
    state.objects.forEach(function (object) {
      if (object.type === "image" && object.url) { object.src = object.url; loadImage(object.url); }
    });
    render(); resetHistory();
  }

  app.components.canvas = {
    init: init,
    render: render,
    commit: commit,
    undo: undo,
    redo: redo,
    removeSelected: removeSelected,
    clear: clear,
    moveLayer: moveLayer,
    addImage: addImage,
    composeInput: composeInput,
    composeMask: composeMask,
    composeOutput: composeOutput,
    exportImage: exportImage,
    load: load,
    hasMask: hasMask
  };
})(window.vibedraw);
