(function (app) {
  "use strict";

  var labels = {
    pencil: { text: "铅笔", icon: "pencil" },
    brush: { text: "涂色", icon: "paintbrush" },
    eraser: { text: "擦除", icon: "eraser" },
    select: { text: "选择", icon: "arrow-pointer" },
    mask: { text: "局部蒙版", icon: "mask-face" }
  };

  function init() {
    bindTools();
    bindOptions();
    bindActions();
    bindGeneration();
    syncAll();
    resizeStage();
    window.addEventListener("resize", resizeStage);
  }
  function resizeStage() {
    var frame = document.getElementById("stage-frame");
    if (!window.CSS || !CSS.supports || !CSS.supports("aspect-ratio", "1 / 1")) frame.style.height = frame.offsetWidth + "px";
  }
  function bindTools() {
    document.querySelectorAll("[data-tool]").forEach(function (button) {
      button.addEventListener("click", function () { setTool(button.dataset.tool); });
    });
    app.events.on("tool", setTool);
    app.events.on("selection", syncSelection);
  }
  function setTool(tool) {
    if (!labels[tool]) return;
    app.state.tool = tool;
    document.querySelectorAll("[data-tool]").forEach(function (button) { button.classList.toggle("is-active", button.dataset.tool === tool); });
    var label = labels[tool], current = document.getElementById("active-tool-label");
    current.innerHTML = '<i class="fa-solid fa-' + label.icon + '" aria-hidden="true"></i><span>' + label.text + '</span>';
    document.getElementById("draft-canvas").style.cursor = tool === "select" ? "grab" : "crosshair";
    syncSelection(app.state.selectedId);
  }
  function bindOptions() {
    var color = document.getElementById("stroke-color"), size = document.getElementById("brush-size"), background = document.getElementById("background-color"), prompt = document.getElementById("prompt-input");
    color.addEventListener("input", function () { app.state.color = color.value; app.services.store.scheduleCanvasSave(); });
    size.addEventListener("input", function () { app.state.size = Number(size.value); app.services.store.scheduleCanvasSave(); });
    background.addEventListener("input", function () {
      app.state.background = background.value;
      app.components.canvas.render();
      app.components.canvas.commit();
    });
    prompt.addEventListener("input", function () {
      app.state.prompt = prompt.value;
      autoSizePrompt(prompt);
      app.services.store.scheduleCanvasSave();
      app.services.imageEngine.schedule();
    });
    document.getElementById("prompt-more").addEventListener("click", function () { app.components.settings.open("canvas"); });
    document.getElementById("add-image").addEventListener("click", app.components.ui.action(addImage));
    document.getElementById("fallback-file").addEventListener("change", importFallbackFile);
  }
  async function addImage() {
    var result = await app.platform.hermit.pickImage();
    if (result) {
      if (!result.cancelled) await app.components.canvas.addImage(result);
      return;
    }
    document.getElementById("fallback-file").click();
  }
  function importFallbackFile(event) {
    var file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    if (!/^image\/(png|jpeg|webp)$/i.test(file.type)) { app.components.ui.toast("请选择 PNG、JPEG 或 WebP 图片", "error"); return; }
    var reader = new FileReader();
    reader.onload = function () {
      app.components.canvas.addImage({ url: reader.result, name: file.name, logicalFileId: "" }).catch(function (error) { app.events.emit("error", error); });
    };
    reader.readAsDataURL(file);
  }
  function autoSizePrompt(field) { field.style.height = "auto"; field.style.height = Math.min(96, field.scrollHeight) + "px"; }
  function bindActions() {
    document.getElementById("open-settings").addEventListener("click", function () { app.components.settings.open("models"); });
    document.getElementById("open-help").addEventListener("click", function () { app.components.settings.open("about"); });
    document.getElementById("undo").addEventListener("click", app.components.canvas.undo);
    document.getElementById("redo").addEventListener("click", app.components.canvas.redo);
    document.getElementById("delete-selected").addEventListener("click", app.components.canvas.removeSelected);
    document.getElementById("layer-down").addEventListener("click", function () { app.components.canvas.moveLayer(-1); });
    document.getElementById("layer-up").addEventListener("click", function () { app.components.canvas.moveLayer(1); });
    document.getElementById("clear-canvas").addEventListener("click", function () {
      if (window.confirm("清空全部草稿笔触和导入图片？生成结果会保留。")) app.components.canvas.clear();
    });
    document.getElementById("auto-toggle").addEventListener("click", function () {
      app.state.autoGenerate = !app.state.autoGenerate;
      syncAuto();
      app.services.store.scheduleCanvasSave();
      app.components.ui.toast(app.state.autoGenerate ? "已开启落笔后自动生成" : "已关闭自动生成");
    });
    document.getElementById("generate-quick").addEventListener("click", function () { app.services.imageEngine.run("quick", false); });
    document.getElementById("generate-quality").addEventListener("click", function () { app.services.imageEngine.run("quality", false); });
    document.getElementById("export-image").addEventListener("click", app.components.ui.action(app.components.canvas.exportImage));
    app.events.on("history", function (value) {
      document.getElementById("undo").disabled = !value.undo;
      document.getElementById("redo").disabled = !value.redo;
    });
    document.addEventListener("keydown", function (event) {
      if (document.getElementById("modal-layer").hidden === false) return;
      var modifier = event.ctrlKey || event.metaKey;
      if (modifier && String(event.key).toLowerCase() === "z") { event.preventDefault(); event.shiftKey ? app.components.canvas.redo() : app.components.canvas.undo(); return; }
      if (modifier && String(event.key).toLowerCase() === "y") { event.preventDefault(); app.components.canvas.redo(); return; }
      if (event.key === "Delete" || event.key === "Backspace" && app.state.tool === "select") { event.preventDefault(); app.components.canvas.removeSelected(); return; }
      var shortcut = { p: "pencil", b: "brush", e: "eraser", v: "select", m: "mask" }[String(event.key).toLowerCase()];
      if (shortcut && !/input|textarea|select/i.test(document.activeElement.tagName)) setTool(shortcut);
    });
  }
  function bindGeneration() {
    app.events.on("generation:start", function (detail) {
      document.getElementById("stage-busy").hidden = false;
      document.getElementById("busy-label").textContent = detail.slot === "quality" ? "正在精绘高质量画面" : "正在生成实时预览";
      document.getElementById("generate-quick").disabled = true;
      document.getElementById("generate-quality").disabled = true;
      status("模型正在处理当前画面…");
    });
    app.events.on("generation:done", function (result) {
      var image = document.getElementById("result-image");
      image.onload = function () {
        image.hidden = false;
        document.getElementById("stage-empty").hidden = true;
        document.getElementById("export-image").disabled = false;
      };
      image.src = result.src;
      image.style.opacity = String(app.state.resultOpacity);
      image.style.filter = app.components.canvas.resultFilter();
      document.getElementById("stage-badge").textContent = result.slot === "quality" ? "高质量结果" : "实时预览";
      status("生成完成 · " + new Date(result.createdAt).toLocaleTimeString());
      app.components.ui.toast(result.slot === "quality" ? "高质量画面已完成" : "实时预览已更新");
    });
    app.events.on("generation:error", function (error) { status("生成失败"); app.events.emit("error", error); });
    app.events.on("generation:idle", function () {
      document.getElementById("stage-busy").hidden = true;
      document.getElementById("generate-quick").disabled = false;
      document.getElementById("generate-quality").disabled = false;
    });
    app.events.on("needs-config", function (slot) { app.components.settings.open("models"); status("请先配置" + (slot === "quick" ? "实时" : "高质量") + "模型"); });
    app.events.on("status", status);
    app.events.on("error", function (error) { app.components.ui.toast(app.utils.cleanError(error), "error"); });
    app.events.on("config:changed", function () { status("模型设置已更新"); });
    app.events.on("result:filter", function (value) {
      var image = document.getElementById("result-image");
      image.style.filter = value;
      image.style.opacity = String(app.state.resultOpacity);
    });
  }
  function syncSelection(selectedId) {
    var disabled = !selectedId;
    document.getElementById("delete-selected").disabled = disabled;
    document.getElementById("layer-up").disabled = disabled;
    document.getElementById("layer-down").disabled = disabled;
  }
  function syncAuto() {
    var button = document.getElementById("auto-toggle");
    button.setAttribute("aria-pressed", String(app.state.autoGenerate));
    button.querySelector("span").textContent = app.state.autoGenerate ? "自动" : "手动";
  }
  function syncAll() {
    document.getElementById("stroke-color").value = app.state.color;
    document.getElementById("brush-size").value = app.state.size;
    document.getElementById("background-color").value = app.state.background;
    document.getElementById("prompt-input").value = app.state.prompt;
    document.getElementById("result-image").style.filter = app.components.canvas.resultFilter();
    autoSizePrompt(document.getElementById("prompt-input"));
    syncAuto(); setTool(app.state.tool); syncSelection(app.state.selectedId);
  }
  function status(message) { document.getElementById("status-line").textContent = String(message || ""); }

  async function runDevSelfTest() {
    if (window.location.hash !== "#self-test" || !app.platform.hermit.available()) return null;
    var runtime = await app.platform.hermit.current().runtime.info();
    if (runtime.launchChannel !== "dev") return null;
    var original = app.services.store.serializeCanvas();
    var canvas = document.getElementById("draft-canvas"), rect = canvas.getBoundingClientRect();
    var EventType = window.PointerEvent || window.MouseEvent;
    function fire(type, x, y) {
      canvas.dispatchEvent(new EventType(type, { bubbles: true, clientX: rect.left + x, clientY: rect.top + y, pointerId: 1 }));
    }
    var down = window.PointerEvent ? "pointerdown" : "mousedown";
    var move = window.PointerEvent ? "pointermove" : "mousemove";
    var up = window.PointerEvent ? "pointerup" : "mouseup";
    fire(down, 60, 75); fire(move, 130, 145); fire(up, 195, 210);
    var beforeUndo = app.state.objects.length;
    app.components.canvas.undo();
    var afterUndo = app.state.objects.length;
    app.components.canvas.redo();
    var afterRedo = app.state.objects.length;
    var prompt = document.getElementById("prompt-input");
    prompt.value = "VibeDraw DEV self test";
    prompt.dispatchEvent(new Event("input", { bubbles: true }));
    document.getElementById("open-settings").click();
    var modelCards = document.querySelectorAll("[data-model-card]").length;
    app.components.ui.close();
    await app.utils.sleep(500);
    var stored = await app.platform.hermit.getData("vibedraw", "canvas");
    var persisted = Boolean(stored && stored.value && stored.value.prompt === "VibeDraw DEV self test");
    var result = {
      passed: beforeUndo === 1 && afterUndo === 0 && afterRedo === 1 && modelCards === 2 && persisted,
      version: app.version,
      bridgeReady: Boolean(window.hermit && window.hermit.isReady),
      canvasCss: [Math.round(rect.width), Math.round(rect.height)],
      beforeUndo: beforeUndo,
      afterUndo: afterUndo,
      afterRedo: afterRedo,
      modelCards: modelCards,
      persisted: persisted,
      quickConfigured: app.services.imageEngine.configured("quick"),
      qualityConfigured: app.services.imageEngine.configured("quality")
    };
    app.components.canvas.load(original);
    syncAll();
    app.services.store.scheduleCanvasSave();
    window.__vibedrawSelfTest = result;
    window.history.replaceState(null, "", window.location.pathname);
    return result;
  }

  app.features.editor = { init: init, syncAll: syncAll, setTool: setTool, status: status, runDevSelfTest: runDevSelfTest };
})(window.vibedraw);
