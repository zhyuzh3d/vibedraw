(function (app) {
  "use strict";

  async function start() {
    app.components.ui.init();
    app.events.on("error", function (error) { app.components.ui.toast(app.utils.cleanError(error), "error"); });
    app.components.settings.init();
    await app.services.store.loadConfig();
    app.i18n.theme();
    app.state.negativePrompt = app.config.canvas.negativePrompt || "";
    app.state.includeResult = Boolean(app.config.canvas.includeResult);
    app.state.resultOpacity = Number(app.config.canvas.resultOpacity) || 1;
    app.components.canvas.init();
    app.services.imageEngine.init(app.components.canvas);
    var saved = await app.services.store.loadCanvas();
    if (saved) app.components.canvas.load(saved);
    app.features.editor.init();
    app.platform.hermit.appReady();
    app.features.editor.status(app.features.editor.defaultStatus());
    var media = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)");
    if (media && media.addListener) media.addListener(app.i18n.theme);
    await app.features.selfTest.run();
  }

  window.addEventListener("error", function (event) {
    if (event.error) app.events.emit("error", event.error);
  });
  window.addEventListener("unhandledrejection", function (event) {
    app.events.emit("error", event.reason || new Error("异步操作失败"));
  });

  window.hermitDevState = {
    capture: function () {
      return {
        tool: app.state.tool,
        prompt: app.state.prompt,
        selectedId: app.state.selectedId,
        scrollY: window.scrollY,
        version: app.version,
        workId: app.state.workId,
        workCount: app.services.store.list().length,
        theme: document.documentElement.dataset.theme,
        language: app.i18n.language(),
        selfTest: window.__vibedrawSelfTest || null
      };
    },
    restore: function (snapshot) {
      if (!snapshot || typeof snapshot !== "object") return;
      if (snapshot.tool) app.features.editor.setTool(snapshot.tool);
      if (typeof snapshot.prompt === "string") {
        app.state.prompt = snapshot.prompt;
        document.getElementById("prompt-input").value = snapshot.prompt;
      }
      app.state.selectedId = snapshot.selectedId || "";
      app.components.canvas.render();
      requestAnimationFrame(function () { window.scrollTo(0, Number(snapshot.scrollY) || 0); });
    }
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})(window.vibedraw);
