(function (app) {
  "use strict";
  var timer = 0, running = false, queuedSlot = "", generation = 0, dismissed = false;
  var canvasInput = null;
  var t = app.i18n.text;
  function configured(slot) {
    var config = app.config && app.config[slot];
    if (!config || !config.endpoint) return false;
    if (config.protocol === "comfyui" && !config.workflow) return false;
    return true;
  }
  function schedule() {
    clearTimeout(timer);
    if (!app.state.autoGenerate || !configured("quick")) return;
    timer = setTimeout(function () { run("quick", true); }, Number(app.state.autoDelayMs) || 850);
  }
  function stopAuto() { clearTimeout(timer); if (queuedSlot === "quick") queuedSlot = ""; }
  function cancel() {
    clearTimeout(timer); generation += 1; queuedSlot = ""; dismissed = true; app.state.busy = false;
    app.events.emit("generation:idle");
  }
  async function run(slot, automatic) {
    clearTimeout(timer);
    if (running) {
      queuedSlot = slot === "quality" ? "quality" : queuedSlot || "quick";
      app.events.emit("status", t("最新画面已排队，当前请求完成后继续", "Latest sketch queued until the current request finishes"));
      return;
    }
    if (!configured(slot)) {
      if (!automatic) app.events.emit("needs-config", slot);
      return;
    }
    var prompt = String(app.state.prompt || "").trim();
    var config = app.utils.copy(app.config[slot]);
    if (!prompt && config.protocol !== "a1x-image") {
      if (!automatic) app.events.emit("error", new Error(t("先在画布上方描述你想画什么", "Describe your idea above the canvas first")));
      return;
    }
    if (canvasInput.hasMask() && config.protocol !== "a1x-image" && (config.inputMode === "text" || ["openai-images", "sd-webui"].indexOf(config.protocol) < 0)) {
      if (!automatic) app.events.emit("error", new Error(t("当前模型不支持局部蒙版，请使用 OpenAI Images 或 SD WebUI 的草图模式", "Masks require an OpenAI Images or SD WebUI model in sketch mode")));
      return;
    }
    running = true; queuedSlot = ""; dismissed = false;
    var token = ++generation;
    app.state.busy = true; app.events.emit("generation:start", { slot: slot });
    try {
      var input = { prompt: prompt, negativePrompt: app.state.negativePrompt, seed: app.state.seedLocked ? app.state.seed : -1, strength: app.state.strength, referenceStrength: app.state.referenceStrength,
        imageDataUrl: await canvasInput.composeInput(), maskDataUrl: canvasInput.composeMask(false), openAiMaskDataUrl: canvasInput.composeMask(true) };
      var result = await app.services.providers.generate(config, input);
      if (token !== generation) return;
      app.state.result = { src: result.src, logicalFileId: result.logicalFileId || "", slot: slot, prompt: prompt, createdAt: Date.now() };
      app.events.emit("generation:done", app.state.result);
      app.services.store.scheduleCanvasSave();
    } catch (error) {
      if (token === generation) app.events.emit("generation:error", error);
    } finally {
      running = false; app.state.busy = false;
      if (!dismissed) app.events.emit("generation:idle");
      if (queuedSlot) { var next = queuedSlot; queuedSlot = ""; setTimeout(function () { run(next, true); }, 60); }
    }
  }
  app.services.imageEngine = { init: function (input) { canvasInput = input; }, schedule: schedule, run: run, configured: configured, cancel: cancel, stopAuto: stopAuto };
})(window.vibedraw);
