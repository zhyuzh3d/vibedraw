"""Built-in ComfyUI graphs for the VibeDraw tasks.

The plugin owns the graphs so a user never has to export an API workflow.  The
same specifications drive ``GET /vibedraw/v1/capabilities``, so the client and
the server can never disagree about which sizes, step counts, or parameters a
task accepts.

Reference influence
-------------------
``ref_strength`` is the single most important parameter: it is how strongly the
reference image constrains the result.  Higher means closer to the reference.
For the checkpoint tasks it maps onto the sampler's ``denoise`` in reverse,
because a low denoise keeps more of the encoded reference latent intact.  The
``qwen`` task has no such lever — see :func:`reference_fade` — so there it fades
the reference itself instead.  Either way, higher means closer to the reference.

Two families
------------
Three tasks are driven by one *checkpoint* (``CheckpointLoaderSimple``).  The
``qwen`` task is driven by a *triple* — a diffusion model, a text encoder and a
VAE — because Qwen-Image 2.1 ships that way: ``UNETLoader`` + ``CLIPLoader`` +
``VAELoader``.  Both families share the same request contract, so a client never
has to know which one it is talking to; only the graph builder branches.

Prompt language
---------------
``english_only`` says whether a task's text encoder can read a Chinese prompt.
It is per task, not per plugin, and it is what a client reads to decide whether
to translate before submitting:

* the LCM tasks run SD 1.5 checkpoints, whose text encoder is CLIP-L — an
  English-only model, so a Chinese prompt reaches the sampler as noise
  (``english_only: True``);
* the ``qwen`` task runs Qwen-Image 2.1, whose text encoder is Qwen3-VL — a
  multilingual model that reads Chinese natively (``english_only: False``).

Measured on the A1X box (2026-09-26), one seed, one reference picture, four
prompts: the render from 一只戴着墨镜的猫 sat 12.38 (mean |Δ| per channel) from
the render of its English translation, while an unrelated prompt sat 21.40 away
and an empty prompt 27.73 — i.e. the Chinese prompt steered the picture to the
same place its translation did, which noise cannot do.  The translator stays
available either way; this only says it is not *required* here.
"""

from __future__ import annotations

from typing import Any

REFERENCE_FLOOR = 0.05
#: The strongest reference influence a task may ask for.  Tasks that can hold the
#: reference through the latent sit at 0.95 so the sampler still has room to move;
#: the Qwen family reaches "reference untouched" exactly here.
REFERENCE_CEILING = 0.95
DENOISE_MINIMUM = 0.05
DENOISE_MAXIMUM = 1.0

#: Tasks whose graph is a UNET + text encoder + VAE triple instead of a single
#: checkpoint.  Everything else loads one ``CheckpointLoaderSimple``.
QWEN_FAMILY = "qwen_image_21"

#: The Qwen text encoder is loaded through ``CLIPLoader`` with this type.
QWEN_CLIP_TYPE = "qwen_image"

#: Qwen's KV cache wrapper defaults. ``auto`` spills to RAM when VRAM runs out
#: and ``int8`` halves the cache at about bf16 accuracy, which is what the model's
#: own author recommends for a memory-starved box.
QWEN_CACHE_DEVICE = "auto"
QWEN_CACHE_DTYPE = "int8"

#: How much a Qwen reference may be softened when the strength is turned down.
#: ``ImageBlur`` caps ``blur_radius`` at 31 and ``sigma`` at 10.
QWEN_REFERENCE_FADE_MAX = 0.85
QWEN_BLUR_RADIUS_MAX = 31
QWEN_BLUR_SIGMA_MAX = 10.0

#: Upscaling encodes the reference at its own resolution up to this cap, and only
#: grows the latent above it.  The cap is what keeps a 2048 px job from needing
#: roughly four times the memory of a 1024 px one.  It is deliberately *not* 512:
#: encoding at 512 and growing the latent afterwards put the reference through a
#: lossy round trip before the sampler ever saw it, which is why a "render" came
#: out soft and partly re-invented instead of sharper than the canvas it came from.
UPSCALE_ENCODE_MAX = 1024


def denoise_from_reference(ref_strength: float) -> float:
    value = 1.0 - max(0.0, min(1.0, float(ref_strength)))
    return max(DENOISE_MINIMUM, min(DENOISE_MAXIMUM, value))


TASK_SPECS: dict[str, dict[str, Any]] = {
    "quick": {
        "id": "quick",
        "label": {"zh": "快速绘制", "en": "Quick draw"},
        "description": {
            "zh": "把画布当作参考图重绘一张 512 × 512 的速写稿，推荐 DreamShaper8 LCM。",
            "en": "Redraw the canvas as a 512 × 512 sketch. DreamShaper8 LCM is recommended.",
        },
        "needs": {"image": True, "mask": False, "prompt": True},
        "english_only": True,
        "sizes": [[512, 512]],
        "steps": {"allowed": [2, 4, 6, 8], "default": 8},
        "params": [
            {
                "id": "ref_strength",
                "kind": "reference",
                "label": {"zh": "参考图权重", "en": "Reference influence"},
                "help": {
                    "zh": "越高越贴近画布原稿，越低越放手重画。",
                    "en": "Higher keeps closer to the canvas, lower redraws more freely.",
                },
                "minimum": REFERENCE_FLOOR,
                "maximum": REFERENCE_CEILING,
                "default": 0.55,
            }
        ],
        "estimated_seconds": 1.2,
    },
    "inpaint": {
        "id": "inpaint",
        "label": {"zh": "局部重绘", "en": "Local redraw"},
        "description": {
            "zh": "只重画白色蒙版覆盖的区域，其余部分原样保留，推荐 DreamShaper8 LCM。",
            "en": "Repaint only the white mask area and keep everything else. DreamShaper8 LCM is recommended.",
        },
        "needs": {"image": True, "mask": True, "prompt": True},
        "english_only": True,
        "sizes": [[512, 512]],
        "steps": {"allowed": [4, 6, 8, 12], "default": 6},
        "params": [
            {
                "id": "ref_strength",
                "kind": "reference",
                "label": {"zh": "参考图权重", "en": "Reference influence"},
                "help": {
                    "zh": "越高越贴近原图；蒙版内仍会被重画。",
                    "en": "Higher keeps closer to the original; the masked area is still redrawn.",
                },
                "minimum": REFERENCE_FLOOR,
                "maximum": REFERENCE_CEILING,
                "default": 0.30,
            },
            {
                "id": "grow_mask_by",
                "kind": "integer",
                "label": {"zh": "蒙版外扩", "en": "Mask grow"},
                "help": {
                    "zh": "把重画范围向外扩几个像素，接缝更自然。",
                    "en": "Grow the repaint area by a few pixels so the seam blends.",
                },
                "minimum": 0,
                "maximum": 64,
                "default": 8,
            },
        ],
        "estimated_seconds": 2.6,
    },
    "upscale": {
        "id": "upscale",
        "label": {"zh": "放大绘制", "en": "Upscale draw"},
        "description": {
            "zh": "把画布放大到 1024 或 2048 并补细节；参考图按原分辨率（上限 1024）直接编码，模型只要能接受同尺寸参考图即可。",
            "en": "Upscale the canvas to 1024 or 2048 and add detail. The reference is encoded at its own resolution, capped at 1024, so any model that accepts a same-size reference works.",
        },
        "needs": {"image": True, "mask": False, "prompt": True},
        "english_only": True,
        "sizes": [[1024, 1024], [2048, 2048]],
        "steps": {"allowed": [4, 8, 12, 16, 20], "default": 8},
        "params": [
            {
                "id": "ref_strength",
                "kind": "reference",
                "label": {"zh": "参考图权重", "en": "Reference influence"},
                "help": {
                    "zh": "建议保持较高，否则放大后会改变原构图。",
                    "en": "Keep this high, or upscaling will change the composition.",
                },
                "minimum": 0.30,
                "maximum": REFERENCE_CEILING,
                "default": 0.75,
            }
        ],
        "estimated_seconds": 6.0,
    },
    "qwen": {
        "id": "qwen",
        "label": {"zh": "Qwen 图像 2.1", "en": "Qwen Image 2.1"},
        "description": {
            "zh": "用 Qwen-Image 2.1(官方 INT8)把画布重画成一张 1024 以内的成品图。它按参考图作画而不是在画布上做图生图,所以构图由参考图本身带来;它比 LCM 草图模型重得多,单张要几十秒;画幅可在 512–1024 之间按 64 步进。",
            "en": "Redraw the canvas with Qwen-Image 2.1 (official INT8) up to 1024 px. It paints *from* the reference rather than running img2img over the canvas, so the composition comes from the reference itself. It is far heavier than the LCM sketch models — tens of seconds per image — and takes any square size from 512 to 1024 in steps of 64.",
        },
        "needs": {"image": True, "mask": False, "prompt": True},
        # Qwen 的文本编码器是 Qwen3-VL（中文母语）,所以这一条**不需要**先翻译 ——
        # 与本文件另外三条 LCM 任务相反。实测见模块开头的 Prompt language 一节。
        "english_only": False,
        # The whole 512–1024 range in steps of 64, so a client slider maps onto
        # the task without a second lookup table. Every value is a multiple of
        # 64, which keeps the Qwen VAE happy.
        "sizes": [
            [512, 512], [576, 576], [640, 640], [704, 704], [768, 768],
            [832, 832], [896, 896], [960, 960], [1024, 1024],
        ],
        "steps": {"allowed": [12, 16, 20, 25, 30, 40], "default": 20},
        "params": [
            {
                "id": "ref_strength",
                "kind": "reference",
                "label": {"zh": "参考图权重", "en": "Reference influence"},
                # Not the img2img denoise of the other tasks: see reference_fade().
                "help": {
                    "zh": "最高时参考图原样交给编码器,构图与姿态跟得最紧;调低则把参考图逐步柔化,肢体轮廓化开,让模型照提示词自由发挥。",
                    "en": "At the top the reference reaches the encoder untouched, so composition and pose are followed closely; lower values soften it until the limbs have dissolved and the prompt takes over.",
                },
                "minimum": REFERENCE_FLOOR,
                "maximum": REFERENCE_CEILING,
                "default": 0.95,
            }
        ],
        "estimated_seconds": 45.0,
        "family": QWEN_FAMILY,
    },
}


def family(task: str) -> str:
    """``"checkpoint"`` for the LCM tasks, ``"qwen_image_21"`` for Qwen."""
    return str(spec(task).get("family") or "checkpoint")


def task_ids() -> list[str]:
    return list(TASK_SPECS)


def spec(task: str) -> dict[str, Any]:
    value = TASK_SPECS.get(str(task or "").strip().lower())
    if value is None:
        raise ValueError("unsupported_task")
    return value


def allowed_sizes(task: str) -> list[list[int]]:
    return [list(size) for size in spec(task)["sizes"]]


def _checkpoint_node(checkpoint: str) -> dict[str, Any]:
    return {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": checkpoint}, "_meta": {"title": "VibeDraw checkpoint"}}


def _unet_node(name: str) -> dict[str, Any]:
    return {"class_type": "UNETLoader", "inputs": {"unet_name": name, "weight_dtype": "default"}, "_meta": {"title": "VibeDraw diffusion model"}}


def _clip_node(name: str) -> dict[str, Any]:
    return {"class_type": "CLIPLoader", "inputs": {"clip_name": name, "type": QWEN_CLIP_TYPE}, "_meta": {"title": "VibeDraw text encoder"}}


def _vae_node(name: str) -> dict[str, Any]:
    return {"class_type": "VAELoader", "inputs": {"vae_name": name}, "_meta": {"title": "VibeDraw VAE"}}


def _load_image(name: str, title: str) -> dict[str, Any]:
    return {"class_type": "LoadImage", "inputs": {"image": name}, "_meta": {"title": title}}


def _scale(source: list[Any], width: int, height: int) -> dict[str, Any]:
    return {
        "class_type": "ImageScale",
        "inputs": {"image": source, "upscale_method": "lanczos", "width": int(width), "height": int(height), "crop": "disabled"},
    }


def _latent_upscale(source: list[Any], width: int, height: int) -> dict[str, Any]:
    return {
        "class_type": "LatentUpscale",
        "inputs": {"samples": source, "upscale_method": "bilinear", "width": int(width), "height": int(height), "crop": "disabled"},
    }


def _text_encode(text: str, clip: list[Any], title: str) -> dict[str, Any]:
    return {"class_type": "CLIPTextEncode", "inputs": {"text": str(text or ""), "clip": clip}, "_meta": {"title": title}}


def _sampler(model, positive, negative, latent, seed, steps, sampling, denoise) -> dict[str, Any]:
    return {
        "class_type": "KSampler",
        "inputs": {
            "model": model,
            "positive": positive,
            "negative": negative,
            "latent_image": latent,
            "seed": int(seed),
            "steps": int(steps),
            "cfg": float(sampling.get("cfg", 2.0)),
            "sampler_name": str(sampling.get("sampler", "lcm")),
            "scheduler": str(sampling.get("scheduler", "sgm_uniform")),
            "denoise": float(denoise),
        },
    }


def reference_fade(ref_strength: float) -> float:
    """How far the reference is softened before it reaches the Qwen encoder.

    Qwen-Image 2.1 is a *reference-conditioned* generator: the reference pictures
    are spliced into the token sequence by ``TextEncodeQwenImage21`` and sampling
    always starts from an empty latent at ``denoise = 1``.  Its sampler therefore
    has no "keep more of the reference latent" lever — the usual
    ``denoise = 1 - ref_strength`` has nothing to hold on to, and asking for a
    partial denoise over a reference latent makes the model hand the latent back
    almost untouched (measured on the A1X box: 0.45 and even 0.70 came back as
    the reference with a slight blur, only 0.95 really repainted).

    So the same knob is applied to the reference itself.  The picture is blurred
    by an amount that grows as the strength falls: at full strength the encoder
    sees it untouched, and at the bottom the limbs have dissolved into a colour
    wash, which is as close as this model gets to being told to stop copying the
    composition.  The blur is deliberately *not* a blend towards a flat grey —
    that tinted the whole render, because the model happily painted the grey back
    out as a washed-out background.
    """
    ceiling = REFERENCE_CEILING - REFERENCE_FLOOR
    normalized = (max(REFERENCE_FLOOR, min(REFERENCE_CEILING, float(ref_strength))) - REFERENCE_FLOOR) / ceiling
    return round(QWEN_REFERENCE_FADE_MAX * (1.0 - normalized), 3)


def _qwen_reference_blur(fade: float) -> dict[str, Any]:
    """The blur that turns a fade amount into ``ImageBlur`` settings.

    ``blur_radius`` only goes up to 31, so the radius and the sigma are moved
    together: a wide radius on its own rings around the edges of a 1024 px
    picture, and a large sigma on its own leaves a visible ghost of the original
    silhouette, which is exactly the thing a low strength is trying to remove.
    """
    radius = int(round(1 + fade * (QWEN_BLUR_RADIUS_MAX - 1)))
    sigma = round(0.1 + fade * (QWEN_BLUR_SIGMA_MAX - 0.1), 1)
    return {"class_type": "ImageBlur", "inputs": {"image": ["11", 0], "blur_radius": radius, "sigma": sigma},
            "_meta": {"title": "VibeDraw reference strength"}}


def _build_qwen(
    *,
    models: dict[str, Any] | None,
    image: str,
    prompt: str,
    negative_prompt: str,
    seed: int,
    steps: int,
    size: tuple[int, int],
    sampling: dict[str, Any],
    ref_strength: float,
    filename_prefix: str,
) -> dict[str, Any]:
    """Qwen-Image 2.1: a diffusion model + text encoder + VAE, reference-conditioned.

    The graph mirrors the model's own contract rather than pretending it is an
    ordinary checkpoint: ``UNETLoader`` + ``CLIPLoader(type=qwen_image)`` +
    ``VAELoader`` feed ``QwenImage21Cache`` (the KV-cache wrapper the model wants),
    ``TextEncodeQwenImage21`` turns prompt, negative prompt **and the reference
    picture** into a conditioning pair, and the sampler runs from an empty latent
    with ``denoise = 1``.  The reference is scaled to the output canvas first,
    because the node resizes what it is given to ``resolution`` anyway and doing
    it here keeps the aspect ratio exact.

    The reference-strength knob is applied by :func:`reference_fade`.
    """
    files = dict(models or {})
    unet = str(files.get("unet") or "").strip()
    clip = str(files.get("clip") or "").strip()
    vae = str(files.get("vae") or "").strip()
    if not (unet and clip and vae):
        raise ValueError("no_model")

    width, height = int(size[0]), int(size[1])
    fade = reference_fade(ref_strength)

    graph: dict[str, Any] = {
        # "9" is always the output node: the HTTP layer validates the prompt
        # against exactly that id, so it must not move between families.
        "9": {"class_type": "VibeDrawOutput", "inputs": {"images": ["8", 0], "filename_prefix": filename_prefix}},
        "8": {"class_type": "VAEDecode", "inputs": {"samples": ["7", 0], "vae": ["3", 0]}},
        "7": _sampler(["4", 0], ["5", 0], ["5", 1], ["6", 0], seed, steps, sampling, 1.0),
        "6": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "5": {
            "class_type": "TextEncodeQwenImage21",
            "inputs": {
                "clip": ["2", 0],
                "prompt": str(prompt or ""),
                "negative_prompt": str(negative_prompt or ""),
                # The reference already carries the canvas size; telling the node
                # the same number keeps it from resizing a second time.
                "resolution": max(width, height),
                "vae": ["3", 0],
                "images.image_1": ["12", 0] if fade > 0 else ["11", 0],
            },
            "_meta": {"title": "VibeDraw prompt and reference"},
        },
        "4": {
            "class_type": "QwenImage21Cache",
            "inputs": {"model": ["1", 0], "device": QWEN_CACHE_DEVICE, "dtype": QWEN_CACHE_DTYPE},
            "_meta": {"title": "VibeDraw text cache"},
        },
        "3": _vae_node(vae),
        "2": _clip_node(clip),
        "1": _unet_node(unet),
        # "10" loads the picture, "11" scales it to the output canvas, and "12"
        # is what the encoder actually sees: "11" as it is, or "11" softened by
        # the strength knob.  The soften step must live on its own id — reading
        # "11" and writing "11" is a dependency cycle and ComfyUI rejects the
        # whole prompt with "Dependency cycle detected".
        "10": _load_image(image, "VibeDraw reference"),
        "11": _scale(["10", 0], width, height),
    }
    if fade > 0:
        graph["12"] = _qwen_reference_blur(fade)
    return graph


def build(
    *,
    task: str,
    checkpoint: str = "",
    sampling: dict[str, Any],
    image: str,
    mask: str = "",
    prompt: str = "",
    negative_prompt: str = "",
    seed: int = 0,
    steps: int | None = None,
    size: list[int] | None = None,
    ref_strength: float | None = None,
    grow_mask_by: int | None = None,
    models: dict[str, Any] | None = None,
    filename_prefix: str = "vibedraw/vibedraw",
) -> tuple[dict[str, Any], list[str]]:
    specification = spec(task)
    width, height = size or specification["sizes"][0]
    chosen_steps = int(steps if steps is not None else specification["steps"]["default"])
    reference = float(specification["params"][0]["default"] if ref_strength is None else ref_strength)
    denoise = denoise_from_reference(reference)

    if family(task) == QWEN_FAMILY:
        graph = _build_qwen(
            models=models, image=image, prompt=prompt, negative_prompt=negative_prompt,
            seed=int(seed), steps=chosen_steps, size=(width, height), sampling=sampling,
            ref_strength=reference, filename_prefix=filename_prefix,
        )
        return graph, ["9"]

    graph: dict[str, Any] = {
        "1": _checkpoint_node(checkpoint),
        "2": _load_image(image, "VibeDraw reference"),
        "5": _text_encode(prompt, ["1", 1], "VibeDraw prompt"),
        "6": _text_encode(negative_prompt, ["1", 1], "VibeDraw negative prompt"),
    }

    if task == "upscale":
        # The reference keeps the resolution the client sent, up to the cap, so the
        # sampler starts from the real picture instead of a 512 px impression of it.
        encode = (min(int(width), UPSCALE_ENCODE_MAX), min(int(height), UPSCALE_ENCODE_MAX))
        graph["3"] = _scale(["2", 0], encode[0], encode[1])
    else:
        encode = (int(width), int(height))
        graph["3"] = _scale(["2", 0], width, height)

    if task == "inpaint":
        grow = int(grow_mask_by if grow_mask_by is not None else specification["params"][1]["default"])
        graph["10"] = _load_image(mask, "VibeDraw mask")
        graph["11"] = {"class_type": "ImageToMask", "inputs": {"image": ["10", 0], "channel": "red"}}
        graph["4"] = {
            "class_type": "VAEEncodeForInpaint",
            "inputs": {"pixels": ["3", 0], "vae": ["1", 2], "mask": ["11", 0], "grow_mask_by": max(0, min(64, grow))},
        }
        latent: list[Any] = ["4", 0]
    else:
        graph["4"] = {"class_type": "VAEEncode", "inputs": {"pixels": ["3", 0], "vae": ["1", 2]}}
        latent = ["4", 0]

    if task == "upscale" and encode != (int(width), int(height)):
        # Only a target larger than the cap is grown from the smaller latent.
        graph["12"] = _latent_upscale(["4", 0], width, height)
        latent = ["12", 0]

    graph["7"] = _sampler(["1", 0], ["5", 0], ["6", 0], latent, seed, chosen_steps, sampling, denoise)
    graph["8"] = {"class_type": "VAEDecode", "inputs": {"samples": ["7", 0], "vae": ["1", 2]}}
    graph["9"] = {"class_type": "VibeDrawOutput", "inputs": {"images": ["8", 0], "filename_prefix": filename_prefix}}
    return graph, ["9"]


def validate(*, task: str, size: list[int] | None, steps: int | None) -> tuple[list[int], int]:
    specification = spec(task)
    sizes = [list(value) for value in specification["sizes"]]
    chosen = [int(size[0]), int(size[1])] if size else sizes[0]
    if chosen not in sizes:
        raise ValueError("unsupported_size")
    allowed_steps = [int(value) for value in specification["steps"]["allowed"]]
    selected = int(steps if steps is not None else specification["steps"]["default"])
    if selected not in allowed_steps:
        raise ValueError("unsupported_steps")
    return chosen, selected
