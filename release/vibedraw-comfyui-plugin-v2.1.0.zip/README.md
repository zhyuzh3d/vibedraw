# CVP — ComfyUI VibeDraw Plugin

VibeDraw 的**统一本地接口**。任何客户端（VibeDraw 本体、其他开发者的工具）只要认下面这一个 HTTP 契约，就能用你已经装好的 ComfyUI 出图，**不需要自己导出工作流 JSON**——四套图都内置在插件里。

- 协议标识：`vibedraw-comfy/v2`
- 发现文档：`vibedraw-comfy/discovery/v1`
- 路由前缀：`/vibedraw/v1/`
- 目录：把 `vibedraw_comfy/` 整个放进 ComfyUI 的 `custom_nodes/`

**新客户端第一步先调 `GET /vibedraw/v1/plugins`**：它一次给出这台机器上**有哪些任务、每个任务收什么请求体、背后是哪几个模型文件、以及这条任务的编码器认不认中文**。客户端据此自己长出配置界面，不必把参数写死在自己代码里。

## 安装

1. 拷贝目录：

   ```bash
   cp -r vibedraw_comfy  <你的 ComfyUI>/custom_nodes/vibedraw_comfy
   ```

   容器部署时把这个目录挂进去即可（宿主路径 → 容器 `custom_nodes/vibedraw_comfy`），改完重启 ComfyUI。

2. **没有额外依赖**，只用 ComfyUI 自带的 `aiohttp` / `folder_paths` / `execution`；也不用改 `requirements.txt`。

3. 重启后在 ComfyUI 节点菜单里搜 **VibeDraw**，会看到三个节点：

   | 节点 | 用途 |
   |---|---|
   | **VibeDraw 配置 (Config)** | **用户唯一需要操作的节点**：设密码 + 选三套 checkpoint（外加 Qwen 那一路的三个槽位） |
   | VibeDraw 输入 / 输出 | 只在你自己搭自定义工作流时用；内置四套图用不到 |

4. 想确认装好了：

   ```bash
   curl -s http://127.0.0.1:8188/vibedraw/v1/plugins
   ```

   返回 JSON，且 `schema` 为 `vibedraw-comfy/discovery/v1`、`plugin.version` 是你期望的那一版（当前 **2.1.0**）、`plugins` 里每条 `ready` 为 `true`，即成功（ComfyUI 没开鉴权时；开了鉴权见下）。

   发现端点**密码填错也照答**（此时 `auth.authorized` 为 `false`），所以"地址对不对"和"密码对不对"可以一次问清：能返回 JSON 说明地址通，`authorized` 说明密码。

   **插件版本只有一个出处**：`vibedraw_comfy/version.py` 的 `__version__`。发布包名（`tools/package-plugin.py`）与 App 内嵌副本（`tools/embed-plugin.py`）都读它，不会各自漂移。

## 配置（VibeDraw 配置节点）

| 字段 | 说明 |
|---|---|
| `password` | **访问密码**。填了就只有带对密码的请求能出图；**留空 = 不校验**。 |
| `quick_checkpoint` | 快速绘制用的模型，默认 `DreamShaper8_LCM.safetensors` |
| `inpaint_checkpoint` | 局部重绘用的模型，可填 `(same as quick)` 复用上一个 |
| `upscale_checkpoint` | 放大绘制用的模型，同样支持 `(same as quick)` |
| `qwen_unet` / `qwen_clip` / `qwen_vae` | Qwen 成品图那一路的**三个槽位**（diffusion model / 文本编码器 / VAE），与上面的 checkpoint 互不影响 |
| `translate_model` | 内建翻译引擎，默认 `qwen3-0.6b` |

`qwen` 那一路要三个文件都填齐才算 `ready`；只填一半时发现文档会把它标成 `ready: false` 并在 `model.missing` 里点名缺哪个槽位。

配置写在 `custom_nodes/vibedraw_comfy/vibedraw_settings.json`（原子写、可手工编辑）；也可以直接用环境变量 `VIBEDRAW_PASSWORD` 覆盖密码（适合容器/CI）。

**密码错了会怎样**：请求在**入队之前**就被拦下，返回 `401 unauthorized`，**不会生图**。客户端拿到的是一句可读的中文提示，而不是一张画错的图。

## 四套内置工作流

客户端只报任务名，尺寸/步数由插件按规格校验，超范围的参数直接 `400`：

| 任务 `task` | 画幅 | 步数 | 特有参数 | 提示词语言 | 说明 |
|---|---|---|---|---|---|
| `quick` | 512×512 | 2 / 4 / 6 / 8 | `ref_strength` 默认 0.55 | **只认英文** | 把画布当参考图重绘一张速写稿 |
| `inpaint` | 512×512 | 4 / 6 / 8 / 12 | `ref_strength` 默认 0.30、`grow_mask_by` 0–64 默认 8 | **只认英文** | **只重画白色蒙版区域**，其余原样保留 |
| `upscale` | 1024×1024 或 2048×2048 | 4 / 8 / 12 / 16 / 20 | `ref_strength` 默认 0.75 | **只认英文** | 放大重绘：参考图按**原分辨率**（上限 1024）直接编码；只有目标大于上限时才 latent 放大。**不要退回"先缩到 512 再放大"**——那等于在采样器看到参考图之前先模糊它一轮，渲染出来会发软、像被重新演绎过。 |
| `qwen` | 512–1024 见方，按 64 步进（9 档） | 12 / 16 / 20 / 25 / 30 / 40 | `ref_strength` 默认 0.95 | **中文英文都行** | 用 Qwen-Image 2.1（官方 INT8）出 1024 以内的成品图。它**按参考图作画**而不是在画布上做图生图，构图由参考图本身带来；比 LCM 草图模型重得多，单张约 45 秒；模型是 unet + clip + vae 三元组。 |

**推荐模型**：DreamShaper8 LCM 系列（512 分辨率通常 1 秒左右出图）。`quick` / `inpaint` 建议就用它，不必换；`upscale` 用能接受 512 参考图、输出 1024/2048 的模型即可。`qwen` 走 RealVisXL / Qwen-Image 那一族，与前三套的 checkpoint 完全独立。

### 语言：谁认中文，由插件自己报

`quick` / `inpaint` / `upscale` 三条是 **SD1.5 + CLIP-L** 结构，文本编码器只吃英文；`qwen` 那条的编码器是 **Qwen3-VL**，中文是它的母语。这不是猜的，是两条独立证据：

- 官方口径：Qwen-Image 系支持中英双语提示词，SD1.5 / SDXL 那套 CLIP-L 不支持。
- 真机实测：固定 seed 与参考图，只换提示词跑四单 `qwen`，比较逐像素平均差。**中文 vs 它的英文译文 12.38，中文 vs 无关提示词 21.40，中文 vs 空提示词 27.73**——中文把画面带到了它英文译文去的地方，噪声做不到这件事。

于是发现文档里每个任务都带两个字段，客户端**不要自己写死**：

| 字段 | 取值 | 含义 |
|---|---|---|
| `english_only` | `true` / `false` | 提示词是否必须先译成英文 |
| `prompt_language` | `"en"` / `"any"` | 同上的可读形式 |

文档顶层另有 `prompt_policy`，把两条清单一次给全：`english_only_pipelines`（需要翻译的）与 `any_language_pipelines`（不必翻译的）。`/capabilities` 里同名字段一致。

**翻不翻的建议**：`english_only` 为 `false` 时传中文就行，**不必多绕一次 `/translate`**——插件内建的翻译引擎是同一个 Qwen，先翻再喂等于多花一次往返，对画面没有增益。

### `ref_strength` 是唯一的权重入口

它是"**参考图权重**"：越高越贴近你画的原稿，越低越放手重画。插件内部换算成 denoise 后钳制：

```
denoise = clamp(1 - ref_strength, 0.05, 1.0)
```

所以 `1.0` 几乎照着原稿描、`0.05` 近乎完全重画，两端都不会出现"毫无效果"的假参数。**客户端若用别的滑杆口径，请自行映射到这个 0.05–0.95 的区间再发过来。**

## HTTP 契约

| 方法 | 路径 | 说明 |
|---|---|---|
| `GET` | `/vibedraw/v1/plugins` | **发现文档**：任务清单 + 每个任务的请求体 JSON Schema + 模型槽位 + `english_only` + 是否需要密码。**密码填错也照答**，由 `auth.authorized` 说明 |
| `GET` | `/vibedraw/v1/capabilities` | 能力自描述：任务、画幅、步数、参数、当前选中的模型、是否需要密码。**发现信息在这里也有一份**（`plugins` / `prompt_policy` / `plugin_version` / `discovery` 四个新键），老字段一个没动 |
| `POST` | `/vibedraw/v1/jobs` | 提交任务 → **202** `{"job":{"id":…,"state":"queued"}}` |
| `GET` | `/vibedraw/v1/jobs/{id}` | 轮询状态：`state ∈ queued / running / completed / failed / cancelled`，含 `progress` 与 `outputs` |
| `GET` | `/vibedraw/v1/jobs/{id}/output/{n}` | 取成图（直接返回 PNG，**复用同一把密码**） |
| `POST` | `/vibedraw/v1/jobs/{id}/cancel` | 取消排队中的任务 |
| `POST` | `/vibedraw/v1/translate` | 中文提示词 → 英文（`english_only` 为 `true` 的任务才需要） |

### `GET /vibedraw/v1/plugins` 长什么样

```json
{
  "schema": "vibedraw-comfy/discovery/v1",
  "api_schema": "vibedraw-comfy/v2",
  "plugin": { "id": "vibedraw_comfy", "version": "2.1.0",
              "label": { "zh": "ComfyUI VibeDraw 插件", "en": "ComfyUI VibeDraw Plugin" } },
  "auth": { "required": true, "authorized": true, "scheme": "Bearer", "header": "Authorization" },
  "plugins": [
    {
      "id": "qwen", "kind": "pipeline", "family": "qwen_image_21",
      "label": { "zh": "Qwen 图像 2.1", "en": "Qwen Image 2.1" },
      "description": { "zh": "…", "en": "…" },
      "english_only": false, "prompt_language": "any",
      "needs": { "image": true, "mask": false, "prompt": true },
      "sizes": [[512,512], [576,576], "…"] ,
      "steps": { "allowed": [12,16,20,25,30,40], "default": 20 },
      "params": [
        { "id": "ref_strength", "kind": "reference", "label": {"zh":"参考图权重","en":"Reference influence"},
          "minimum": 0.05, "maximum": 0.95, "default": 0.95 }
      ],
      "model": { "role": "triple", "name": "qwen_image_2.1_int8_convrot.safetensors",
                 "files": { "unet": "…", "clip": "…", "vae": "…" },
                 "available": true, "ready": true, "missing": [] },
      "model_roles": ["unet", "clip", "vae"],
      "ready": true, "estimated_seconds": 45.0,
      "schema": { "$schema": "…", "properties": { "prompt": {"type":"string","language":"any"} } }
    }
  ],
  "prompt_policy": {
    "english_only_pipelines": ["quick", "inpaint", "upscale"],
    "any_language_pipelines": ["qwen"],
    "translate_endpoint": "/vibedraw/v1/translate",
    "translate_available": true,
    "engine": "qwen3-0.6b", "target": "en"
  },
  "checkpoints": ["DreamShaper8_LCM.safetensors", "…"],
  "endpoints": { "plugins": "…", "jobs": "…", "job": "…", "output": "…", "cancel": "…", "translate": "…" }
}
```

几个使用要点：

- **`schema.required` 只列真正会 `400` 的字段**（`task`，以及按需的 `image_base64` / `mask_base64`）。提示词是 `recommended: true` 而不是 required —— **空提示词是合法的**，只是画面不听指挥。
- `model.ready` 复述的是 `POST /jobs` 入队前的那个判断（不满足时它回 `no_model`）。客户端照 `ready` 灰按钮，就不会在提交时才被拒。
- `model.available` 为 `false` 不是错，是"机器上没装这个文件"；`missing` 列出缺哪个槽位。
- `sizes` / `steps.allowed` / 参数的 `minimum`·`maximum`·`default` 全是从插件内部规格直接导出的，**与校验用的是同一份数据**，不会出现"文档说行、提交被拒"。
- 文档里的 `help` 与 `label` 都是 `{ "zh": …, "en": … }` 双份，界面按当前语言取。

提交体：

```json
{
  "task": "quick",
  "prompt": "a red fox",
  "negative_prompt": "",
  "seed": 12345,
  "size": [512, 512],
  "steps": 8,
  "ref_strength": 0.55,
  "image_base64": "data:image/png;base64,...",
  "mask_base64": "data:image/png;base64,...",
  "grow_mask_by": 8
}
```

- `image_base64`：参考图（画布）。`inpaint` 必带 `mask_base64`（**白 = 要重画**）。
- 图片可直接给 data URL，插件自己解码；请求体上限 32 MB。
- 鉴权：`Authorization: Bearer <password>`（也接受 Basic 或 `X-VibeDraw-Password`）。密码为空时不需要。
- 完成后的 `outputs[n].url` 已经是 `/vibedraw/v1/...` 绝对路径，**客户端直接拼服务器地址去下就行，不要再拼一层**。

错误码（全部带中英双语文案）：`unauthorized(401)` / `bad_request` / `unsupported_task` / `unsupported_size` / `unsupported_steps` / `bad_image` / `bad_mask` / `no_model(409)` / `busy(429)` / `not_found(404)` / `internal(500)`。

## 自测

```bash
# 1. 发现：有哪些任务、各自收什么、谁只认英文
curl -s -H 'Authorization: Bearer <password>' http://<host>:8188/vibedraw/v1/plugins

# 2. 能力（老接口，仍然可用）
curl -s -H 'Authorization: Bearer <password>' http://<host>:8188/vibedraw/v1/capabilities

# 3. 快速绘制
curl -s -X POST http://<host>:8188/vibedraw/v1/jobs \
  -H 'Authorization: Bearer <password>' -H 'Content-Type: application/json' \
  -d '{"task":"quick","prompt":"a red fox","seed":1,"size":[512,512],"steps":8,"ref_strength":0.55}'

# 4. 轮询 / 取图
curl -s -H 'Authorization: Bearer <password>' http://<host>:8188/vibedraw/v1/jobs/<id>
curl -s -H 'Authorization: Bearer <password>' -o out.png http://<host>:8188/vibedraw/v1/jobs/<id>/output/0
```

用 `python3 -m json.tool` 过一遍第 1 步的返回，重点确认三件事：`plugins` 有你要的那几条、每条 `ready` 为 `true`、`prompt_policy.english_only_pipelines` 与你预期一致。

- **第一次请求会慢**（模型加载，约十几秒），之后同模型重跑约 1 秒；别用首单判断"模型太慢"。
- 在 VibeDraw App 里对接：设置 → 模型配置 → 接口模式选「CVP 插件（推荐）」，服务器地址填 `http://<host>:<port>`，访问密码填节点里设的那个。三个 tab（快速生图 / 局部重绘 / 高清渲染）各自独立配置。
