(function (app) {
  "use strict";

  var revisions = {};
  var saveTimer = 0;

  async function read(key, fallback) {
    var record = await app.platform.hermit.getData("vibedraw", key);
    if (!record || record.value == null) return app.utils.copy(fallback);
    revisions[key] = record.revision;
    return record.value;
  }
  async function write(key, value) {
    var result = await app.platform.hermit.putData("vibedraw", key, value, revisions[key]);
    if (result && result.revision) revisions[key] = result.revision;
    return result;
  }
  async function loadConfig() {
    var stored = await read("config", app.defaults);
    app.config = app.utils.merge(app.defaults, stored || {});
    return app.config;
  }
  async function saveConfig(config) {
    app.config = app.utils.merge(app.defaults, config || {});
    await write("config", app.config);
    return app.config;
  }
  function serializeCanvas() {
    var safeObjects = app.state.objects.filter(function (object) {
      return object.type === "stroke" || object.type === "image" && object.logicalFileId;
    }).map(function (object) {
      var output = app.utils.copy(object);
      if (output.type === "image") delete output.src;
      return output;
    });
    return {
      schema: 1,
      prompt: app.state.prompt,
      negativePrompt: app.state.negativePrompt,
      background: app.state.background,
      color: app.state.color,
      size: app.state.size,
      opacity: app.state.opacity,
      strength: app.state.strength,
      seed: app.state.seed,
      autoGenerate: app.state.autoGenerate,
      includeResult: app.state.includeResult,
      resultOpacity: app.state.resultOpacity,
      objects: safeObjects,
      savedAt: Date.now()
    };
  }
  async function loadCanvas() { return read("canvas", null); }
  function scheduleCanvasSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      write("canvas", serializeCanvas()).catch(function (error) { app.events.emit("error", error); });
    }, 350);
  }

  app.services.store = {
    loadConfig: loadConfig,
    saveConfig: saveConfig,
    loadCanvas: loadCanvas,
    scheduleCanvasSave: scheduleCanvasSave,
    serializeCanvas: serializeCanvas
  };
})(window.vibedraw);
