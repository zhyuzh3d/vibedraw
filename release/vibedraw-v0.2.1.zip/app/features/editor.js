(function (app) {
  "use strict";
  var t = app.i18n.text, ui, canvas, initial, imageSource = "";
  function node(id) { return document.getElementById(id); }
  function init() {
    ui = app.components.ui; canvas = app.components.canvas;
    app.components.gallery.init({ newWork: newWork, resetWork: resetWork, syncAll: syncAll });
    initial = { objects: [], result: null, prompt: "", workId: "", workTitle: "", view: "overlay", background: "#ffffff", negativePrompt: app.config.canvas.negativePrompt || "", seed: -1, strength: 0.55, autoDelayMs: Number(app.config.canvas.autoDelayMs) || 850, includeResult: false, resultOpacity: 1, resultBrightness: 100, resultContrast: 100, resultSaturation: 100, resultHue: 0, resultGlow: 0, resultClarity: 0 };
    node("app-version").textContent = "v" + app.version;
    bindMenu(); bindTools(); bindOptions(); bindActions(); bindGeneration();
    app.events.on("canvas:rendered", syncCanvas);
    app.events.on("selection", syncSelection);
    app.events.on("tool", setTool);
    app.events.on("history", function (value) { node("undo").disabled = !value.undo; node("redo").disabled = !value.redo; });
    app.events.on("save", function (value) {
      node("save-state").textContent = value === "error" ? t("保存失败", "Save failed") : value === "saved" ? t("已保存", "Saved") : t("保存中…", "Saving…");
      syncTitle();
    });
    app.events.on("works:changed", function (count) { node("history-count").textContent = count; });
    app.events.on("preferences:changed", function () { syncAll(); status(defaultStatus()); });
    app.events.on("config:changed", function () { status(defaultStatus()); });
    app.events.on("result:filter", syncCanvas);
    app.events.on("color:changed", syncColors);
    syncAll(); resizeStage(); window.addEventListener("resize", resizeStage);
    window.addEventListener("pagehide", function () { app.services.store.flush().catch(function () {}); });
    document.addEventListener("visibilitychange", function () { if (document.hidden) app.services.store.flush().catch(function () {}); });
  }
  function resizeStage() {
    if (/INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
    var frame = node("stage-frame"), available = frame.parentNode.clientWidth;
    var side = Math.min(available, 510, Math.max(220, window.innerHeight - 326));
    frame.style.width = side + "px"; frame.style.height = side + "px";
  }
  function closeMenu() { node("app-menu").hidden = true; node("open-menu").setAttribute("aria-expanded", "false"); }
  function bindMenu() {
    node("open-menu").onclick = function (event) {
      event.stopPropagation(); var show = node("app-menu").hidden;
      node("app-menu").hidden = !show; node("open-menu").setAttribute("aria-expanded", String(show));
      if (show) node("app-menu").querySelector("button").focus({ preventScroll: true });
    };
    document.addEventListener("click", function (event) { if (!node("app-menu").contains(event.target) && !node("open-menu").contains(event.target)) closeMenu(); });
    node("app-menu").addEventListener("keydown", function (event) {
      var buttons = Array.prototype.slice.call(node("app-menu").querySelectorAll("button")), index = buttons.indexOf(document.activeElement);
      if (event.key === "Escape") { closeMenu(); node("open-menu").focus(); }
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault(); buttons[(index + (event.key === "ArrowDown" ? 1 : buttons.length - 1)) % buttons.length].focus();
      }
    });
    node("app-menu").querySelectorAll("[data-menu]").forEach(function (button) {
      button.onclick = ui.action(async function () { closeMenu(); if (button.dataset.menu === "history") await app.components.gallery.open(); else app.components.settings.open(button.dataset.menu); });
    });
  }
  function bindTools() {
    document.querySelectorAll("[data-tool]").forEach(function (button) { button.onclick = function () { setTool(button.dataset.tool); }; });
    document.querySelectorAll("[data-view]").forEach(function (button) {
      button.onclick = function () {
        if (button.dataset.view === "result" && !app.state.result) { ui.toast(t("生成后即可在这里查看成图", "Generate an image to view your result")); return; }
        app.state.view = button.dataset.view; syncCanvas(); app.services.store.scheduleCanvasSave();
      };
    });
    node("add-image").onclick = ui.action(async function () {
      var file = await app.platform.hermit.pickImage();
      if (file) { if (!file.cancelled) await canvas.addImage(file); }
      else node("fallback-file").click();
    });
    node("fallback-file").onchange = function (event) {
      var file = event.target.files && event.target.files[0]; event.target.value = "";
      if (!file) return;
      if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 12 * 1024 * 1024) { ui.toast(t("请选择 12 MB 以内的 PNG、JPEG 或 WebP", "Choose PNG, JPEG or WebP up to 12 MB"), "error"); return; }
      var reader = new FileReader(); reader.onload = function () { canvas.addImage({ url: reader.result, name: file.name }).catch(function (error) { app.events.emit("error", error); }); };
      reader.readAsDataURL(file);
    };
  }
  function setTool(tool, keepView) {
    if (["pencil", "brush", "eraser", "select", "mask"].indexOf(tool) < 0) return;
    app.state.tool = tool;
    if (!keepView && app.state.view === "result") app.state.view = "overlay";
    if (tool !== "select") app.state.selectedId = "";
    document.querySelectorAll("[data-tool]").forEach(function (button) {
      button.classList.toggle("is-active", button.dataset.tool === tool); button.setAttribute("aria-pressed", String(button.dataset.tool === tool));
    });
    node("draft-canvas").style.cursor = tool === "select" ? "grab" : "crosshair";
    node("draw-options").hidden = tool === "select"; node("selection-options").hidden = tool !== "select";
    node("stroke-color").hidden = tool === "eraser" || tool === "mask"; node("brush-more").hidden = tool === "eraser" || tool === "mask";
    node("size-label").textContent = tool === "mask" ? t("区域", "Area") : tool === "eraser" ? t("范围", "Size") : t("粗细", "Size");
    syncSelection(); canvas.render();
  }
  function bindOptions() {
    node("stroke-color").onclick = function () { app.components.settings.openColor("stroke"); };
    node("brush-size").oninput = function (event) { app.state.size = Number(event.target.value); node("brush-size-value").textContent = event.target.value; app.services.store.scheduleCanvasSave(); };
    node("background-color").onclick = function () { app.components.settings.openColor("background"); };
    node("prompt-input").oninput = function (event) {
      app.state.prompt = event.target.value; syncTitle(); app.services.store.scheduleCanvasSave(); app.services.imageEngine.schedule();
    };
    node("prompt-input").onkeydown = function (event) { if (event.key === "Enter") { event.preventDefault(); node("prompt-save").click(); } };
    node("prompt-save").onclick = ui.action(async function () { await app.services.store.flush(); ui.toast(t("画面描述已保存", "Prompt saved")); });
    node("brush-more").onclick = function () { app.components.settings.open("brush"); };
  }
  function bindActions() {
    node("undo").onclick = canvas.undo; node("redo").onclick = canvas.redo;
    node("delete-selected").onclick = canvas.removeSelected; node("duplicate-selected").onclick = canvas.duplicateSelected;
    node("layer-down").onclick = function () { canvas.moveLayer(-1); }; node("layer-up").onclick = function () { canvas.moveLayer(1); };
    node("scale-down").onclick = function () { canvas.scaleSelected(0.9); }; node("scale-up").onclick = function () { canvas.scaleSelected(1.1); };
    node("clear-canvas").onclick = ui.action(async function () {
      if (!app.state.objects.length) return;
      if (await ui.confirm({ title: t("清空草稿？", "Clear sketch?"), message: t("删除所有笔触与参考图，成图会保留。之后可以撤销。", "Remove strokes and reference images. The result stays. You can undo this."), ok: t("清空草稿", "Clear sketch"), danger: true })) canvas.clear();
    });
    node("auto-toggle").onclick = function () {
      app.state.autoGenerate = !app.state.autoGenerate;
      if (!app.state.autoGenerate) app.services.imageEngine.stopAuto();
      syncAuto(); app.services.store.scheduleCanvasSave();
      status(app.state.autoGenerate ? t("落笔后自动生成，费用由模型服务计算", "Auto-generate after drawing; provider charges may apply") : t("自动已关闭，点击生成按钮出图", "Auto is off. Tap Generate when ready."));
    };
    node("generate-quick").onclick = function () { app.services.imageEngine.run("quick", false); };
    node("generate-quality").onclick = function () { app.services.imageEngine.run("quality", false); };
    node("cancel-generation").onclick = function () { app.services.imageEngine.cancel(); status(t("已停止等待；服务端任务可能仍在运行", "Dismissed; the server task may still be running")); };
    node("work-settings").onclick = function () { app.components.settings.open("work"); };
    node("color-adjust").onclick = function () { app.components.settings.open("adjustments"); };
    node("rename-work").onclick = rename;
    node("export-image").onclick = exportOptions;
    document.addEventListener("keydown", function (event) {
      if (!node("modal-layer").hidden || !node("confirm-layer").hidden || /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) || document.activeElement.isContentEditable) return;
      var key = String(event.key).toLowerCase(), modifier = event.ctrlKey || event.metaKey;
      if (modifier && key === "z") { event.preventDefault(); event.shiftKey ? canvas.redo() : canvas.undo(); return; }
      if (modifier && key === "y") { event.preventDefault(); canvas.redo(); return; }
      if ((key === "delete" || key === "backspace") && app.state.tool === "select") { event.preventDefault(); canvas.removeSelected(); return; }
      if (modifier) return;
      var tool = { p: "pencil", b: "brush", e: "eraser", v: "select", m: "mask" }[key]; if (tool) setTool(tool);
    });
  }
  function bindGeneration() {
    app.events.on("generation:start", function (detail) {
      node("stage-busy").hidden = false;
      node("busy-label").textContent = detail.slot === "quality" ? t("精绘中，仍可继续画", "Refining · keep drawing") : t("生成中，仍可继续画", "Generating · keep drawing");
      node("generate-quick").disabled = true; node("generate-quality").disabled = true;
      status(t("正在处理当前画面…", "Processing your sketch…"));
    });
    app.events.on("generation:done", function () { syncCanvas(); status(t("成图已更新，作品自动保存", "Result updated · artwork saves automatically")); });
    app.events.on("generation:error", function (error) { status(t("生成失败，可修改设置后重试", "Generation failed. Adjust settings and retry.")); app.events.emit("error", error); });
    app.events.on("generation:idle", function () { node("stage-busy").hidden = true; node("generate-quick").disabled = false; node("generate-quality").disabled = false; });
    app.events.on("needs-config", function () { app.components.settings.open("models"); });
    app.events.on("status", status);
  }
  function syncSelection() {
    var id = app.state.selectedId, selected = app.state.objects.findIndex(function (object) { return object.id === id; });
    node("selection-hint").hidden = selected >= 0; node("selection-actions").hidden = selected < 0;
    node("selection-hint").textContent = t("轻点笔触或图片，拖动调整位置", "Tap a stroke or image, then drag to move");
    node("layer-down").disabled = selected <= 0; node("layer-up").disabled = selected < 0 || selected === app.state.objects.length - 1;
  }
  function syncCanvas() {
    var state = app.state, image = node("result-image"), glow = node("result-glow-image"), hasResult = Boolean(state.result && state.result.src), view = state.view;
    if (!hasResult && view === "result") { state.view = "overlay"; view = "overlay"; }
    if (hasResult && state.result.src !== imageSource) { imageSource = state.result.src; image.src = imageSource; glow.src = imageSource; }
    if (!hasResult && imageSource) { imageSource = ""; image.removeAttribute("src"); glow.removeAttribute("src"); }
    image.hidden = !hasResult || view === "sketch"; image.style.filter = canvas.resultFilter(); image.style.opacity = String(view === "result" ? 1 : state.resultOpacity);
    glow.hidden = !hasResult || view === "sketch" || Number(state.resultGlow) <= 0; glow.style.filter = canvas.resultGlowFilter(); glow.style.opacity = String((view === "result" ? 1 : state.resultOpacity) * Math.min(0.62, Number(state.resultGlow) / 150));
    node("draft-canvas").hidden = view === "result";
    node("stage-empty").hidden = state.objects.length > 0 || hasResult;
    node("clear-canvas").disabled = !state.objects.length;
    node("export-image").disabled = !state.objects.length && !hasResult;
    node("stage-badge").hidden = !hasResult || view === "sketch";
    node("stage-badge").textContent = hasResult && state.result.slot === "quality" ? t("高质量", "High quality") : t("实时预览", "Preview");
    document.querySelectorAll("[data-view]").forEach(function (button) { button.classList.toggle("is-active", button.dataset.view === view); button.setAttribute("aria-pressed", String(button.dataset.view === view)); });
  }
  function syncAuto() {
    var button = node("auto-toggle"); button.setAttribute("aria-pressed", String(app.state.autoGenerate));
    button.querySelector("span").textContent = app.state.autoGenerate ? t("自动", "Auto") : t("手动", "Manual");
  }
  function syncTitle() { node("work-title").textContent = app.state.workTitle || app.state.prompt.slice(0, 28) || t("未命名作品", "Untitled artwork"); }
  function syncColors() { node("stroke-color").style.backgroundColor = app.state.color; node("background-color").style.backgroundColor = app.state.background; }
  function syncAll() {
    app.i18n.dom(); syncTitle();
    syncColors(); node("brush-size").value = app.state.size; node("brush-size-value").textContent = app.state.size;
    node("prompt-input").value = app.state.prompt;
    node("history-count").textContent = app.services.store.list().length;
    node("save-state").textContent = app.services.store.meaningful() ? t("已保存", "Saved") : t("自动保存", "Autosave");
    syncAuto(); syncCanvas(); setTool(app.state.tool, true); resizeStage();
  }
  function resetWork() { canvas.load(app.utils.copy(initial)); app.state.tool = "pencil"; syncAll(); }
  async function newWork() {
    app.services.imageEngine.cancel(); await app.services.store.flush(); resetWork(); await app.services.store.flush(); ui.close(); status(defaultStatus());
    ui.toast(t("新画布已就绪，旧作已保存在历史中", "New canvas ready. Previous work is in Your artwork."));
  }
  function rename() {
    var root = ui.open({ mode: "center", title: t("作品名称", "Artwork title"), html: '<label class="field"><span>' + t("名称", "Title") + '</span><input id="work-name-input" maxlength="64" value="' + app.utils.escapeHtml(app.state.workTitle || app.state.prompt.slice(0, 28)) + '" placeholder="' + t("未命名作品", "Untitled artwork") + '"></label><div class="button-row"><button class="button button-secondary" data-cancel>' + t("取消", "Cancel") + '</button><button class="button button-primary" data-save>' + t("保存", "Save") + '</button></div>' });
    root.querySelector("[data-cancel]").onclick = ui.close;
    root.querySelector("[data-save]").onclick = ui.action(async function () { app.state.workTitle = root.querySelector("input").value.trim(); await app.services.store.flush(); syncTitle(); ui.close(); });
  }
  function exportOptions() {
    var native = app.platform.hermit.available(), result = app.state.result;
    var root = ui.open({ mode: "center", title: t("导出作品", "Export artwork"), html: '<p class="field-help">' + (native ? t("导出可在浏览器打开的 SVG 预览。原始成图以文件返回时，还可直接保留原格式。", "Export an SVG preview that opens in a browser. File-based results can also be exported in their original format.") : t("导出 PNG 图片。作品仍保留在历史中。", "Export a PNG. Your editable work stays in history.")) +
      '</p><div class="export-options"><button class="button button-secondary" data-export="sketch"><i class="fa-solid fa-pencil"></i>' + t("导出草稿", "Export sketch") + '</button><button class="button button-secondary" data-export="result"' + (!result ? " disabled" : "") + '><i class="fa-regular fa-image"></i>' + t("导出成图", "Export result") + '</button></div>' +
      (native && result && result.logicalFileId ? '<div class="button-row"><button class="button button-primary" data-original>' + t("导出原始图片", "Export original image") + '</button></div>' : '') });
    root.querySelectorAll("[data-export]").forEach(function (button) {
      button.onclick = ui.action(async function () { var response = await canvas.exportImage(button.dataset.export); if (!response || !response.cancelled) ui.toast(t("导出已完成", "Export complete")); });
    });
    if (root.querySelector("[data-original]")) root.querySelector("[data-original]").onclick = ui.action(async function () { await app.platform.hermit.current().files.export({ logicalFileId: result.logicalFileId }); });
  }
  function status(message) { node("status-line").textContent = String(message || ""); }
  function defaultStatus() { return app.services.imageEngine.configured("quick") ? t("画下轮廓，让灵感成形", "Sketch a shape. Bring your idea to life.") : t("先画也可以 · 在右上角菜单配置模型", "Start sketching · configure models in the menu"); }
  app.features.editor = { init: init, syncAll: syncAll, setTool: setTool, status: status, defaultStatus: defaultStatus, newWork: newWork, resetWork: resetWork, syncCanvas: syncCanvas };
})(window.vibedraw);
