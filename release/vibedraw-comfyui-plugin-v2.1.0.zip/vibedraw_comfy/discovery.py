"""Machine-readable discovery: what this server can run, and how to ask for it.

``GET /vibedraw/v1/plugins`` answers one question — *which pipelines are
available here, and what does each one accept?*  A client that knows nothing but
an address and a password can configure itself from this single call: it does
not have to be told which tasks exist, which sizes they take, which parameters
they carry, or whether they can read a Chinese prompt.

Why a second document instead of more keys in ``capabilities``
--------------------------------------------------------------
``capabilities.schema`` is ``vibedraw-comfy/v2`` and versions the *job* API.
That API did not change, so its version must not move — a client that compares
the string would reject a server that behaves exactly as before.  This document
carries its own version (``vibedraw-comfy/discovery/v1``) and states which API
schema it describes.

``capabilities`` additionally carries the same ``plugins`` list, so a client
that already calls it needs no second request.  That is an added key and
nothing else: every key ``capabilities`` used to return is still there, byte for
byte.

Single source of truth
----------------------
Everything below is derived from :data:`workflows.TASK_SPECS` and the settings
module.  A task added there appears here immediately, with its schema, its
language and its model, and there is no second table to forget.

Field order is meaningful
-------------------------
``schema.properties`` is emitted in the order a form should render it (prompt
before seed, size before steps).  JSON objects keep their document order in
every client that matters (Python dicts, JavaScript string keys), so the order
travels with the document and a client does not need a separate layout hint.
"""

from __future__ import annotations

from typing import Any, Callable

from . import settings as settings_module
from . import translate as translate_module
from . import workflows
from .version import __version__

SCHEMA = "vibedraw-comfy/discovery/v1"
#: The job API this document describes.  Unchanged since v2.
API_SCHEMA = "vibedraw-comfy/v2"
PLUGIN_ID = "vibedraw_comfy"
PLUGIN_LABEL = {"zh": "ComfyUI VibeDraw 插件", "en": "ComfyUI VibeDraw Plugin"}

API_ROOT = "/vibedraw/v1"
ENDPOINTS: dict[str, str] = {
    "plugins": f"{API_ROOT}/plugins",
    "capabilities": f"{API_ROOT}/capabilities",
    "jobs": f"{API_ROOT}/jobs",
    "job": f"{API_ROOT}/jobs/{{job_id}}",
    "output": f"{API_ROOT}/jobs/{{job_id}}/output/{{index}}",
    "cancel": f"{API_ROOT}/jobs/{{job_id}}/cancel",
    "translate": f"{API_ROOT}/translate",
}

#: How a task parameter's ``kind`` maps onto a JSON type.  A kind that is not
#: listed is reported as ``number``, which is what every current one is.
KIND_TYPES = {
    "reference": "number",
    "float": "number",
    "integer": "integer",
    "boolean": "boolean",
    "string": "string",
    "size": "array",
    "seed": "integer",
}

#: One resolver, provided by the HTTP layer, which is the only part that can see
#: ComfyUI's model folders.  It answers, for a task: which file drives it, under
#: which role, whether that file is actually installed, and what is missing.
Resolver = Callable[[str], dict[str, Any]]


def _required_roles(task: str) -> list[str]:
    """The model roles a task cannot run without."""
    if workflows.family(task) == workflows.QWEN_FAMILY:
        return list(settings_module.MODEL_ROLES)
    return ["checkpoint"]


def _property(name: str, type_name: str, **extra: Any) -> dict[str, Any]:
    value: dict[str, Any] = {"type": type_name}
    value.update({key: item for key, item in extra.items() if item is not None})
    return value


def _param_property(parameter: dict[str, Any]) -> dict[str, Any]:
    """One entry of ``params`` as a schema property.

    ``minimum`` / ``maximum`` / ``default`` are copied verbatim from the task
    spec, which is the same spec the HTTP layer validates a job against.  A
    client that renders a slider from these numbers can therefore never produce a
    request the server rejects for being out of range.
    """
    return _property(
        str(parameter["id"]),
        KIND_TYPES.get(str(parameter.get("kind")), "number"),
        title=dict(parameter.get("label") or {}),
        help=dict(parameter.get("help") or {}),
        default=parameter.get("default"),
        minimum=parameter.get("minimum"),
        maximum=parameter.get("maximum"),
        vibedraw_kind=parameter.get("kind"),
    )


def job_schema(task: str, english_only: bool) -> dict[str, Any]:
    """The JSON body ``POST /jobs`` accepts for this task.

    Not full JSON Schema — it is the subset a form needs: type, default, range,
    allowed values, and which fields are mandatory.

    ``required`` (a list, as in JSON Schema) is what the HTTP layer actually
    enforces: it answers ``bad_image`` / ``bad_mask`` when those are missing.  A
    prompt is deliberately *not* on that list even though every task wants one —
    an empty prompt is accepted, it simply draws whatever the reference implies —
    so ``prompt`` carries ``recommended`` instead.  Every property also carries
    ``required`` as a boolean so a renderer can mark one field without
    cross-referencing the list.
    """
    specification = workflows.spec(task)
    needs = specification["needs"]
    properties: dict[str, Any] = {}

    properties["task"] = _property(
        "task", "string", const=specification["id"], required=True,
        help={"zh": "任务名,与 plugins[].id 相同。", "en": "Task name; same as plugins[].id."},
    )
    properties["prompt"] = _property(
        "prompt", "string", default="", required=False, recommended=bool(needs.get("prompt")),
        language="en" if english_only else "any",
        help={
            "zh": "画面描述。" + ("这条任务的编码器只认英文,中文请先用 /translate 翻译。" if english_only
                                else "这条任务的编码器能读中文,不必先翻译。"),
            "en": "What to draw. " + ("This pipeline's text encoder only reads English; translate first via /translate."
                                      if english_only else "This pipeline's encoder reads Chinese; no translation needed."),
        },
    )
    properties["negative_prompt"] = _property(
        "negative_prompt", "string", default="", required=False,
        help={"zh": "不想出现的内容；cfg 为 1 的任务会忽略它。", "en": "What to avoid; a task sampled at cfg 1 ignores it."},
    )

    required = ["task"]
    if needs.get("image"):
        properties["image_base64"] = _property(
            "image_base64", "string", format="base64-image", required=True,
            help={"zh": "参考图,PNG/JPEG 的 base64,可直接给 data URL。",
                  "en": "Reference image as base64 PNG/JPEG; a data URL is accepted as-is."},
        )
        required.append("image_base64")
    if needs.get("mask"):
        properties["mask_base64"] = _property(
            "mask_base64", "string", format="base64-image", required=True,
            help={"zh": "蒙版,黑底白区,白色 = 要重画。",
                  "en": "Mask, black background with a white area; white means repaint."},
        )
        required.append("mask_base64")

    for parameter in specification["params"]:
        entry = _param_property(parameter)
        entry["required"] = False
        properties[str(parameter["id"])] = entry

    properties["size"] = _property(
        "size", "array", items="integer", length=2, enum=[list(value) for value in specification["sizes"]],
        default=list(specification["sizes"][0]), required=False,
        help={"zh": "画幅 [宽, 高],只能取 enum 里列出的值。", "en": "Canvas [width, height]; only the listed values are accepted."},
    )
    properties["steps"] = _property(
        "steps", "integer", enum=[int(value) for value in specification["steps"]["allowed"]],
        default=int(specification["steps"]["default"]), required=False,
        help={"zh": "采样步数,只能取 enum 里列出的值。", "en": "Sampling steps; only the listed values are accepted."},
    )
    properties["seed"] = _property(
        "seed", "integer", default=0, minimum=0, required=False,
        help={"zh": "0 表示每张都不一样；同一个 seed 可以复现。", "en": "0 means a new seed each run; the same seed reproduces."},
    )
    return {"type": "object", "required": required, "properties": properties}


def plugin_entry(task: str, model: dict[str, Any]) -> dict[str, Any]:
    """One pipeline, described well enough for a client to build a form."""
    specification = workflows.spec(task)
    english_only = bool(specification.get("english_only", True))
    return {
        "id": specification["id"],
        "kind": "pipeline",
        "family": workflows.family(task),
        "label": dict(specification["label"]),
        "description": dict(specification["description"]),
        # 是否只吃英文提示词。前端据此决定"用户写了中文要不要先翻译"。
        "english_only": english_only,
        "prompt_language": "en" if english_only else "any",
        "needs": dict(specification["needs"]),
        "sizes": [list(size) for size in specification["sizes"]],
        "steps": {
            "allowed": [int(value) for value in specification["steps"]["allowed"]],
            "default": int(specification["steps"]["default"]),
        },
        "params": [dict(parameter) for parameter in specification["params"]],
        "schema": job_schema(task, english_only),
        "model": dict(model),
        # 这条任务要哪几个模型槽位才算配好（checkpoint 一个,Qwen 那一族三个）。
        "model_roles": _required_roles(task),
        "ready": bool(model.get("ready")),
        "estimated_seconds": specification["estimated_seconds"],
    }


def plugins(resolve: Resolver) -> list[dict[str, Any]]:
    return [plugin_entry(task, resolve(task)) for task in workflows.task_ids()]


def prompt_policy(entries: list[dict[str, Any]]) -> dict[str, Any]:
    """What a client should do about Chinese prompts, in one object.

    ``english_only_pipelines`` lists exactly the ids that need translating, so a
    client can decide per job instead of translating everything or nothing.
    """
    description = translate_module.describe()
    return {
        "translate_endpoint": ENDPOINTS["translate"],
        "translate_available": bool(description.get("available")),
        "engine": str(description.get("engine") or ""),
        "target": "en",
        "rule": str(description.get("rule") or ""),
        "english_only_pipelines": [entry["id"] for entry in entries if entry["english_only"]],
        "any_language_pipelines": [entry["id"] for entry in entries if not entry["english_only"]],
    }


def document(*, resolve: Resolver, authorized: bool, auth_required: bool, auth_hint: str = "",
             checkpoints: list[str] | None = None) -> dict[str, Any]:
    """The whole discovery document.

    ``auth.required`` says whether the server wants a password at all;
    ``auth.authorized`` says whether the one that arrived was right.  That pair
    is what lets a client tell "wrong password" from "no password needed"
    without a second call, and it is why this endpoint answers even when the
    password is wrong — knowing *what* a server can do should not depend on
    having already configured it.
    """
    entries = plugins(resolve)
    return {
        "schema": SCHEMA,
        "api_schema": API_SCHEMA,
        "plugin": {"id": PLUGIN_ID, "label": dict(PLUGIN_LABEL), "version": __version__},
        "endpoints": dict(ENDPOINTS),
        "auth": {
            "required": bool(auth_required),
            "authorized": bool(authorized),
            "scheme": "Bearer",
            "header": "Authorization",
            "hint": auth_hint or "密码在 ComfyUI 的 VibeDraw 配置节点里设置。",
        },
        "plugins": entries,
        "prompt_policy": prompt_policy(entries),
        "checkpoints": [str(name) for name in (checkpoints or [])],
    }


__all__ = [
    "API_ROOT",
    "API_SCHEMA",
    "ENDPOINTS",
    "PLUGIN_ID",
    "SCHEMA",
    "document",
    "job_schema",
    "plugin_entry",
    "plugins",
    "prompt_policy",
]
