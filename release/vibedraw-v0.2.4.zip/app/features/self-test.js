(function (app) {
  "use strict";
  async function run() {
    if (window.location.hash !== "#self-test" || !app.platform.hermit.available()) return;
    var runtime = await app.platform.hermit.current().runtime.info();
    if (runtime.launchChannel !== "dev") return;
    var checks = {}, store = app.services.store, canvas = app.components.canvas, editor = app.features.editor, ui = app.components.ui;
    function step(name) { window.__vibedrawSelfTestProgress = name; }
    step("starting");
    await store.flush();
    var stale = store.list().filter(function (item) { return String(item.title || "").indexOf("DEV self-test ") === 0; });
    var currentStale = stale.some(function (item) { return item.id === app.state.workId; });
    for (var staleItem of stale) if (staleItem.id !== app.state.workId) await store.remove(staleItem.id);
    if (currentStale) {
      await store.remove(app.state.workId); editor.resetWork();
      var recoveredItem = store.list()[0];
      if (recoveredItem) { var recovered = await store.hydrate(await store.get(recoveredItem.id)); canvas.load(recovered); editor.syncAll(); }
      await store.flush();
    }
    var original = await store.loadCanvas(), config = app.utils.copy(app.config), originalTool = app.state.tool, tempId = "";
    try {
      step("drawing"); editor.resetWork(); app.state.autoGenerate = false; app.state.workTitle = "DEV self-test " + Date.now();
      app.state.autoDelayMs = 1320; app.state.resultGlow = 38; app.state.resultClarity = 24;
      app.config.quick.endpoint = ""; app.config.quality.endpoint = "";
      var target = document.getElementById("draft-canvas"), rect = target.getBoundingClientRect();
      var Type = window.PointerEvent || window.MouseEvent;
      function fire(name, x, y, pointerId, isPrimary) {
        target.dispatchEvent(new Type((window.PointerEvent ? "pointer" : "mouse") + name, { bubbles: true, isPrimary: isPrimary !== false, button: 0, pointerId: pointerId || 1, clientX: rect.left + rect.width * x, clientY: rect.top + rect.height * y }));
      }
      function stroke(tool, x, y) { editor.setTool(tool); fire("down", x, y); fire("move", x + 0.15, y + 0.15); fire("up", x + 0.15, y + 0.15); }
      stroke("pencil", .15, .15);
      checks.draw = app.state.objects.length === 1;
      canvas.undo(); checks.undo = app.state.objects.length === 0;
      canvas.redo(); checks.redo = app.state.objects.length === 1;
      editor.setTool("select"); fire("down", .2, .2); fire("up", .2, .2);
      checks.select = Boolean(app.state.selectedId);
      canvas.duplicateSelected(); canvas.scaleSelected(1.1); checks.transform = app.state.objects.length === 2;
      app.state.busy = true; stroke("brush", .4, .4); app.state.busy = false;
      checks.drawDuringGeneration = app.state.objects.length === 3;
      app.state.size = 60; stroke("mask", .7, .1);
      var mask = new Image(); mask.src = canvas.composeMask(true);
      await new Promise(function (resolve, reject) { mask.onload = resolve; mask.onerror = reject; });
      var probe = document.createElement("canvas"); probe.width = 768; probe.height = 768;
      var ctx = probe.getContext("2d"); ctx.drawImage(mask, 0, 0);
      checks.maskAlpha = ctx.getImageData(555, 94, 1, 1).data[3] < 20 && ctx.getImageData(20, 20, 1, 1).data[3] === 255;
      stroke("eraser", .7, .1);
      var erasedMask = new Image(); erasedMask.src = canvas.composeMask(true);
      await new Promise(function (resolve, reject) { erasedMask.onload = resolve; erasedMask.onerror = reject; });
      ctx.clearRect(0, 0, 768, 768); ctx.drawImage(erasedMask, 0, 0);
      checks.eraseMask = ctx.getImageData(555, 94, 1, 1).data[3] === 255;
      var tiny = document.createElement("canvas"); tiny.width = 16; tiny.height = 16; var tinyCtx = tiny.getContext("2d"); tinyCtx.fillStyle = "#36a9e8"; tinyCtx.fillRect(0, 0, 16, 16);
      var imageSrc = tiny.toDataURL("image/png");
      await canvas.addImage({ url: imageSrc, name: "self-test.png" });
      var imageObject = app.state.objects.find(function (object) { return object.type === "image"; });
      imageObject.x = 264; imageObject.y = 284; imageObject.width = 240; imageObject.height = 180; canvas.render(); canvas.commit();
      editor.setTool("select"); app.state.selectedId = imageObject.id; canvas.render();
      checks.imageHandles = canvas.selectionHandles().length === 4;
      var handle = canvas.selectionHandles()[3], initialWidth = imageObject.width, initialRatio = imageObject.width / imageObject.height;
      fire("down", handle.x / 768, handle.y / 768); fire("move", (handle.x + 76) / 768, (handle.y + 57) / 768); fire("up", (handle.x + 76) / 768, (handle.y + 57) / 768);
      checks.cornerResize = imageObject.width > initialWidth * 1.2 && Math.abs(imageObject.width / imageObject.height - initialRatio) < 0.01;
      var resizedWidth = imageObject.width; canvas.undo(); var undoneImage = app.state.objects.find(function (object) { return object.type === "image"; });
      checks.resizeUndo = Math.abs(undoneImage.width - initialWidth) < 1; canvas.redo(); imageObject = app.state.objects.find(function (object) { return object.type === "image"; });
      checks.resizeRedo = Math.abs(imageObject.width - resizedWidth) < 1;
      app.state.selectedId = imageObject.id; canvas.render();
      var centerX = (imageObject.x + imageObject.width / 2) / 768, centerY = (imageObject.y + imageObject.height / 2) / 768, pinchWidth = imageObject.width;
      fire("down", centerX - 0.06, centerY, 1, true); fire("down", centerX + 0.06, centerY, 2, false);
      fire("move", centerX - 0.1, centerY - 0.02, 1, true); fire("move", centerX + 0.1, centerY + 0.02, 2, false); fire("up", centerX + 0.1, centerY + 0.02, 2, false);
      checks.pinchScale = imageObject.width > pinchWidth * 1.45 && Math.abs(imageObject.width / imageObject.height - initialRatio) < 0.01;
      app.state.result = { src: imageSrc, slot: "quick", prompt: "self-test", createdAt: Date.now() };
      var prompt = document.getElementById("prompt-input"); prompt.value = "History and image round trip";
      prompt.dispatchEvent(new Event("input", { bubbles: true }));
      step("saving-assets"); await store.flush(); tempId = app.state.workId;
      var saved = await store.get(tempId);
      checks.noInlineImageData = JSON.stringify(saved).indexOf("data:image") < 0 && saved.result.asset.parts.length > 0;
      checks.historyCreated = store.list().some(function (item) { return item.id === tempId; });
      var count = app.state.objects.length;
      app.services.assets.clearCache();
      step("restoring"); editor.resetWork(); var restored = await store.restoreWork(tempId, false); canvas.load(restored); editor.syncAll();
      checks.filesystemReadback = restored.result.src === imageSrc;
      checks.restore = app.state.prompt === "History and image round trip" && app.state.objects.length === count && app.state.result.src === imageSrc;
      checks.fileSettingsRestore = app.state.autoDelayMs === 1320 && app.state.resultGlow === 38 && app.state.resultClarity === 24;
      checks.imageRestore = app.state.objects.some(function (object) { return object.type === "image" && object.src === imageSrc; });
      var workCount = store.list().length;
      await store.flush(); checks.noDuplicateAutosaves = store.list().length === workCount;
      step("gallery"); await app.components.gallery.open();
      checks.historyGallery = Boolean(document.querySelector('[data-work="' + tempId + '"] canvas'));
      var search = document.getElementById("history-search"); search.value = "not-found-" + Date.now(); search.dispatchEvent(new Event("input", { bubbles: true }));
      checks.historySearch = document.querySelectorAll(".art-card").length === 0; ui.close();
      step("settings"); app.components.settings.open("models");
      checks.twoModelTabs = document.querySelectorAll("[data-slot-tab]").length === 2;
      document.querySelector('[data-slot-tab="quality"]').click();
      checks.independentModelTabs = Boolean(document.querySelector('[data-model-card="quality"]'));
      checks.keyMasked = document.querySelector('[name="apiKey"]').type === "password";
      ui.close();
      app.components.settings.open("work");
      checks.workSettings = Boolean(document.querySelector('[name="strength"]') && document.querySelector('[name="seed"]') && document.querySelector('[name="autoDelayMs"]') && document.querySelector('[name="includeResult"]'));
      checks.workSettingsCentered = document.querySelector("#modal-layer .modal-sheet").classList.contains("centered"); ui.close();
      app.components.settings.open("adjustments");
      checks.colorAdjustments = Boolean(document.querySelector('[name="resultGlow"]') && document.querySelector('[name="resultClarity"]'));
      checks.roundRanges = getComputedStyle(document.querySelector('[name="resultGlow"]')).height === "28px"; ui.close();
      app.components.settings.openColor("background");
      checks.compactColorPicker = document.querySelectorAll('input[type="color"]').length === 0 && document.querySelectorAll('[name="red"],[name="green"],[name="blue"]').length === 3;
      ui.close();
      step("layout"); app.config.preferences = { theme: "dark", language: "en" }; app.i18n.theme(); editor.syncAll();
      checks.theme = document.documentElement.dataset.theme === "dark" && getComputedStyle(document.body).backgroundColor === "rgb(23, 25, 29)";
      checks.language = document.documentElement.lang === "en" && document.querySelector('[data-menu="history"] span').textContent === "Your artwork";
      var dialog = ui.open({ title: "Self-test", mode: "center", html: "<button>Test</button>" });
      checks.centerDialog = dialog.parentNode.classList.contains("centered"); ui.close();
      var confirm = ui.confirm({ title: "Self-test", message: "Cancel test" });
      document.getElementById("confirm-cancel").click(); checks.confirm = await confirm === false;
      app.components.settings.open("preferences"); checks.sheet = !document.querySelector("#modal-layer .modal-sheet").classList.contains("centered"); ui.close();
      var frame = document.getElementById("stage-frame").getBoundingClientRect();
      checks.layout = Math.abs(frame.width - frame.height) < 2 && document.documentElement.scrollWidth <= window.innerWidth;
      checks.promptAboveCanvas = document.querySelector(".prompt-panel").getBoundingClientRect().bottom < frame.top;
      checks.singleLinePrompt = document.getElementById("prompt-input").tagName === "INPUT" && !document.querySelector(".prompt-label") && Boolean(document.querySelector("#prompt-save .fa-floppy-disk"));
      checks.compactWorkHeading = !document.getElementById("new-work") && !document.getElementById("open-history") && Boolean(document.querySelector("#work-settings .fa-gear"));
      checks.canvasActionOrder = Array.prototype.map.call(document.querySelectorAll(".canvas-actions button"), function (button) { return button.id; }).join(",") === "color-adjust,undo,redo,clear-canvas" && Boolean(document.querySelector("#clear-canvas .fa-trash-can"));
      checks.colorButtons = document.querySelectorAll('input[type="color"]').length === 0 && getComputedStyle(document.getElementById("background-color")).borderRadius === "50%";
      document.body.classList.remove("keyboard-focus"); document.getElementById("work-settings").focus();
      checks.noTapOutline = getComputedStyle(document.getElementById("work-settings")).outlineStyle === "none";
      checks.brandLeft = document.querySelector(".brand").getBoundingClientRect().left <= 24 && document.getElementById("app-version").textContent === "v" + app.version;
      var generate = document.getElementById("generate-quality").getBoundingClientRect();
      checks.actionsVisible = generate.left >= 0 && generate.right <= window.innerWidth && generate.bottom <= window.innerHeight;
      checks.bridgeReady = Boolean(window.hermit.isReady);
    } catch (error) {
      checks.error = app.utils.cleanError(error);
    } finally {
      step("cleanup"); ui.close(); app.services.imageEngine.cancel();
      app.config = config; await store.saveConfig(config);
      canvas.load(original || { objects: [], result: null, prompt: "", workId: "", workTitle: "", view: "overlay" });
      app.state.tool = originalTool; app.i18n.theme(); editor.syncAll(); await store.flush();
      if (tempId) await store.remove(tempId);
      window.__vibedrawSelfTest = { version: app.version, passed: Object.keys(checks).every(function (key) { return checks[key] === true; }), checks: checks };
      window.__vibedrawSelfTestProgress = "complete";
      window.history.replaceState(null, "", window.location.pathname);
      editor.status(editor.defaultStatus());
    }
  }
  app.features.selfTest = { run: run };
})(window.vibedraw);
