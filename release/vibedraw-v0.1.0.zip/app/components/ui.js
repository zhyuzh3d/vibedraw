(function (app) {
  "use strict";

  var layer, content, title, eyebrow;
  var lastFocus = null;

  function init() {
    layer = document.getElementById("modal-layer");
    content = document.getElementById("modal-content");
    title = document.getElementById("modal-title");
    eyebrow = document.getElementById("modal-eyebrow");
    layer.querySelectorAll("[data-close-modal]").forEach(function (node) { node.addEventListener("click", close); });
    document.addEventListener("keydown", function (event) { if (event.key === "Escape" && !layer.hidden) close(); });
  }
  function open(options) {
    lastFocus = document.activeElement;
    title.textContent = options.title || "";
    eyebrow.textContent = options.eyebrow || "";
    content.innerHTML = options.html || "";
    layer.hidden = false;
    document.body.style.overflow = "hidden";
    var focus = content.querySelector("input, textarea, select, button");
    if (focus) setTimeout(function () { focus.focus(); }, 30);
    return content;
  }
  function close() {
    if (!layer || layer.hidden) return;
    layer.hidden = true;
    content.innerHTML = "";
    document.body.style.overflow = "";
    if (lastFocus && lastFocus.focus) lastFocus.focus();
    lastFocus = null;
  }
  function toast(message, type) {
    var node = document.createElement("div");
    node.className = "toast" + (type ? " " + type : "");
    node.textContent = String(message || "");
    document.getElementById("toast-stack").appendChild(node);
    setTimeout(function () { node.remove(); }, type === "error" ? 5200 : 2600);
  }
  function action(handler) {
    return async function (event) {
      var button = event && event.currentTarget;
      if (button) button.disabled = true;
      try { await handler(event); } catch (error) { toast(app.utils.cleanError(error), "error"); }
      finally { if (button && button.isConnected) button.disabled = false; }
    };
  }

  app.components.ui = { init: init, open: open, close: close, toast: toast, action: action };
})(window.vibedraw);
