(function (app) {
  "use strict";

  var ui;
  var draft;
  var activeTab = "models";

  function init() { ui = app.components.ui; }
  function open(tab) {
    draft = app.utils.copy(app.config || app.defaults);
    activeTab = tab || "models";
    render();
  }
  function render() {
    var root = ui.open({
      eyebrow: "VibeDraw",
      title: activeTab === "models" ? "模型设置" : activeTab === "canvas" ? "画面参数" : "使用说明",
      html: tabs() + (activeTab === "models" ? modelsHtml() : activeTab === "canvas" ? canvasHtml() : aboutHtml())
    });
    bindTabs(root);
    if (activeTab === "models") bindModels(root);
    else if (activeTab === "canvas") bindCanvas(root);
  }
  function tabs() {
    return '<div class="section-tabs" role="tablist">' +
      tabButton("models", "模型") + tabButton("canvas", "画面") + tabButton("about", "说明") + '</div>';
  }
  function tabButton(id, label) { return '<button type="button" data-settings-tab="' + id + '" class="' + (activeTab === id ? 'is-active' : '') + '">' + label + '</button>'; }
  function bindTabs(root) {
    root.querySelectorAll("[data-settings-tab]").forEach(function (button) {
      button.addEventListener("click", function () { activeTab = button.dataset.settingsTab; render(); });
    });
  }
  function protocolOptions(selected) {
    return app.services.providers.protocols.map(function (item) {
      return '<option value="' + item.id + '"' + (item.id === selected ? ' selected' : '') + '>' + app.utils.escapeHtml(item.name) + '</option>';
    }).join("");
  }
  function inputModeOptions(selected) {
    return '<option value="sketch"' + (selected === "sketch" ? ' selected' : '') + '>草图 / 画面编辑</option>' +
      '<option value="text"' + (selected === "text" ? ' selected' : '') + '>仅文生图</option>';
  }
  function modelCard(slot) {
    var model = draft[slot], quality = slot === "quality", protocol = model.protocol;
    var protocolInfo = app.services.providers.protocols.find(function (item) { return item.id === protocol; }) || {};
    var comfy = protocol === "comfyui";
    return '<article class="model-card" data-model-card="' + slot + '">' +
      '<div class="model-card-header"><div><h3>' + (quality ? '高质量模型' : '实时快速模型') + '</h3><p>' + (quality ? '用于最终成图，允许更长等待' : '用于落笔后的快速预览，建议选低步数模型') + '</p></div><span class="slot-badge ' + (quality ? 'quality' : '') + '">' + (quality ? 'QUALITY' : 'LIVE') + '</span></div>' +
      '<div class="form-grid two-columns">' +
      fieldSelect(slot, "protocol", "接口模式", protocolOptions(protocol)) +
      fieldSelect(slot, "inputMode", "输入方式", inputModeOptions(model.inputMode)) +
      '</div><p class="field-help">' + app.utils.escapeHtml(protocolInfo.description || "") + '</p>' +
      fieldInput(slot, "endpoint", "服务地址", model.endpoint, "url", "完整地址；HTTP 仅允许可信局域网") +
      secretField(slot, model.apiKey) +
      fieldInput(slot, "model", comfy ? "模型说明" : "模型 ID", model.model, "text", comfy ? "实际 checkpoint 由 workflow 决定" : "例如 gpt-image-1 或 checkpoint 名称") +
      '<details class="advanced"><summary>高级设置</summary>' +
      '<div class="field-row">' + numberField(slot, "width", "宽度", model.width, 256, 2048) + numberField(slot, "height", "高度", model.height, 256, 2048) + '</div>' +
      '<div class="field-row">' + numberField(slot, "steps", "采样步数", model.steps, 1, 150) + numberField(slot, "timeoutMs", "超时毫秒", model.timeoutMs, 5000, 300000) + '</div>' +
      fieldInput(slot, "quality", "质量参数", model.quality, "text", "OpenAI 兼容接口常用 low / medium / high / auto") +
      textArea(slot, "customHeaders", "自定义 Header JSON", model.customHeaders, '{"X-API-Key":"..."}') +
      (comfy ? textArea(slot, "workflow", "ComfyUI API workflow JSON", model.workflow, '支持 {{prompt}}、{{negative_prompt}}、{{image}}、{{seed}}、{{steps}}、{{width}}、{{height}}、{{denoise}}') : '') +
      '</details><p class="connection-status" data-test-status="' + slot + '"></p>' +
      '<div class="button-row"><button class="button-secondary" type="button" data-test-slot="' + slot + '"><i class="fa-solid fa-plug" aria-hidden="true"></i> 测试连接</button></div>' +
      '</article>';
  }
  function modelsHtml() {
    return '<div class="notice">两个槽位完全独立，可以连接不同服务。API Key 只在点击“保存模型设置”后写入当前 happ 的隔离数据；页面调用模型时仍可读取它，因此只加载你信任的 happ 代码。</div>' +
      modelCard("quick") + modelCard("quality") +
      '<div class="button-row"><button class="button-secondary" type="button" data-close-settings>取消</button><button class="button-primary" type="button" data-save-models>保存模型设置</button></div>';
  }
  function fieldInput(slot, name, label, value, type, placeholder) {
    return '<label class="field"><span>' + label + '</span><input data-slot="' + slot + '" name="' + name + '" type="' + type + '" value="' + app.utils.escapeHtml(value || "") + '" placeholder="' + app.utils.escapeHtml(placeholder || "") + '"></label>';
  }
  function fieldSelect(slot, name, label, options) {
    return '<label class="field"><span>' + label + '</span><select data-slot="' + slot + '" name="' + name + '">' + options + '</select></label>';
  }
  function numberField(slot, name, label, value, min, max) {
    return '<label class="field"><span>' + label + '</span><input data-slot="' + slot + '" name="' + name + '" type="number" min="' + min + '" max="' + max + '" value="' + Number(value || 0) + '"></label>';
  }
  function textArea(slot, name, label, value, placeholder) {
    return '<label class="field"><span>' + label + '</span><textarea data-slot="' + slot + '" name="' + name + '" placeholder="' + app.utils.escapeHtml(placeholder || "") + '">' + app.utils.escapeHtml(value || "") + '</textarea></label>';
  }
  function secretField(slot, value) {
    return '<label class="field"><span>API Key</span><div class="secret-input"><input data-slot="' + slot + '" name="apiKey" type="password" autocomplete="off" value="' + app.utils.escapeHtml(value || "") + '" placeholder="局域网免鉴权服务可留空"><button type="button" data-toggle-secret aria-label="显示密钥"><i class="fa-solid fa-eye"></i></button><button type="button" data-paste-secret aria-label="粘贴密钥"><i class="fa-solid fa-paste"></i></button></div></label>';
  }
  function readField(field) {
    var slot = field.dataset.slot, name = field.name, value = field.value;
    if (["width", "height", "steps", "timeoutMs"].indexOf(name) >= 0) value = Number(value);
    draft[slot][name] = value;
  }
  function bindModels(root) {
    root.querySelectorAll("[data-slot]").forEach(function (field) {
      field.addEventListener("input", function () { readField(field); });
      field.addEventListener("change", function () {
        var oldProtocol = draft[field.dataset.slot].protocol;
        readField(field);
        if (field.name === "protocol" && field.value !== oldProtocol) {
          draft[field.dataset.slot] = app.services.providers.preset(field.value, field.dataset.slot);
          render();
        }
      });
    });
    root.querySelectorAll("[data-toggle-secret]").forEach(function (button) {
      button.addEventListener("click", function () {
        var input = button.parentNode.querySelector("input"), showing = input.type === "text";
        input.type = showing ? "password" : "text";
        button.innerHTML = '<i class="fa-solid fa-' + (showing ? 'eye' : 'eye-slash') + '"></i>';
        button.setAttribute("aria-label", showing ? "显示密钥" : "隐藏密钥");
      });
    });
    root.querySelectorAll("[data-paste-secret]").forEach(function (button) {
      button.addEventListener("click", ui.action(async function () {
        var input = button.parentNode.querySelector("input");
        input.value = String(await app.platform.hermit.clipboardRead()).trim();
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.focus(); input.select();
      }));
    });
    root.querySelectorAll("[data-test-slot]").forEach(function (button) {
      button.addEventListener("click", ui.action(async function () {
        var slot = button.dataset.testSlot, status = root.querySelector('[data-test-status="' + slot + '"]');
        status.textContent = "正在执行不生成图片的连接测试…";
        await app.services.providers.test(draft[slot]);
        status.textContent = "连接成功，服务已响应。";
        ui.toast((slot === "quick" ? "实时模型" : "高质量模型") + "连接成功");
      }));
    });
    root.querySelector("[data-close-settings]").addEventListener("click", ui.close);
    root.querySelector("[data-save-models]").addEventListener("click", ui.action(async function () {
      ["quick", "quality"].forEach(function (slot) {
        app.utils.validateEndpoint(draft[slot].endpoint);
        app.utils.parseHeaders(draft[slot].customHeaders || "");
      });
      await app.services.store.saveConfig(draft);
      ui.close(); ui.toast("模型设置已保存");
      app.events.emit("config:changed", app.config);
    }));
  }
  function canvasHtml() {
    var canvas = draft.canvas || {}, state = app.state;
    return '<div class="model-card"><div class="model-card-header"><div><h3>生成控制</h3><p>这些参数同时作用于两个模型槽位</p></div></div>' +
      '<label class="field"><span>负面提示词</span><textarea name="negativePrompt" data-canvas-field placeholder="不希望画面出现的内容">' + app.utils.escapeHtml(state.negativePrompt || canvas.negativePrompt || "") + '</textarea></label>' +
      '<label class="field"><span>草图影响强度 <strong data-strength-value>' + Math.round(state.strength * 100) + '%</strong></span><input name="strength" data-canvas-field type="range" min="0" max="100" value="' + Math.round(state.strength * 100) + '"></label>' +
      '<div class="field-row">' +
      '<label class="field"><span>随机种子</span><input name="seed" data-canvas-field type="number" min="-1" max="2147483647" value="' + Number(state.seed) + '"></label>' +
      '<label class="field"><span>自动生成延迟（毫秒）</span><input name="autoDelayMs" data-canvas-field type="number" min="400" max="5000" value="' + Number(canvas.autoDelayMs || 850) + '"></label>' +
      '</div>' +
      '<label class="switch-row"><span><strong>叠加上次生成结果</strong><small>把上次结果与草图一起作为下一次输入</small></span><input name="includeResult" data-canvas-field type="checkbox"' + (state.includeResult ? ' checked' : '') + '></label>' +
      '<label class="field"><span>结果叠加强度 <strong data-result-opacity-value>' + Math.round(state.resultOpacity * 100) + '%</strong></span><input name="resultOpacity" data-canvas-field type="range" min="10" max="100" value="' + Math.round(state.resultOpacity * 100) + '"' + (!state.includeResult ? ' disabled' : '') + '></label>' +
      '<div class="model-card-header filter-heading"><div><h3>结果调色</h3><p>只调整当前 AI 结果的显示、叠加输入与导出，不改变原始返回文件</p></div></div>' +
      filterField("resultBrightness", "亮度", state.resultBrightness, 40, 180, "%") +
      filterField("resultContrast", "对比度", state.resultContrast, 40, 180, "%") +
      filterField("resultSaturation", "饱和度", state.resultSaturation, 0, 220, "%") +
      filterField("resultHue", "色相", state.resultHue, -180, 180, "°") +
      '<div class="button-row"><button class="button-secondary" type="button" data-reset-filters>重置调色</button></div>' +
      '<div class="button-row"><button class="button-primary" type="button" data-save-canvas>应用参数</button></div></div>';
  }
  function filterField(name, label, value, min, max, suffix) {
    return '<label class="field"><span>' + label + ' <strong data-filter-value="' + name + '">' + Number(value) + suffix + '</strong></span><input name="' + name + '" data-filter-field type="range" min="' + min + '" max="' + max + '" value="' + Number(value) + '"></label>';
  }
  function bindCanvas(root) {
    var strength = root.querySelector('[name="strength"]'), opacity = root.querySelector('[name="resultOpacity"]'), include = root.querySelector('[name="includeResult"]');
    strength.addEventListener("input", function () { root.querySelector("[data-strength-value]").textContent = strength.value + "%"; });
    opacity.addEventListener("input", function () { root.querySelector("[data-result-opacity-value]").textContent = opacity.value + "%"; });
    include.addEventListener("change", function () { opacity.disabled = !include.checked; });
    root.querySelectorAll("[data-filter-field]").forEach(function (field) {
      field.addEventListener("input", function () {
        var suffix = field.name === "resultHue" ? "°" : "%";
        root.querySelector('[data-filter-value="' + field.name + '"]').textContent = field.value + suffix;
      });
    });
    root.querySelector("[data-reset-filters]").addEventListener("click", function () {
      [["resultBrightness", 100], ["resultContrast", 100], ["resultSaturation", 100], ["resultHue", 0]].forEach(function (entry) {
        var field = root.querySelector('[name="' + entry[0] + '"]');
        field.value = entry[1]; field.dispatchEvent(new Event("input", { bubbles: true }));
      });
    });
    root.querySelector("[data-save-canvas]").addEventListener("click", ui.action(async function () {
      app.state.negativePrompt = root.querySelector('[name="negativePrompt"]').value.trim();
      app.state.strength = Number(strength.value) / 100;
      app.state.seed = Number(root.querySelector('[name="seed"]').value);
      app.state.includeResult = include.checked;
      app.state.resultOpacity = Number(opacity.value) / 100;
      ["resultBrightness", "resultContrast", "resultSaturation", "resultHue"].forEach(function (name) {
        app.state[name] = Number(root.querySelector('[name="' + name + '"]').value);
      });
      draft.canvas.negativePrompt = app.state.negativePrompt;
      draft.canvas.autoDelayMs = Math.max(400, Number(root.querySelector('[name="autoDelayMs"]').value) || 850);
      draft.canvas.includeResult = app.state.includeResult;
      draft.canvas.resultOpacity = app.state.resultOpacity;
      await app.services.store.saveConfig(draft);
      app.events.emit("result:filter", app.components.canvas.resultFilter());
      app.services.store.scheduleCanvasSave();
      ui.close(); ui.toast("画面参数已应用");
    }));
  }
  function aboutHtml() {
    return '<div class="help-copy"><h3>基本流程</h3><ol><li>先在“模型”里分别配置实时模型和高质量模型。</li><li>用铅笔或涂色笔画出轮廓，填写提示词。</li><li>开启“自动”后，每次落笔会合并触发实时模型；高质量按钮始终需要手动点击。</li><li>切换到“局部”后涂出粉色区域，支持蒙版的接口只修改该区域。</li></ol>' +
      '<h3>局域网模型</h3><p>SD WebUI / Forge 默认使用 <code>/sdapi/v1/img2img</code>。ComfyUI 需要从桌面界面导出 API workflow，并在其中使用占位符；happ 会先上传草图，再提交整个 workflow。</p>' +
      '<h3>隐私与费用</h3><p>草图只在生成时发送给你配置的服务。自动模式可能产生连续请求；当前实现会合并快速操作并保持最多一个在途请求，但模型费用仍由你的服务商计算。</p>' +
      '<p class="danger-note">不要把 API Key 写进 workflow、自定义地址或分享截图中。线上实时运行只应加载你信任的代码来源。</p></div>';
  }

  app.components.settings = { init: init, open: open };
})(window.vibedraw);
