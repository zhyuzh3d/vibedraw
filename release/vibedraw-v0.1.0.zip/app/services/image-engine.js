(function (app) {
  "use strict";

  var timer = 0;
  var running = false;
  var queuedSlot = "";
  var generation = 0;

  function configured(slot) {
    var config = app.config && app.config[slot];
    if (!config || !config.endpoint) return false;
    if (["openai-images", "stability"].indexOf(config.protocol) >= 0 && !config.apiKey) return false;
    if (config.protocol === "comfyui" && !config.workflow) return false;
    return true;
  }
  function schedule() {
    if (!app.state.autoGenerate || !configured("quick")) return;
    clearTimeout(timer);
    timer = setTimeout(function () { run("quick", true); }, Number(app.config.canvas.autoDelayMs) || 850);
  }
  async function run(slot, automatic) {
    clearTimeout(timer);
    if (running) {
      queuedSlot = slot === "quality" ? "quality" : queuedSlot || "quick";
      app.events.emit("status", "已记录最新画面，当前生成结束后继续");
      return;
    }
    if (!configured(slot)) {
      app.events.emit("needs-config", slot);
      if (!automatic) app.events.emit("error", new Error("请先配置并保存" + (slot === "quick" ? "实时快速" : "高质量") + "模型"));
      return;
    }
    var prompt = String(app.state.prompt || "").trim();
    if (!prompt) {
      if (!automatic) app.events.emit("error", new Error("请先描述你想生成的画面"));
      return;
    }
    running = true;
    queuedSlot = "";
    var currentGeneration = ++generation;
    app.state.busy = true;
    app.events.emit("generation:start", { slot: slot });
    try {
      var input = {
        prompt: prompt,
        negativePrompt: app.state.negativePrompt,
        seed: app.state.seed,
        strength: app.state.strength,
        imageDataUrl: await app.components.canvas.composeInput(),
        maskDataUrl: app.components.canvas.composeMask(false),
        openAiMaskDataUrl: app.components.canvas.composeMask(true)
      };
      var result = await app.services.providers.generate(app.config[slot], input);
      if (currentGeneration === generation) {
        app.state.result = {
          src: result.src,
          logicalFileId: result.logicalFileId || "",
          slot: slot,
          prompt: prompt,
          createdAt: Date.now(),
          metadata: result.metadata || {}
        };
        app.events.emit("generation:done", app.state.result);
      }
    } catch (error) {
      if (currentGeneration === generation) app.events.emit("generation:error", error);
    } finally {
      running = false;
      app.state.busy = false;
      app.events.emit("generation:idle", {});
      if (queuedSlot) {
        var next = queuedSlot;
        queuedSlot = "";
        setTimeout(function () { run(next, true); }, 60);
      }
    }
  }

  app.services.imageEngine = { schedule: schedule, run: run, configured: configured };
})(window.vibedraw);
