(function (app) {
  "use strict";

  var state = app.state;
  var canvas, context;
  var drawingObject = null;
  var dragging = null;
  var resizing = null;
  var pinching = null;
  var activePointers = {};
  var imageCache = {};
  var WIDTH = 768;
  var HANDLE_DRAW_RADIUS = 16;
  var HANDLE_HIT_RADIUS = 36;
  var MIN_IMAGE_SIZE = 48;
  var MAX_IMAGE_SIZE = WIDTH * 3;

  function resultFilter() {
    var clarity = Number(state.resultClarity) || 0;
    return "brightness(" + Math.max(20, Number(state.resultBrightness) + clarity * 0.08) + "%) contrast(" + Math.max(20, Number(state.resultContrast) + clarity * 0.38) + "%) saturate(" + Math.max(0, Number(state.resultSaturation) + clarity * 0.12) + "%) hue-rotate(" + Number(state.resultHue) + "deg)";
  }
  function resultGlowFilter() {
    var glow = Number(state.resultGlow) || 0;
    return resultFilter() + " blur(" + (1 + glow * 0.1) + "px) brightness(" + (108 + glow * 0.45) + "%) saturate(" + (105 + glow * 0.35) + "%)";
  }
  function drawResult(ctx, image, width, height, contained) {
    var alpha = ctx.globalAlpha;
    function paint() { if (contained) drawContained(ctx, image, width, height); else ctx.drawImage(image, 0, 0, width, height); }
    ctx.save(); ctx.filter = resultFilter(); paint(); ctx.restore();
    var glow = Number(state.resultGlow) || 0;
    if (glow > 0) {
      ctx.save(); ctx.globalCompositeOperation = "screen"; ctx.globalAlpha = alpha * Math.min(0.62, glow / 150); ctx.filter = resultGlowFilter(); paint(); ctx.restore();
    }
  }

  function init() {
    canvas = document.getElementById("draft-canvas");
    context = canvas.getContext("2d");
    bindInput();
    render();
    resetHistory();
  }
  function bindInput() {
    if (window.PointerEvent) {
      canvas.addEventListener("pointerdown", start);
      canvas.addEventListener("pointermove", move);
      canvas.addEventListener("pointerup", end);
      canvas.addEventListener("pointercancel", end);
    } else {
      canvas.addEventListener("mousedown", start);
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", end);
      canvas.addEventListener("touchstart", start, { passive: false });
      canvas.addEventListener("touchmove", move, { passive: false });
      canvas.addEventListener("touchend", end, { passive: false });
    }
  }
  function pointFromSource(source) {
    var rect = canvas.getBoundingClientRect();
    return { x: (source.clientX - rect.left) * WIDTH / rect.width, y: (source.clientY - rect.top) * WIDTH / rect.height };
  }
  function point(event) { return pointFromSource(event.touches && event.touches[0] || event.changedTouches && event.changedTouches[0] || event); }
  function touchPair(event) {
    if (!event.touches || event.touches.length < 2) return null;
    return [pointFromSource(event.touches[0]), pointFromSource(event.touches[1])];
  }
  function start(event) {
    if (event.button !== undefined && event.button !== 0) return;
    if (state.tool !== "select" && event.isPrimary === false) return;
    event.preventDefault();
    if (event.pointerId !== undefined && canvas.setPointerCapture && event.isTrusted) canvas.setPointerCapture(event.pointerId);
    var p = point(event);
    if (state.tool === "select") {
      if (event.pointerId !== undefined) activePointers[event.pointerId] = p;
      var pair = event.pointerId === undefined ? touchPair(event) : pointerPair();
      var current = selectedObject();
      if (pair && current && current.type === "image" && insideImage(pair[0], current, HANDLE_HIT_RADIUS) && insideImage(pair[1], current, HANDLE_HIT_RADIUS)) {
        beginPinch(current, pair); render(); return;
      }
      if (event.pointerId !== undefined && Object.keys(activePointers).length > 1) return;
      var handle = current && current.type === "image" ? hitHandle(p, current) : null;
      if (handle) {
        resizing = beginResize(current, handle, event.pointerId); dragging = null; render(); return;
      }
      var selected = hitTest(p);
      state.selectedId = selected ? selected.id : "";
      dragging = selected ? { object: selected, x: p.x, y: p.y, moved: false, pointerId: event.pointerId } : null;
      render();
      app.events.emit("selection", state.selectedId);
      return;
    }
    state.selectedId = "";
    drawingObject = {
      id: app.utils.id("stroke"),
      type: "stroke",
      tool: state.tool,
      color: state.tool === "mask" ? "#ee4f85" : state.color,
      width: state.tool === "pencil" ? Math.max(1, Math.round(state.size / 3)) : state.tool === "eraser" ? Math.max(8, state.size * 1.6) : state.size,
      opacity: state.tool === "brush" ? Math.min(state.opacity, 0.42) : state.tool === "mask" ? 0.55 : state.tool === "eraser" ? 1 : state.opacity,
      points: [p]
    };
    state.objects.push(drawingObject);
    render();
  }
  function move(event) {
    if (event.pointerId !== undefined && activePointers[event.pointerId]) activePointers[event.pointerId] = point(event);
    if (pinching) {
      var pair = event.pointerId === undefined ? touchPair(event) : pointerPair();
      if (pair) { event.preventDefault(); applyPinch(pair); render(); }
      return;
    }
    if (!drawingObject && !dragging && !resizing) return;
    event.preventDefault();
    var p = point(event);
    if (drawingObject) {
      var points = drawingObject.points, last = points[points.length - 1];
      if (distance(last, p) >= 1.5) points.push(p);
      render();
      return;
    }
    if (resizing) {
      if (resizing.pointerId !== undefined && event.pointerId !== resizing.pointerId) return;
      resizeTo(p); render(); return;
    }
    if (dragging.pointerId !== undefined && event.pointerId !== dragging.pointerId) return;
    var dx = p.x - dragging.x, dy = p.y - dragging.y;
    if (Math.abs(dx) + Math.abs(dy) < 0.25) return;
    translate(dragging.object, dx, dy);
    dragging.x = p.x; dragging.y = p.y; dragging.moved = true;
    render();
  }
  function end(event) {
    if (event && event.pointerId !== undefined) delete activePointers[event.pointerId];
    if (pinching) {
      if (event && event.preventDefault) event.preventDefault();
      var pinchChanged = pinching.changed; pinching = null; dragging = null; resizing = null; activePointers = {};
      if (pinchChanged) commit();
      return;
    }
    if (event && event.preventDefault && (drawingObject || dragging || resizing)) event.preventDefault();
    if (resizing && resizing.pointerId !== undefined && event && event.pointerId !== undefined && event.pointerId !== resizing.pointerId) return;
    if (dragging && dragging.pointerId !== undefined && event && event.pointerId !== undefined && event.pointerId !== dragging.pointerId) return;
    var changed = Boolean(drawingObject || dragging && dragging.moved || resizing && resizing.changed);
    drawingObject = null;
    dragging = null;
    resizing = null;
    if (changed) commit();
  }
  function translate(object, dx, dy) {
    if (object.type === "stroke") object.points.forEach(function (p) { p.x += dx; p.y += dy; });
    else { object.x += dx; object.y += dy; }
  }
  function distance(a, b) { var dx = a.x - b.x, dy = a.y - b.y; return Math.sqrt(dx * dx + dy * dy); }
  function midpoint(a, b) { return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; }
  function pointerPair() {
    var ids = Object.keys(activePointers);
    return ids.length >= 2 ? [activePointers[ids[0]], activePointers[ids[1]]] : null;
  }
  function insideImage(p, object, padding) {
    return p.x >= object.x - padding && p.x <= object.x + object.width + padding && p.y >= object.y - padding && p.y <= object.y + object.height + padding;
  }
  function selectionHandles(object) {
    if (!object || object.type !== "image") return [];
    return [
      { key: "nw", x: object.x, y: object.y }, { key: "ne", x: object.x + object.width, y: object.y },
      { key: "sw", x: object.x, y: object.y + object.height }, { key: "se", x: object.x + object.width, y: object.y + object.height }
    ];
  }
  function hitHandle(p, object) {
    var handles = selectionHandles(object);
    for (var index = 0; index < handles.length; index += 1) if (distance(p, handles[index]) <= HANDLE_HIT_RADIUS) return handles[index];
    return null;
  }
  function beginResize(object, handle, pointerId) {
    var opposite = { x: handle.key.indexOf("w") >= 0 ? object.x + object.width : object.x, y: handle.key.indexOf("n") >= 0 ? object.y + object.height : object.y };
    var vector = { x: handle.x - opposite.x, y: handle.y - opposite.y };
    return { object: object, key: handle.key, opposite: opposite, vector: vector, squared: vector.x * vector.x + vector.y * vector.y,
      width: object.width, height: object.height, pointerId: pointerId, changed: false };
  }
  function resizeTo(p) {
    var transform = resizing, vector = transform.vector;
    var factor = ((p.x - transform.opposite.x) * vector.x + (p.y - transform.opposite.y) * vector.y) / Math.max(1, transform.squared);
    var minimum = Math.max(MIN_IMAGE_SIZE / transform.width, MIN_IMAGE_SIZE / transform.height);
    var maximum = Math.min(MAX_IMAGE_SIZE / transform.width, MAX_IMAGE_SIZE / transform.height);
    factor = Math.max(minimum, Math.min(maximum, factor));
    var width = transform.width * factor, height = transform.height * factor;
    transform.object.width = width; transform.object.height = height;
    transform.object.x = transform.key.indexOf("w") >= 0 ? transform.opposite.x - width : transform.opposite.x;
    transform.object.y = transform.key.indexOf("n") >= 0 ? transform.opposite.y - height : transform.opposite.y;
    transform.changed = Math.abs(factor - 1) > 0.002;
  }
  function beginPinch(object, pair) {
    var center = midpoint(pair[0], pair[1]);
    pinching = { object: object, distance: Math.max(1, distance(pair[0], pair[1])), center: center,
      objectCenter: { x: object.x + object.width / 2, y: object.y + object.height / 2 }, width: object.width, height: object.height, changed: false };
    dragging = null; resizing = null;
  }
  function applyPinch(pair) {
    var transform = pinching, center = midpoint(pair[0], pair[1]);
    var factor = distance(pair[0], pair[1]) / transform.distance;
    var minimum = Math.max(MIN_IMAGE_SIZE / transform.width, MIN_IMAGE_SIZE / transform.height);
    var maximum = Math.min(MAX_IMAGE_SIZE / transform.width, MAX_IMAGE_SIZE / transform.height);
    factor = Math.max(minimum, Math.min(maximum, factor));
    var width = transform.width * factor, height = transform.height * factor;
    var objectCenter = { x: center.x + (transform.objectCenter.x - transform.center.x) * factor, y: center.y + (transform.objectCenter.y - transform.center.y) * factor };
    transform.object.width = width; transform.object.height = height; transform.object.x = objectCenter.x - width / 2; transform.object.y = objectCenter.y - height / 2;
    transform.changed = Math.abs(factor - 1) > 0.002 || distance(center, transform.center) > 0.5;
  }
  function segmentDistance(pointValue, a, b) {
    var dx = b.x - a.x, dy = b.y - a.y;
    if (!dx && !dy) return distance(pointValue, a);
    var t = ((pointValue.x - a.x) * dx + (pointValue.y - a.y) * dy) / (dx * dx + dy * dy);
    t = Math.max(0, Math.min(1, t));
    return distance(pointValue, { x: a.x + t * dx, y: a.y + t * dy });
  }
  function hitTest(p) {
    for (var index = state.objects.length - 1; index >= 0; index -= 1) {
      var object = state.objects[index];
      if (object.type === "image") {
        if (p.x >= object.x && p.x <= object.x + object.width && p.y >= object.y && p.y <= object.y + object.height) return object;
      } else {
        if (object.points.length === 1 && distance(p, object.points[0]) <= object.width / 2 + 12) return object;
        for (var pointIndex = 1; pointIndex < object.points.length; pointIndex += 1) {
          if (segmentDistance(p, object.points[pointIndex - 1], object.points[pointIndex]) <= object.width / 2 + 12) return object;
        }
      }
    }
    return null;
  }
  function bounds(object) {
    if (object.type === "image") return { x: object.x, y: object.y, width: object.width, height: object.height };
    var xs = object.points.map(function (p) { return p.x; }), ys = object.points.map(function (p) { return p.y; });
    var pad = object.width / 2 + 5, left = Math.min.apply(null, xs) - pad, top = Math.min.apply(null, ys) - pad;
    return { x: left, y: top, width: Math.max.apply(null, xs) - left + pad, height: Math.max.apply(null, ys) - top + pad };
  }
  function drawStroke(ctx, object, maskPreview) {
    if (!object.points.length) return;
    ctx.save();
    ctx.globalCompositeOperation = object.tool === "eraser" ? "destination-out" : "source-over";
    ctx.globalAlpha = object.opacity;
    ctx.strokeStyle = object.tool === "mask" && maskPreview ? "#ee4f85" : object.color;
    ctx.lineWidth = object.width;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(object.points[0].x, object.points[0].y);
    for (var index = 1; index < object.points.length; index += 1) ctx.lineTo(object.points[index].x, object.points[index].y);
    if (object.points.length === 1) ctx.lineTo(object.points[0].x + 0.1, object.points[0].y + 0.1);
    ctx.stroke();
    ctx.restore();
  }
  function loadImage(src) {
    if (!src) return Promise.resolve(null);
    if (imageCache[src] && imageCache[src].complete) return Promise.resolve(imageCache[src]);
    return new Promise(function (resolve) {
      var image = imageCache[src] || new Image();
      imageCache[src] = image;
      image.onload = function () {
        var keep = state.objects.filter(function (object) { return object.type === "image"; }).map(function (object) { return object.src || object.url; });
        if (state.result) keep.push(state.result.src);
        var keys = Object.keys(imageCache);
        keys.slice(0, Math.max(0, keys.length - 12)).forEach(function (key) { if (keep.indexOf(key) < 0) delete imageCache[key]; });
        resolve(image); render();
      };
      image.onerror = function () { resolve(null); };
      if (!image.src) image.src = src;
    });
  }
  function drawContained(ctx, image, width, height) {
    var scale = Math.min(width / image.naturalWidth, height / image.naturalHeight);
    var w = image.naturalWidth * scale, h = image.naturalHeight * scale;
    ctx.drawImage(image, (width - w) / 2, (height - h) / 2, w, h);
  }
  function drawImageObject(ctx, object) {
    var image = imageCache[object.src || object.url];
    if (image && image.complete && image.naturalWidth) ctx.drawImage(image, object.x, object.y, object.width, object.height);
    else loadImage(object.src || object.url);
  }
  function render() {
    if (!context) return;
    context.clearRect(0, 0, WIDTH, WIDTH);
    state.objects.forEach(function (object) {
      if (object.type === "stroke") drawStroke(context, object, true);
      else drawImageObject(context, object);
    });
    var selected = selectedObject();
    if (selected) {
      var box = bounds(selected);
      context.save();
      context.strokeStyle = "#ee4f85";
      context.lineWidth = 2;
      context.setLineDash([9, 7]);
      context.strokeRect(box.x, box.y, box.width, box.height);
      context.restore();
      if (selected.type === "image") {
        selectionHandles(selected).forEach(function (handle) {
          context.save(); context.beginPath(); context.arc(handle.x, handle.y, HANDLE_DRAW_RADIUS, 0, Math.PI * 2);
          context.fillStyle = "#ffffff"; context.fill(); context.lineWidth = 4; context.strokeStyle = "#e75483"; context.stroke(); context.restore();
        });
      }
    }
    document.getElementById("stage-background").style.background = state.background;
    canvas.style.opacity = "1";
    app.events.emit("canvas:rendered", { objects: state.objects.length });
  }
  function selectedObject() {
    return state.objects.find(function (object) { return object.id === state.selectedId; }) || null;
  }
  function snapshot() {
    return JSON.stringify({ objects: state.objects.map(function (object) {
      var value = app.utils.copy(object); delete value._image; return value;
    }), background: state.background });
  }
  function restore(value) {
    var data = app.utils.parseJson(value, { objects: [], background: "#ffffff" });
    state.objects = data.objects || [];
    state.background = data.background || "#ffffff";
    state.selectedId = "";
    state.objects.forEach(function (object) { if (object.type === "image") loadImage(object.src || object.url); });
    render();
    app.events.emit("history", { undo: state.history.length > 1, redo: state.future.length > 0 });
    app.events.emit("selection", "");
    app.services.store.scheduleCanvasSave();
    app.services.imageEngine.schedule();
  }
  function resetHistory() { drawingObject = null; dragging = null; resizing = null; pinching = null; activePointers = {}; state.history = [snapshot()]; state.future = []; app.events.emit("history", { undo: false, redo: false }); }
  function commit() {
    var next = snapshot();
    if (state.history[state.history.length - 1] !== next) state.history.push(next);
    if (state.history.length > 80) state.history.shift();
    state.future = [];
    app.events.emit("history", { undo: state.history.length > 1, redo: false });
    app.events.emit("selection", state.selectedId);
    app.services.store.scheduleCanvasSave();
    app.services.imageEngine.schedule();
  }
  function undo() {
    if (state.history.length <= 1) return;
    state.future.push(state.history.pop());
    restore(state.history[state.history.length - 1]);
  }
  function redo() {
    if (!state.future.length) return;
    var value = state.future.pop();
    state.history.push(value);
    restore(value);
  }
  function removeSelected() {
    if (!state.selectedId) return;
    state.objects = state.objects.filter(function (object) { return object.id !== state.selectedId; });
    state.selectedId = "";
    render(); commit();
  }
  function clear() {
    if (!state.objects.length) return;
    state.objects = [];
    state.selectedId = "";
    render(); commit();
  }
  function moveLayer(direction) {
    var index = state.objects.findIndex(function (object) { return object.id === state.selectedId; });
    var target = index + direction;
    if (index < 0 || target < 0 || target >= state.objects.length) return;
    var object = state.objects.splice(index, 1)[0];
    state.objects.splice(target, 0, object);
    render(); commit();
  }
  function scaleSelected(factor) {
    var object = selectedObject();
    if (!object) return;
    var box = bounds(object), cx = box.x + box.width / 2, cy = box.y + box.height / 2;
    if (Math.max(box.width, box.height) * factor > MAX_IMAGE_SIZE || object.type === "image" && Math.min(box.width, box.height) * factor < MIN_IMAGE_SIZE || object.type !== "image" && Math.min(box.width, box.height) * factor < 3) return;
    if (object.type === "stroke") {
      object.points.forEach(function (p) { p.x = cx + (p.x - cx) * factor; p.y = cy + (p.y - cy) * factor; });
      object.width *= factor;
    } else { object.width *= factor; object.height *= factor; object.x = cx - object.width / 2; object.y = cy - object.height / 2; }
    render(); commit();
  }
  function duplicateSelected() {
    var object = selectedObject(); if (!object) return;
    var copy = app.utils.copy(object); copy.id = app.utils.id(copy.type);
    translate(copy, 22, 22); state.objects.push(copy); state.selectedId = copy.id; render(); commit();
  }
  async function addImage(file) {
    if (!file || !file.url) return;
    var image = await loadImage(file.url);
    if (!image) throw new Error("无法读取所选图片");
    var scale = Math.min(WIDTH * 0.72 / image.naturalWidth, WIDTH * 0.72 / image.naturalHeight, 1);
    var width = image.naturalWidth * scale, height = image.naturalHeight * scale;
    var object = {
      id: app.utils.id("image"), type: "image", url: file.url, src: file.url,
      logicalFileId: file.logicalFileId || "", name: file.name || "image",
      x: (WIDTH - width) / 2, y: (WIDTH - height) / 2, width: width, height: height
    };
    state.objects.push(object);
    state.selectedId = object.id;
    state.tool = "select";
    render(); commit();
    app.events.emit("tool", "select");
  }
  function hasMask() { return state.objects.some(function (object) { return object.type === "stroke" && object.tool === "mask"; }); }
  async function drawObjectList(targetContext, includeMask) {
    var layer = document.createElement("canvas"); layer.width = WIDTH; layer.height = WIDTH;
    var layerContext = layer.getContext("2d");
    for (var index = 0; index < state.objects.length; index += 1) {
      var object = state.objects[index];
      if (object.type === "stroke") {
        if (object.tool === "mask" && !includeMask) continue;
        drawStroke(layerContext, object, false);
      } else {
        var image = await loadImage(object.src || object.url);
        if (image) layerContext.drawImage(image, object.x, object.y, object.width, object.height);
      }
    }
    targetContext.drawImage(layer, 0, 0);
  }
  async function composeInput() {
    var output = document.createElement("canvas");
    output.width = WIDTH; output.height = WIDTH;
    var ctx = output.getContext("2d");
    ctx.fillStyle = state.background;
    ctx.fillRect(0, 0, WIDTH, WIDTH);
    if (state.includeResult && state.result && state.result.src) {
      var result = await loadImage(state.result.src);
      if (result) {
        ctx.save(); ctx.globalAlpha = state.resultOpacity; drawResult(ctx, result, WIDTH, WIDTH, true); ctx.restore();
      }
    }
    await drawObjectList(ctx, false);
    return output.toDataURL("image/png");
  }
  function composeMask(openAiAlpha) {
    if (!hasMask()) return null;
    var output = document.createElement("canvas");
    output.width = WIDTH; output.height = WIDTH;
    var ctx = output.getContext("2d");
    if (openAiAlpha) {
      ctx.fillStyle = "white"; ctx.fillRect(0, 0, WIDTH, WIDTH);
      ctx.globalCompositeOperation = "destination-out";
    } else {
      ctx.fillStyle = "black"; ctx.fillRect(0, 0, WIDTH, WIDTH);
      ctx.strokeStyle = "white";
    }
    state.objects.filter(function (object) { return object.type === "stroke" && (object.tool === "mask" || object.tool === "eraser"); }).forEach(function (object) {
      var copy = app.utils.copy(object);
      copy.color = !openAiAlpha && object.tool === "eraser" ? "black" : "white";
      copy.opacity = 1; copy.tool = openAiAlpha && object.tool === "mask" ? "eraser" : "brush";
      drawStroke(ctx, copy, false);
    });
    return output.toDataURL("image/png");
  }
  async function exportImage(mode) {
    var src = await composeOutput(mode);
    var bridge = app.platform.hermit.current();
    if (bridge) {
      var image = await loadImage(src), output = document.createElement("canvas");
      var dimension = Math.min(1536, image.naturalWidth);
      var encoded;
      do {
        output.width = dimension; output.height = Math.round(dimension * image.naturalHeight / image.naturalWidth);
        output.getContext("2d").drawImage(image, 0, 0, output.width, output.height);
        encoded = output.toDataURL("image/jpeg", 0.88); dimension = Math.round(dimension * 0.8);
      } while (encoded.length > 220000 && dimension > 160);
      var svg = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="' + output.width + '" height="' + output.height + '" viewBox="0 0 ' + output.width + ' ' + output.height + '"><image width="100%" height="100%" xlink:href="' + encoded + '"/></svg>';
      var file = await bridge.files.writeText({ name: "VibeDraw-" + Date.now() + ".svg", text: svg });
      try { return await bridge.files.export({ logicalFileId: file.logicalFileId }); }
      finally { await bridge.files.delete({ logicalFileId: file.logicalFileId }).catch(function () {}); }
    }
    var anchor = document.createElement("a");
    anchor.download = "vibedraw-" + new Date().toISOString().replace(/[:.]/g, "-") + ".png";
    anchor.href = src;
    document.body.appendChild(anchor); anchor.click(); anchor.remove();
  }
  async function composeOutput(mode) {
    var output = document.createElement("canvas"); output.width = WIDTH; output.height = WIDTH;
    var ctx = output.getContext("2d"); ctx.fillStyle = state.background; ctx.fillRect(0, 0, WIDTH, WIDTH);
    if (mode !== "sketch" && state.result && state.result.src) {
      var image = await loadImage(state.result.src);
      if (image) {
        output.width = image.naturalWidth; output.height = image.naturalHeight;
        ctx.fillStyle = state.background; ctx.fillRect(0, 0, output.width, output.height);
        drawResult(ctx, image, output.width, output.height, false);
      }
    } else await drawObjectList(ctx, false);
    return output.toDataURL("image/png");
  }
  function load(saved) {
    if (!saved) return;
    ["prompt", "negativePrompt", "background", "color", "size", "opacity", "strength", "referenceStrength", "seed", "autoDelayMs", "autoGenerate", "includeResult", "resultOpacity", "resultBrightness", "resultContrast", "resultSaturation", "resultHue", "resultGlow", "resultClarity", "view", "workId", "workTitle"].forEach(function (key) {
      if (saved[key] !== undefined) state[key] = saved[key];
    });
    state.objects = saved.objects || [];
    state.result = saved.result || null;
    state.selectedId = "";
    state.objects.forEach(function (object) {
      if (object.type === "image") { object.src = object.src || object.url; loadImage(object.src); }
    });
    render(); resetHistory();
  }
  async function thumbnail(saved, target) {
    var size = 768, ctx = target.getContext("2d"); target.width = 288; target.height = 288;
    ctx.scale(288 / size, 288 / size); ctx.fillStyle = saved.background || "#fff"; ctx.fillRect(0, 0, size, size);
    if (saved.result && saved.result.asset) {
      var src = await app.services.assets.resolve(saved.result.asset), result = await loadImage(src);
      if (result) drawContained(ctx, result, size, size);
      return;
    }
    var layer = document.createElement("canvas"); layer.width = size; layer.height = size; var layerCtx = layer.getContext("2d");
    for (var object of saved.objects || []) {
      if (object.type === "stroke") { if (object.tool !== "mask") drawStroke(layerCtx, object, false); }
      else { var image = await loadImage(object.asset ? await app.services.assets.resolve(object.asset) : object.url); if (image) layerCtx.drawImage(image, object.x, object.y, object.width, object.height); }
    }
    ctx.drawImage(layer, 0, 0);
  }

  app.components.canvas = {
    init: init,
    render: render,
    commit: commit,
    undo: undo,
    redo: redo,
    removeSelected: removeSelected,
    clear: clear,
    moveLayer: moveLayer,
    scaleSelected: scaleSelected,
    duplicateSelected: duplicateSelected,
    addImage: addImage,
    composeInput: composeInput,
    composeMask: composeMask,
    composeOutput: composeOutput,
    exportImage: exportImage,
    load: load,
    thumbnail: thumbnail,
    hasMask: hasMask,
    selectionHandles: function () { return selectionHandles(selectedObject()); },
    resultFilter: resultFilter,
    resultGlowFilter: resultGlowFilter
  };
})(window.vibedraw);
