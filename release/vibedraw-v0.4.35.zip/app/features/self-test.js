(function (app) {
  "use strict";
  async function run() {
    if (window.location.hash !== "#self-test") return;
    if (!app.platform.hermit.available() && !await app.platform.hermit.awaitReady(2000)) return;
    var runtime = await app.platform.hermit.current().runtime.info();
    if (runtime.launchChannel !== "dev") return;
    var checks = {}, store = app.services.store, canvas = app.components.canvas, editor = app.features.editor, ui = app.components.ui;
    function step(name) { window.__vibedrawSelfTestProgress = name; }
    // A settled state read once, right after the change that causes it, can land
    // before a transition or a style recalc finished and report a spurious
    // failure. Wait for the state to settle with a bounded poll instead, and still
    // assert the value afterwards so a genuinely missing rule stays red.
    async function settled(probe, timeout) {
      var deadline = Date.now() + (timeout || 1200);
      while (!probe() && Date.now() < deadline) await new Promise(function (resolve) { setTimeout(resolve, 40); });
      return probe();
    }
    step("starting");
    await store.flush();
    var stale = store.list().filter(function (item) { return String(item.title || "").indexOf("DEV self-test ") === 0; });
    var currentStale = stale.some(function (item) { return item.id === app.state.workId; });
    for (var staleItem of stale) if (staleItem.id !== app.state.workId) await store.remove(staleItem.id);
    if (currentStale) {
      await store.remove(app.state.workId); editor.resetWork();
      var recoveredItem = store.list()[0];
      if (recoveredItem) { var recovered = await store.hydrate(await store.get(recoveredItem.id)); canvas.load(recovered); editor.syncAll(); }
      await store.flush();
    }
    var original = await store.loadCanvas(), config = app.utils.copy(app.config), originalTool = app.state.tool, tempId = "", originalWorkIds = store.list().map(function (item) { return item.id; });
    try {
      step("drawing"); editor.resetWork(); app.state.autoGenerate = false; app.state.workTitle = "DEV self-test " + Date.now();
      app.state.autoDelayMs = 1320; app.state.resultGlow = 38; app.state.resultClarity = 24; app.state.colorStrength = 0.47; app.state.resultAdjustmentsEnabled = true;
      checks.defaultSeedLocked = app.state.seedLocked === true && Number.isSafeInteger(app.state.seed) && app.state.seed >= 0;
      app.config.quick.endpoint = ""; app.config.quick.protocol = "cvp"; app.config.quick.model = ""; app.config.inpaint.endpoint = ""; app.config.upscale.endpoint = "";
      var target = document.getElementById("draft-canvas"), rect = target.getBoundingClientRect();
      var Type = window.PointerEvent || window.MouseEvent;
      function fire(name, x, y, pointerId, isPrimary) {
        target.dispatchEvent(new Type((window.PointerEvent ? "pointer" : "mouse") + name, { bubbles: true, isPrimary: isPrimary !== false, button: 0, pointerId: pointerId || 1, clientX: rect.left + rect.width * x, clientY: rect.top + rect.height * y }));
      }
      function stroke(tool, x, y) { editor.setTool(tool); fire("down", x, y); fire("move", x + 0.15, y + 0.15); fire("up", x + 0.15, y + 0.15); }
      stroke("pencil", .15, .15);
      checks.draw = app.state.objects.length === 1;
      canvas.undo(); checks.undo = app.state.objects.length === 0;
      canvas.redo(); checks.redo = app.state.objects.length === 1;
      editor.setTool("select"); fire("down", .2, .2); fire("up", .2, .2);
      checks.select = Boolean(app.state.selectedId);
      checks.strokeHandles = canvas.selectionHandles().length === 4;
      canvas.duplicateSelected(); canvas.scaleSelected(1.1); checks.transform = app.state.objects.length === 2;
      var originalStroke = app.state.objects[0], movedStroke = app.state.objects[1];
      var originalStartX = originalStroke.points[0].x, movedStartX = movedStroke.points[0].x;
      fire("down", .24, .24); fire("move", .44, .24); fire("up", .44, .24);
      checks.singleObjectDrag = Math.abs(originalStroke.points[0].x - originalStartX) < 1 && movedStroke.points[0].x > movedStartX + 120;
      fire("down", .2, .2); fire("up", .2, .2);
      checks.tapSelectsOne = app.state.selectedIds.length === 1 && app.state.selectedId === originalStroke.id;
      fire("down", .08, .08); fire("move", .66, .4); fire("up", .66, .4);
      checks.marqueeSelectsMany = app.state.selectedIds.length === 2;
      var groupFirstX = originalStroke.points[0].x, groupSecondX = movedStroke.points[0].x;
      fire("down", .2, .2); fire("move", .26, .25); fire("up", .26, .25);
      checks.groupDrag = originalStroke.points[0].x > groupFirstX + 40 && movedStroke.points[0].x > groupSecondX + 40 && app.state.selectedIds.length === 2;
      app.state.busy = true; app.events.emit("generation:start", { slot: "quality" }); stroke("brush", .4, .4); app.events.emit("generation:idle"); app.state.busy = false;
      checks.drawDuringGeneration = app.state.objects.length === 3;
      app.state.size = 60; stroke("mask", .7, .1);
      var mask = new Image(); mask.src = canvas.composeMask(true);
      await new Promise(function (resolve, reject) { mask.onload = resolve; mask.onerror = reject; });
      var probe = document.createElement("canvas"); probe.width = 768; probe.height = 768;
      var ctx = probe.getContext("2d"); ctx.drawImage(mask, 0, 0);
      checks.maskAlpha = ctx.getImageData(555, 94, 1, 1).data[3] < 20 && ctx.getImageData(20, 20, 1, 1).data[3] === 255;
      stroke("eraser", .7, .1);
      var erasedMask = new Image(); erasedMask.src = canvas.composeMask(true);
      await new Promise(function (resolve, reject) { erasedMask.onload = resolve; erasedMask.onerror = reject; });
      ctx.clearRect(0, 0, 768, 768); ctx.drawImage(erasedMask, 0, 0);
      checks.eraseMask = ctx.getImageData(555, 94, 1, 1).data[3] === 255;
      var tiny = document.createElement("canvas"); tiny.width = 16; tiny.height = 16; var tinyCtx = tiny.getContext("2d"); tinyCtx.fillStyle = "#36a9e8"; tinyCtx.fillRect(0, 0, 16, 16);
      var imageSrc = tiny.toDataURL("image/png");
      await canvas.addImage({ url: imageSrc, name: "self-test.png" });
      var imageObject = app.state.objects.find(function (object) { return object.type === "image"; });
      imageObject.x = 264; imageObject.y = 284; imageObject.width = 240; imageObject.height = 180; canvas.render(); canvas.commit();
      app.state.selectedIds = []; app.state.selectedId = ""; canvas.render();
      var imageBeforeMarquee = { x: imageObject.x, y: imageObject.y };
      fire("down", (imageObject.x + 12) / 768, (imageObject.y + 12) / 768); fire("move", (imageObject.x + imageObject.width + 50) / 768, (imageObject.y + imageObject.height + 50) / 768); fire("up", (imageObject.x + imageObject.width + 50) / 768, (imageObject.y + imageObject.height + 50) / 768);
      checks.imageStartsMarquee = app.state.selectedIds.indexOf(imageObject.id) >= 0 && imageObject.x === imageBeforeMarquee.x && imageObject.y === imageBeforeMarquee.y;
      editor.setTool("select"); app.state.selectedIds = [imageObject.id]; app.state.selectedId = imageObject.id; canvas.render();
      checks.imageHandles = canvas.selectionHandles().length === 4;
      var handle = canvas.selectionHandles()[3], initialWidth = imageObject.width, initialRatio = imageObject.width / imageObject.height;
      fire("down", handle.x / 768, handle.y / 768); fire("move", (handle.x + 76) / 768, (handle.y + 57) / 768); fire("up", (handle.x + 76) / 768, (handle.y + 57) / 768);
      checks.cornerResize = imageObject.width > initialWidth * 1.2 && Math.abs(imageObject.width / imageObject.height - initialRatio) < 0.01;
      var resizedWidth = imageObject.width; canvas.undo(); var undoneImage = app.state.objects.find(function (object) { return object.type === "image"; });
      checks.resizeUndo = Math.abs(undoneImage.width - initialWidth) < 1; canvas.redo(); imageObject = app.state.objects.find(function (object) { return object.type === "image"; });
      checks.resizeRedo = Math.abs(imageObject.width - resizedWidth) < 1;
      app.state.selectedIds = [imageObject.id]; app.state.selectedId = imageObject.id; canvas.render();
      var centerX = (imageObject.x + imageObject.width / 2) / 768, centerY = (imageObject.y + imageObject.height / 2) / 768, pinchWidth = imageObject.width;
      fire("down", centerX - 0.06, centerY, 1, true); fire("down", centerX + 0.06, centerY, 2, false);
      fire("move", centerX - 0.1, centerY - 0.02, 1, true); fire("move", centerX + 0.1, centerY + 0.02, 2, false); fire("up", centerX + 0.1, centerY + 0.02, 2, false);
      checks.pinchScale = imageObject.width > pinchWidth * 1.45 && Math.abs(imageObject.width / imageObject.height - initialRatio) < 0.01;
      var strokeObject = app.state.objects.find(function (object) { return object.type === "stroke" && object.tool === "pencil"; });
      app.state.selectedIds = [strokeObject.id, imageObject.id]; app.state.selectedId = imageObject.id; canvas.render();
      checks.multiSelectionHandles = canvas.selectionHandles().length === 4;
      app.components.settings.openColor("selection");
      var selectionOpacity = document.querySelector('[name="colorOpacity"]'); selectionOpacity.value = "61"; document.querySelector("[data-save]").click();
      checks.selectionColorOpacity = strokeObject.opacity === 0.61 && imageObject.opacity === undefined;
      app.state.result = { src: imageSrc, slot: "quick", prompt: "self-test", createdAt: Date.now() };
      editor.syncCanvas();
      var resultOpacity = document.getElementById("result-opacity"); resultOpacity.value = "42"; resultOpacity.dispatchEvent(new Event("input", { bubbles: true }));
      await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      checks.resultOpacity = Math.abs(app.state.resultOpacity - 0.42) < 0.001 && document.getElementById("result-opacity-value").textContent === "42%" && document.getElementById("result-image").style.opacity === "0.42";
      app.state.resultOpacity = 0.05; app.state.result = { src: imageSrc, slot: "quick", prompt: "self-test", createdAt: Date.now() }; app.events.emit("generation:done", app.state.result); await new Promise(function (resolve) { setTimeout(resolve, 560); });
      checks.resultOpacityFloor = Math.abs(app.state.resultOpacity - 0.2) < 0.001 && document.getElementById("result-image").style.opacity === "0.2";
      document.getElementById("result-visibility").click(); checks.resultVisibility = app.state.resultVisible === false && document.getElementById("result-image").hidden;
      document.getElementById("result-visibility").click();
      // A finished generation is an undoable step: Undo steps the result back to
      // the previous image and Redo brings the newer one back. The render is not
      // part of that journal, so stepping through results must leave it alone.
      step("result-history");
      var secondResult = { src: imageSrc, slot: "quick", prompt: "self-test second", createdAt: Date.now() };
      var previousResultForUndo = app.state.result;
      app.state.result = secondResult; canvas.commitResult();
      app.state.renderResult = { src: imageSrc, logicalFileId: "", slot: "upscale", createdAt: Date.now() }; editor.syncAll();
      canvas.undo();
      checks.resultUndo = app.state.result === previousResultForUndo && app.state.result.prompt === "self-test";
      checks.renderOutsideUndo = Boolean(app.state.renderResult && app.state.renderResult.slot === "upscale");
      canvas.redo();
      checks.resultRedo = app.state.result === secondResult;
      var resultVisibleBefore = app.state.resultVisible, toolBefore = app.state.tool === "mask" ? "pencil" : app.state.tool;
      editor.setTool("mask"); editor.syncCanvas();
      var maskSlider = document.getElementById("result-opacity"), maskEye = document.getElementById("result-visibility"), maskLabel = document.getElementById("opacity-target-label");
      // Labels are compared through the translator so the checks hold in either language.
      checks.maskControlsRelabelled = app.state.maskMode === true && maskLabel.textContent === app.i18n.text("蒙版层显示（0 或 100）", "Mask layer (0 or 100)") && maskSlider.disabled === false && maskEye.disabled === false;
      maskSlider.value = "0"; maskSlider.dispatchEvent(new Event("input", { bubbles: true }));
      checks.maskHiddenBySlider = app.state.maskVisible === false && maskSlider.value === "0" && app.state.resultVisible === resultVisibleBefore;
      maskEye.click();
      checks.maskShownByEye = app.state.maskVisible === true && maskSlider.value === "100" && app.state.resultVisible === resultVisibleBefore;
      var maskVisibleAfter = app.state.maskVisible;
      editor.setTool(toolBefore || "pencil"); editor.syncCanvas();
      maskEye.click();
      // Back on the result the eye must drive the result again, not the mask.
      checks.maskControlsReleased = app.state.maskMode === false && maskLabel.textContent === app.i18n.text("成图透明度", "Result opacity") && app.state.resultVisible === !resultVisibleBefore && app.state.maskVisible === maskVisibleAfter;
      maskEye.click();
      checks.resultOverElements = Number(getComputedStyle(document.getElementById("result-image")).zIndex) > Number(getComputedStyle(document.getElementById("selection-canvas")).zIndex) && getComputedStyle(document.getElementById("result-image")).pointerEvents === "none" && getComputedStyle(document.getElementById("result-image")).touchAction === "none";
      var stageRect = document.getElementById("stage-frame").getBoundingClientRect();
      checks.resultPointerPassThrough = document.elementFromPoint(stageRect.left + stageRect.width / 2, stageRect.top + stageRect.height / 2) === document.getElementById("draft-canvas");
      checks.selectionOverlay = Number(getComputedStyle(document.getElementById("selection-canvas")).zIndex) > Number(getComputedStyle(document.getElementById("draft-canvas")).zIndex);
      checks.noPreviewBadge = !document.getElementById("stage-badge");
      app.state.prompt = "History and image round trip with a deliberately long English description that exceeds the compact summary width"; editor.syncAll();
      // Pin a value the floor animation cannot produce, so the restore assertion
      // below proves persistence instead of re-reading whatever the animation left.
      app.state.resultOpacity = 0.23; editor.syncCanvas();
      step("saving-assets"); await store.flush(); tempId = app.state.workId;
      var saved = await store.get(tempId);
      checks.noInlineImageData = JSON.stringify(saved).indexOf("data:image") < 0 && saved.result.asset.parts.length > 0;
      checks.historyCreated = store.list().some(function (item) { return item.id === tempId; });
      var count = app.state.objects.length;
      app.services.assets.clearCache();
      step("restoring"); editor.resetWork(); var restored = await store.restoreWork(tempId, false); canvas.load(restored); editor.syncAll();
      checks.filesystemReadback = restored.result.src === imageSrc;
      checks.renderRestore = Boolean(app.state.renderResult && app.state.renderResult.slot === "upscale" && app.state.renderResult.src === imageSrc);
      checks.restore = app.state.prompt.indexOf("History and image round trip") === 0 && app.state.objects.length === count && app.state.result.src === imageSrc;
      checks.fileSettingsRestore = app.state.autoDelayMs === 1320 && app.state.resultOpacity === 0.23 && app.state.layerOpacity === 1 && app.state.resultVisible === true && app.state.resultGlow === 38 && app.state.resultClarity === 24 && app.state.colorStrength === 0.47 && app.state.resultAdjustmentsEnabled === true;
      checks.imageRestore = app.state.objects.some(function (object) { return object.type === "image" && object.src === imageSrc; });
      var workCount = store.list().length;
      await store.flush(); checks.noDuplicateAutosaves = store.list().length === workCount;
      step("gallery"); await app.components.gallery.open();
      checks.historyGallery = Boolean(document.querySelector('[data-work="' + tempId + '"] canvas'));
      var search = document.getElementById("history-search"); search.value = "not-found-" + Date.now(); search.dispatchEvent(new Event("input", { bubbles: true }));
      checks.historySearch = document.querySelectorAll(".art-card").length === 0; ui.close();
      step("settings"); app.components.settings.open("models");
      checks.threeTaskTabs = document.querySelectorAll("[data-slot-tab]").length === 3;
      document.querySelector('[data-slot-tab="upscale"]').click();
      checks.independentModelTabs = Boolean(document.querySelector('[data-model-card="upscale"]'));
      checks.aspectLocked = Boolean(document.querySelector(".aspect-field")) && !document.querySelector('.aspect-field [name="width"]') && !document.querySelector('.aspect-field [name="steps"]');
      document.querySelector('[data-slot-tab="inpaint"]').click();
      checks.localRedrawTab = Boolean(document.querySelector('[data-model-card="inpaint"]'));
      checks.keyMasked = document.querySelector('[name="apiKey"]').type === "password";
      ui.close();
      app.components.settings.open("work");
      checks.workSettings = Boolean(document.querySelectorAll('[name="strength"]').length === 1 && document.querySelector('[name="strength"]').min === "0" && document.querySelector('[name="strength"]').max === "100" && !document.querySelector('[name="referenceStrength"]') && !document.querySelector('[name="colorStrength"]') && document.querySelector('[name="prompt"]').rows === 3 && document.querySelector('[name="negativePrompt"]').rows === 2 && document.querySelector('[name="seed"]') && document.querySelector('[name="seedLocked"]').getAttribute("role") === "switch" && document.querySelector('[name="autoDelayMs"]') && document.querySelector('[name="overlayGenerate"]').getAttribute("role") === "switch" && document.querySelector('[name="overlayGenerate"]').classList.contains("toggle-switch"));
      var workSheet = document.querySelector("#modal-layer .modal-sheet"), workContent = document.getElementById("modal-content"), workActions = document.getElementById("modal-actions");
      checks.workSettingsSheet = workSheet.classList.contains("work-settings-sheet") && !workSheet.classList.contains("centered") && Math.abs(workSheet.getBoundingClientRect().bottom - window.innerHeight) < 2;
      checks.fixedWorkFooter = !workActions.hidden && Boolean(workActions.querySelector("[data-cancel]") && workActions.querySelector("[data-save]")) && !workContent.contains(workActions.querySelector("[data-save]")) && getComputedStyle(workContent).overflowY === "auto" && getComputedStyle(workActions).flexShrink === "0";
      checks.cleanWorkFooter = getComputedStyle(workActions).borderTopWidth === "0px" && getComputedStyle(document.querySelectorAll(".work-settings-content .switch-row")[1]).borderBottomWidth === "0px";
      ui.close();
      document.getElementById("color-adjust").click();
      var adjustPanel = document.getElementById("color-adjust-panel"), brightnessField = document.querySelector('[data-adjust="resultBrightness"]'), previousFilter = document.getElementById("result-image").style.filter;
      checks.colorAdjustments = !adjustPanel.hidden && document.querySelectorAll("[data-adjust]").length === 6 && getComputedStyle(adjustPanel).gridTemplateColumns.split(" ").length === 2;
      document.getElementById("color-adjust-enabled").click();
      checks.colorEffectsDisabled = app.state.resultAdjustmentsEnabled === false && canvas.resultFilter() === "none" && document.getElementById("result-image").style.filter === "none" && document.getElementById("color-adjust-enabled").getAttribute("aria-pressed") === "false";
      document.getElementById("color-adjust-enabled").click();
      checks.colorEffectsEnabled = app.state.resultAdjustmentsEnabled === true && canvas.resultFilter() !== "none" && document.getElementById("color-adjust-enabled").getAttribute("aria-pressed") === "true";
      brightnessField.value = "123"; brightnessField.dispatchEvent(new Event("input", { bubbles: true }));
      await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      checks.liveColorAdjustments = app.state.resultBrightness === 123 && document.querySelector('[data-adjust-output="resultBrightness"]').textContent === "123%" && document.getElementById("result-image").style.filter !== previousFilter;
      var clarityField = document.querySelector('[data-adjust="resultClarity"]'); clarityField.value = "50"; clarityField.dispatchEvent(new Event("input", { bubbles: true }));
      await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      checks.realSharpening = canvas.resultFilter().indexOf("url(") >= 0 && document.getElementById("vibedraw-sharpen-matrix").getAttribute("kernelMatrix") !== "0 0 0 0 1 0 0 0 0";
      document.getElementById("color-adjust-default").click();
      for (var saveWait = 0; saveWait < 20 && (app.config.canvas.resultBrightness !== 123 || app.config.canvas.resultClarity !== 50); saveWait += 1) await new Promise(function (resolve) { setTimeout(resolve, 25); });
      checks.adjustmentDefaults = app.config.canvas.resultBrightness === 123 && app.config.canvas.resultClarity === 50;
      document.getElementById("color-adjust-reset").click(); checks.adjustmentReset = app.state.resultBrightness === 100 && app.state.resultClarity === 0;
      checks.roundRanges = getComputedStyle(document.querySelector('[data-adjust="resultGlow"]')).height === "24px";
      document.getElementById("color-adjust-close").click(); checks.inlineAdjustClose = adjustPanel.hidden;
      app.components.settings.openColor("background");
      checks.compactColorPicker = document.querySelectorAll('input[type="color"]').length === 0 && document.querySelectorAll('[name="hue"],[name="saturation"],[name="lightness"]').length === 3 && !document.querySelector('[name="colorOpacity"]') && getComputedStyle(document.querySelector(".color-slider-stack .field")).marginBottom === "5px";
      ui.close();
      app.components.settings.openColor("stroke");
      var pickerOpacity = document.querySelector('[name="colorOpacity"]'); pickerOpacity.value = "37"; pickerOpacity.dispatchEvent(new Event("input", { bubbles: true })); document.querySelector("[data-save]").click();
      checks.colorOpacityToolSync = app.state.opacity === 0.37 && document.getElementById("stroke-opacity").value === "37" && document.getElementById("stroke-opacity-value").textContent === "37%";
      // The image-weight slider is the only control that writes state.strength, so
      // its declared range and the clamp on the value it writes must agree.
      var strengthSlider = document.getElementById("prompt-strength"), strengthBefore = app.state.strength;
      app.state.strength = 0.05; editor.syncAll(); var strengthFloor = strengthSlider.value;
      app.state.strength = 1.5; editor.syncAll(); var strengthCeiling = strengthSlider.value;
      app.state.strength = strengthBefore; editor.syncAll();
      checks.promptStrengthRange = strengthSlider.min === "20" && strengthSlider.max === "100" && strengthFloor === "20" && strengthCeiling === "100" && strengthSlider.value === "80";
      step("layout"); app.config.preferences = { theme: "dark", language: "en" }; app.i18n.theme(); editor.syncAll();
      checks.theme = document.documentElement.dataset.theme === "dark" && getComputedStyle(document.body).backgroundColor === "rgb(23, 25, 29)";
      checks.language = document.documentElement.lang === "en" && document.querySelector('[data-menu="history"] span').textContent === "Your artwork";
      var dialog = ui.open({ title: "Self-test", mode: "center", html: "<button>Test</button>" });
      checks.centerDialog = dialog.parentNode.classList.contains("centered"); ui.close();
      var confirm = ui.confirm({ title: "Self-test", message: "Cancel test" });
      document.getElementById("confirm-cancel").click(); checks.confirm = await confirm === false;
      app.components.settings.open("preferences"); checks.sheet = !document.querySelector("#modal-layer .modal-sheet").classList.contains("centered"); ui.close();
      var frame = document.getElementById("stage-frame").getBoundingClientRect();
      checks.layout = Math.abs(frame.width - frame.height) < 2 && document.documentElement.scrollWidth <= window.innerWidth;
      checks.promptAboveCanvas = document.querySelector(".prompt-panel").getBoundingClientRect().bottom < frame.top;
      var promptSummary = document.getElementById("prompt-display"); promptSummary.scrollLeft = 24;
      checks.singleLinePrompt = promptSummary.tagName === "DIV" && !document.getElementById("prompt-input") && !document.getElementById("prompt-save") && getComputedStyle(promptSummary).whiteSpace === "nowrap" && promptSummary.scrollWidth > promptSummary.clientWidth && promptSummary.scrollLeft > 0;
      checks.borderlessPrompt = getComputedStyle(document.querySelector(".prompt-panel")).borderTopWidth === "0px" && getComputedStyle(document.querySelector(".prompt-panel")).backgroundColor === "rgba(0, 0, 0, 0)";
      checks.resultDisplayControls = Boolean(document.getElementById("result-opacity") && document.getElementById("result-visibility")) && document.querySelectorAll("[data-view]").length === 0;
      checks.compactGenerationControls = document.getElementById("generate-quick").textContent.trim() === "Fast" && document.getElementById("generate-quality").textContent.trim() === "Render" && Boolean(document.querySelector("#export-image .fa-download") && document.querySelector("#seed-lock .fa-dice") && document.querySelector("#snapshot-canvas .fa-camera") && !document.getElementById("generation-strength") && document.getElementById("overlay-toggle").getAttribute("role") === "switch");
      var oldSeed = app.state.seed, quickSeedRuns = 0, originalRun = app.services.imageEngine.run;
      app.services.imageEngine.run = function (slot, automatic) { if (slot === "quick" && automatic === false) quickSeedRuns += 1; };
      document.getElementById("seed-lock").click(); app.services.imageEngine.run = originalRun;
      var seedText = String(app.state.seed), expectedSeedLabel = seedText.length < 5 ? seedText : ".." + seedText.slice(-2);
      checks.seedRollButton = app.state.seed !== oldSeed && app.state.seedLocked === true && quickSeedRuns === 1 && document.getElementById("seed-value").textContent === expectedSeedLabel && !document.getElementById("seed-lock").hasAttribute("aria-pressed");
      checks.generationHelp = document.getElementById("status-line").textContent.indexOf("Roll and lock") >= 0;
      var generationButtons = Array.prototype.slice.call(document.querySelectorAll(".generation-row button")), generationSizes = generationButtons.map(function (button) { var rect = button.getBoundingClientRect(); return Math.round(rect.width) + "x" + Math.round(rect.height); });
      checks.generationButtonOrder = generationButtons.map(function (button) { return button.id; }).join(",") === "auto-toggle,generate-quick,seed-lock,generate-quality,overlay-toggle,snapshot-canvas,export-image";
      checks.equalSquareGenerationButtons = generationSizes.every(function (size) { return size === generationSizes[0] && /^(?:44x44|40x40)$/.test(size); });
      var scheduleCalls = 0, originalSchedule = app.services.imageEngine.schedule, originalOverlayGenerate = app.state.overlayGenerate;
      try {
        app.state.autoGenerate = true; app.services.imageEngine.schedule = function () { if (app.state.autoGenerate) scheduleCalls += 1; };
        document.getElementById("overlay-toggle").click();
        await new Promise(function (resolve) { setTimeout(resolve, 220); });
        checks.overlayGenerationSwitch = app.state.overlayGenerate !== originalOverlayGenerate && document.getElementById("overlay-toggle").getAttribute("aria-checked") === "true" && scheduleCalls === 1;
        checks.overlayResultBelow = Math.abs(app.state.layerOpacity - 0.66) < 0.001 && Number(getComputedStyle(document.getElementById("result-image")).zIndex) < Number(getComputedStyle(document.getElementById("draft-canvas")).zIndex) && document.getElementById("result-opacity").value === "66" && document.getElementById("opacity-target-label").textContent === "Element layer opacity";
      var resultOpacityBeforeOverlaySlider = app.state.resultOpacity;
      var layerOpacityControl = document.getElementById("result-opacity"); layerOpacityControl.value = "42"; layerOpacityControl.dispatchEvent(new Event("input", { bubbles: true }));
      await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      checks.overlaySliderTargetsElements = Math.abs(app.state.layerOpacity - 0.42) < 0.001 && Math.abs(app.state.resultOpacity - resultOpacityBeforeOverlaySlider) < 0.001 && document.getElementById("draft-canvas").style.opacity === "0.42" && scheduleCalls === 2;
        document.getElementById("overlay-toggle").click();
        await new Promise(function (resolve) { setTimeout(resolve, 220); });
        checks.standardResultAbove = app.state.overlayGenerate === false && Math.abs(app.state.resultOpacity - 0.66) < 0.001 && document.getElementById("draft-canvas").style.opacity === "1" && Number(getComputedStyle(document.getElementById("result-image")).zIndex) > Number(getComputedStyle(document.getElementById("selection-canvas")).zIndex) && document.getElementById("result-opacity").value === "66" && document.getElementById("opacity-target-label").textContent === "Result opacity" && scheduleCalls === 3;
      } finally { app.services.imageEngine.schedule = originalSchedule; app.state.autoGenerate = false; }
      var previousOverlayForVisibility = app.state.overlayGenerate;
      app.state.overlayGenerate = true; app.state.layerOpacity = 0.05; editor.syncCanvas(); editor.setTool("select");
      fire("down", .52, .52); fire("up", .52, .52);
      checks.minimumLayerVisibility = Math.abs(app.state.layerOpacity - 0.2) < 0.001 && document.getElementById("draft-canvas").style.opacity === "0.2" && document.getElementById("result-opacity").value === "20";
      app.state.overlayGenerate = previousOverlayForVisibility; app.state.layerOpacity = 1; editor.syncCanvas();
      var snapshotCount = app.state.objects.length;
      app.state.resultOpacity = 1; app.state.resultVisible = true; app.state.resultBrightness = 50; app.state.resultSaturation = 0; app.state.resultContrast = 100; app.state.resultHue = 0; app.state.resultGlow = 0; app.state.resultClarity = 0; app.state.resultAdjustmentsEnabled = true;
      var snapshotObject = await canvas.snapshotVisible(), snapshotImage = new Image(); snapshotImage.src = snapshotObject.src;
      await new Promise(function (resolve, reject) { snapshotImage.onload = resolve; snapshotImage.onerror = reject; });
      var snapshotProbe = document.createElement("canvas"); snapshotProbe.width = 8; snapshotProbe.height = 8; var snapshotContext = snapshotProbe.getContext("2d"); snapshotContext.drawImage(snapshotImage, 0, 0, 8, 8);
      var snapshotPixel = snapshotContext.getImageData(4, 4, 1, 1).data;
      checks.snapshotEditable = app.state.objects.length === snapshotCount + 1 && snapshotObject.type === "image" && snapshotObject.x === 0 && snapshotObject.y === 0 && snapshotObject.width === 768 && snapshotObject.height === 768 && app.state.selectedId === snapshotObject.id && app.state.tool === "select" && canvas.selectionHandles().length === 4;
      checks.snapshotVisibleEffects = Math.max(snapshotPixel[0], snapshotPixel[1], snapshotPixel[2]) - Math.min(snapshotPixel[0], snapshotPixel[1], snapshotPixel[2]) < 5 && snapshotPixel[0] < 150;
      document.querySelector('[data-tool="brush"]').click();
      checks.directStrokeSliders = Boolean(document.getElementById("brush-size") && document.getElementById("stroke-opacity") && !document.getElementById("brush-more") && !document.getElementById("stroke-opacity-control").hidden);
      checks.toolHelp = document.getElementById("status-line").textContent.indexOf("Paint color areas") >= 0;
      checks.newWorkInMenu = Boolean(document.querySelector('[data-menu="new"]')) && /^(?:Untitled artwork \d+|未命名作品\d+)$/.test(editor.nextUntitledTitle());
      checks.compactWorkHeading = !document.getElementById("new-work") && !document.getElementById("open-history") && Boolean(document.querySelector("#work-settings .fa-gear"));
      app.state.workTitle = "A deliberately very long artwork title that must stay on one line and end with an ellipsis"; editor.syncAll();
      var titleNode = document.getElementById("work-title"), titleStyle = getComputedStyle(titleNode);
      checks.longTitleEllipsis = titleStyle.textOverflow === "ellipsis" && titleStyle.whiteSpace === "nowrap" && titleNode.scrollWidth > titleNode.clientWidth;
      app.state.workTitle = ""; app.state.prompt = "This prompt must never become the artwork title"; editor.syncAll();
      checks.promptNeverBecomesTitle = /^(?:Untitled artwork \d+|未命名作品\d+)$/.test(app.state.workTitle) && document.getElementById("work-title").textContent === app.state.workTitle && document.getElementById("work-title").textContent !== app.state.prompt;
      checks.canvasActionOrder = Array.prototype.map.call(document.querySelectorAll(".canvas-actions button"), function (button) { return button.id; }).join(",") === "canvas-fullscreen,color-adjust,undo,redo,clear-canvas" && Boolean(document.querySelector("#clear-canvas .fa-trash-can"));
      checks.canvasHelp = document.querySelectorAll(".canvas-bar [data-help-zh]").length === 6 && document.getElementById("status-line").textContent.length > 0;
      checks.backgroundLabel = document.getElementById("background-color").textContent.trim() === "BG";
      var fullscreenButton = document.getElementById("canvas-fullscreen"); fullscreenButton.click();
      await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      var fullscreenFrame = document.getElementById("stage-frame").getBoundingClientRect(), fullscreenBarStyle = getComputedStyle(document.querySelector(".canvas-bar")), fullscreenBottomStyle = getComputedStyle(document.getElementById("fullscreen-bottom"));
      checks.fullscreenCanvas = document.body.classList.contains("canvas-fullscreen") && Math.abs(fullscreenFrame.height - window.innerHeight) < 2 && Math.abs(fullscreenFrame.width - fullscreenFrame.height) < 2;
      checks.fullscreenFloatingTools = fullscreenBarStyle.position === "fixed" && fullscreenBottomStyle.position === "fixed" && Number(fullscreenBarStyle.zIndex) > Number(getComputedStyle(document.getElementById("result-image")).zIndex);
      checks.fullscreenGradients = fullscreenBarStyle.backgroundImage.indexOf("linear-gradient") >= 0 && fullscreenBottomStyle.backgroundImage.indexOf("linear-gradient") >= 0;
      var fullscreenDockStyle = getComputedStyle(document.querySelector(".drawing-dock"));
      checks.fullscreenFrostedTools = fullscreenDockStyle.backgroundColor.indexOf("rgba") === 0 && fullscreenDockStyle.backgroundColor !== "rgba(0, 0, 0, 0)";
      var fullscreenButtonStyle = getComputedStyle(fullscreenButton), opacityOutputRect = document.getElementById("result-opacity-value").getBoundingClientRect(), fullscreenButtonRect = fullscreenButton.getBoundingClientRect();
      checks.fullscreenButtonStyle = fullscreenButtonStyle.color === "rgb(255, 255, 255)" && fullscreenButtonStyle.backgroundColor !== "rgba(0, 0, 0, 0)";
      checks.fullscreenControlGap = fullscreenButtonRect.left - opacityOutputRect.right >= 6;
      var toolsToggle = document.getElementById("fullscreen-tools-toggle"), toolsToggleRect = toolsToggle.getBoundingClientRect(), dockRect = document.querySelector(".drawing-dock").getBoundingClientRect();
      checks.fullscreenToolsToggle = getComputedStyle(toolsToggle).display !== "none" && Math.abs(toolsToggleRect.width - 48) < 2 && Math.abs(toolsToggleRect.height - 38) < 2 && Math.abs(toolsToggleRect.bottom - dockRect.top) < 2 && toolsToggle.getAttribute("aria-expanded") === "true";
      toolsToggle.click(); await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      checks.fullscreenToolsCollapsed = document.body.classList.contains("fullscreen-tools-collapsed") && toolsToggle.getAttribute("aria-expanded") === "false" && Boolean(toolsToggle.querySelector(".fa-caret-up")) && getComputedStyle(document.querySelector(".drawing-dock")).display === "none" && getComputedStyle(document.querySelector(".generation-row")).display === "none" && getComputedStyle(toolsToggle).display !== "none" && getComputedStyle(document.getElementById("fullscreen-bottom")).backgroundImage === "none";
      var collapsedToggleRect = toolsToggle.getBoundingClientRect(), collapsedToggleStyle = getComputedStyle(toolsToggle);
      checks.fullscreenToggleFlush = Math.abs(collapsedToggleRect.bottom - window.innerHeight) < 2 && collapsedToggleStyle.borderBottomLeftRadius === "0px" && collapsedToggleStyle.borderBottomRightRadius === "0px" && collapsedToggleStyle.backgroundColor !== "rgba(0, 0, 0, 0)";
      toolsToggle.click(); await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      checks.fullscreenToolsExpanded = !document.body.classList.contains("fullscreen-tools-collapsed") && toolsToggle.getAttribute("aria-expanded") === "true" && Boolean(toolsToggle.querySelector(".fa-caret-down")) && getComputedStyle(document.querySelector(".drawing-dock")).display !== "none";
      app.events.emit("canvas:interaction", true);
      // Interactive mode fades the chrome out over a CSS transition, so wait for
      // it to settle before reading the opacity.
      await settled(function () { return Number(getComputedStyle(document.querySelector(".canvas-bar")).opacity) < 0.05 && Number(getComputedStyle(document.getElementById("fullscreen-bottom")).opacity) < 0.05; }, 1500);
      checks.fullscreenInteractionState = document.body.classList.contains("canvas-interacting");
      checks.fullscreenInteractionHidesTop = Number(getComputedStyle(document.querySelector(".canvas-bar")).opacity) < 0.05;
      checks.fullscreenInteractionHidesBottom = Number(getComputedStyle(document.getElementById("fullscreen-bottom")).opacity) < 0.05;
      app.events.emit("canvas:interaction", false);
      await settled(function () { return Number(getComputedStyle(document.querySelector(".canvas-bar")).opacity) > 0.95 && Number(getComputedStyle(document.getElementById("fullscreen-bottom")).opacity) > 0.95; }, 1000);
      checks.fullscreenInteractionRestoresChrome = !document.body.classList.contains("canvas-interacting") && Number(getComputedStyle(document.querySelector(".canvas-bar")).opacity) > 0.95 && Number(getComputedStyle(document.getElementById("fullscreen-bottom")).opacity) > 0.95;
      fullscreenButton.click(); await new Promise(function (resolve) { requestAnimationFrame(resolve); }); checks.fullscreenExit = !document.body.classList.contains("canvas-fullscreen") && Boolean(document.querySelector("#canvas-fullscreen .fa-expand"));
      app.components.renderPreview.open({ src: imageSrc, logicalFileId: "", slot: "upscale" }); await new Promise(function (resolve) { requestAnimationFrame(resolve); });
      await new Promise(function (resolve) { setTimeout(resolve, 30); });
      var preview = document.getElementById("render-preview"), previewTools = document.querySelector(".render-preview-tools");
      checks.renderPreview = !preview.hidden && getComputedStyle(preview).position === "fixed" && getComputedStyle(preview).width === window.innerWidth + "px" && getComputedStyle(document.getElementById("render-preview-stage")).position === "absolute" && getComputedStyle(document.getElementById("render-preview-stage")).touchAction === "none" && document.getElementById("render-preview-image").hidden && !document.getElementById("render-preview-surface").hidden && document.getElementById("render-preview-surface").width > 0 && Boolean(previewTools && getComputedStyle(previewTools).borderRadius !== "0px" && document.getElementById("render-preview-adjust") && document.querySelectorAll("[data-render-adjust]").length === 6 && document.getElementById("render-preview-download") && document.getElementById("render-preview-reset") && document.getElementById("render-preview-clear") && document.getElementById("render-preview-close"));
      app.components.renderPreview.close();
      app.state.renderResult = { src: imageSrc, logicalFileId: "", slot: "upscale", createdAt: Date.now() }; editor.syncAll();
      checks.renderResultChrome = !document.getElementById("render-result-trigger").hidden && document.getElementById("render-result-trigger").classList.contains("is-ready") && !document.getElementById("render-notice");
      app.events.emit("render:clear");
      checks.renderResultClear = app.state.renderResult === null && document.getElementById("render-result-trigger").hidden;
      checks.colorButtons = document.querySelectorAll('input[type="color"]').length === 0 && getComputedStyle(document.getElementById("background-color")).borderRadius === "50%";
      document.body.classList.remove("keyboard-focus"); document.getElementById("work-settings").focus();
      checks.noTapOutline = getComputedStyle(document.getElementById("work-settings")).outlineStyle === "none";
      app.components.settings.open("models");
      var advancedSummary = document.querySelector("details.advanced > summary");
      if (advancedSummary) { document.body.classList.add("keyboard-focus"); advancedSummary.focus(); await settled(function () { return getComputedStyle(advancedSummary).outlineStyle === "none"; }, 800); checks.advancedNoOutline = getComputedStyle(advancedSummary).outlineStyle === "none"; }
      document.body.classList.remove("keyboard-focus"); ui.close();
      checks.brandLeft = document.querySelector(".brand").getBoundingClientRect().left <= 24 && document.getElementById("app-version").textContent === "v" + app.version;
      var performanceState = canvas.performance(), assetPerformance = app.services.assets.performance();
      // The journal keeps the current state plus one entry per undoable action,
      // so a 120-step limit is 121 entries.
      checks.performanceBounds = performanceState.imageCache.entries <= 16 && performanceState.undoLimit === 120 && performanceState.historyEntries <= performanceState.undoLimit + 1 && assetPerformance.cache.entries <= 10;
      var generate = document.getElementById("generate-quality").getBoundingClientRect();
      checks.actionsVisible = generate.left >= 0 && generate.right <= window.innerWidth && generate.bottom <= window.innerHeight;
      checks.bridgeReady = Boolean(window.hermit.isReady);
    } catch (error) {
      checks.error = app.utils.cleanError(error);
    } finally {
      step("cleanup"); ui.close(); app.components.renderPreview.close(); app.services.imageEngine.cancel();
      app.config = config; await store.saveConfig(config);
      canvas.load(original || { objects: [], result: null, prompt: "", workId: "", workTitle: "" });
      app.state.tool = originalTool; app.i18n.theme(); editor.syncAll(); await store.flush();
      var testWorks = store.list().filter(function (item) { return originalWorkIds.indexOf(item.id) < 0; });
      for (var testWork of testWorks) await store.remove(testWork.id);
      window.__vibedrawSelfTest = { version: app.version, passed: Object.keys(checks).every(function (key) { return checks[key] === true; }), checks: checks };
      window.__vibedrawSelfTestProgress = "complete";
      window.history.replaceState(null, "", window.location.pathname);
      editor.status(editor.defaultStatus());
    }
  }
  app.features.selfTest = { run: run };
})(window.vibedraw);
